import React, { useState, useEffect } from 'react';
import { LanguageProvider, useLanguage } from '@/hooks/useLanguage';
import { t, LANGUAGES } from '@/lib/languages';
import LanguageSelector from '@/components/LanguageSelector';
import OnboardingForm, { type FarmData } from '@/components/OnboardingForm';
import FarmProfileTab from '@/components/FarmProfileTab';
import DashboardTab from '@/components/DashboardTab';
import ScanTab from '@/components/ScanTab';
import MapTab from '@/components/MapTab';
import ShopsTab from '@/components/ShopsTab';
import ConsultantsTab from '@/components/ConsultantsTab';
import CropCalendarTab from '@/components/CropCalendarTab';
import CommunityTab from '@/components/CommunityTab';
import MarketPricesTab from '@/components/MarketPricesTab';
import WaterAdvisoryTab from '@/components/WaterAdvisoryTab';
import { User, LayoutDashboard, ScanLine, Map, Store, UserCheck, Wifi, WifiOff, Sprout, Calendar, Users, IndianRupee, Droplets } from 'lucide-react';

type AppScreen = 'lang' | 'onboarding' | 'main';
type TabId = 'profile' | 'dashboard' | 'scan' | 'map' | 'shops' | 'consultants' | 'calendar' | 'community' | 'prices' | 'water';

function AppInner() {
  const { lang, setLang, isRTL, meta } = useLanguage();
  const [screen, setScreen] = useState<AppScreen>(() => {
    const saved = localStorage.getItem('farmData');
    return saved ? 'main' : 'lang';
  });
  const [farmData, setFarmData] = useState<FarmData | null>(() => {
    const saved = localStorage.getItem('farmData');
    return saved ? JSON.parse(saved) : null;
  });
  const [activeTab, setActiveTab] = useState<TabId>('profile');
  const [isOffline, setIsOffline] = useState(false);

  const tabs: { id: TabId; icon: React.ReactNode; labelKey: string }[] = [
    { id: 'profile', icon: <User className="w-5 h-5" />, labelKey: 'farmProfile' },
    { id: 'dashboard', icon: <LayoutDashboard className="w-5 h-5" />, labelKey: 'dashboard' },
    { id: 'scan', icon: <ScanLine className="w-5 h-5" />, labelKey: 'scan' },
    { id: 'water', icon: <Droplets className="w-5 h-5" />, labelKey: 'waterAdvisory' },
    { id: 'calendar', icon: <Calendar className="w-5 h-5" />, labelKey: 'calendar' },
    { id: 'prices', icon: <IndianRupee className="w-5 h-5" />, labelKey: 'prices' },
    { id: 'map', icon: <Map className="w-5 h-5" />, labelKey: 'map' },
    { id: 'shops', icon: <Store className="w-5 h-5" />, labelKey: 'shops' },
    { id: 'community', icon: <Users className="w-5 h-5" />, labelKey: 'community' },
    { id: 'consultants', icon: <UserCheck className="w-5 h-5" />, labelKey: 'farmConsultants' },
  ];

  const handleFarmUpdate = (data: FarmData) => {
    setFarmData(data);
    localStorage.setItem('farmData', JSON.stringify(data));
  };

  if (screen === 'lang') {
    return <LanguageSelector onComplete={() => setScreen(farmData ? 'main' : 'onboarding')} />;
  }

  if (screen === 'onboarding') {
    return (
      <OnboardingForm
        onComplete={(data) => {
          handleFarmUpdate(data);
          setScreen('main');
        }}
      />
    );
  }

  return (
    <div className={`min-h-screen bg-background flex flex-col ${isRTL ? 'text-right' : 'text-left'}`}>
      {/* Top bar */}
      <header className="bg-card border-b border-border px-4 py-3 flex items-center justify-between sticky top-0 z-50">
        <div className="flex items-center gap-2">
          <div className="w-9 h-9 rounded-full bg-primary flex items-center justify-center">
            <Sprout className="w-5 h-5 text-primary-foreground" />
          </div>
          <span className="font-black text-foreground text-lg">{t(lang, 'appName')}</span>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={() => setIsOffline(!isOffline)}
            className={`flex items-center gap-1 px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
              isOffline ? 'bg-warning/20 text-warning-foreground' : 'bg-success/20 text-success-foreground'
            }`}
          >
            {isOffline ? <WifiOff className="w-3 h-3" /> : <Wifi className="w-3 h-3" />}
            {isOffline ? t(lang, 'offline') : t(lang, 'online')}
          </button>
          <select
            value={lang}
            onChange={e => setLang(e.target.value as any)}
            className="bg-muted text-foreground text-xs font-semibold px-2 py-1.5 rounded-xl border border-border outline-none"
          >
            {LANGUAGES.map(l => (
              <option key={l.code} value={l.code}>{l.nativeName}</option>
            ))}
          </select>
        </div>
      </header>

      {/* Content */}
      <main className="flex-1 overflow-y-auto p-4 pb-24 max-w-lg mx-auto w-full">
        {activeTab === 'profile' && farmData && <FarmProfileTab farmData={farmData} onUpdate={handleFarmUpdate} />}
        {activeTab === 'dashboard' && farmData && <DashboardTab farmData={farmData} />}
        {activeTab === 'scan' && <ScanTab />}
        {activeTab === 'water' && farmData && <WaterAdvisoryTab farmData={farmData} />}
        {activeTab === 'calendar' && farmData && <CropCalendarTab farmData={farmData} />}
        {activeTab === 'prices' && farmData && <MarketPricesTab farmData={farmData} />}
        {activeTab === 'map' && <MapTab />}
        {activeTab === 'shops' && <ShopsTab />}
        {activeTab === 'community' && <CommunityTab />}
        {activeTab === 'consultants' && <ConsultantsTab />}
      </main>

      {/* Bottom nav */}
      <nav className="fixed bottom-0 left-0 right-0 bg-card border-t border-border z-50">
        <div className="flex overflow-x-auto max-w-lg mx-auto scrollbar-hide">
          {tabs.map(tab => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex flex-col items-center py-2 px-3 min-w-[60px] transition-all flex-shrink-0 ${
                activeTab === tab.id ? 'text-primary' : 'text-muted-foreground'
              }`}
            >
              {tab.icon}
              <span className="text-[9px] font-semibold mt-0.5 whitespace-nowrap">{t(lang, tab.labelKey as any)}</span>
            </button>
          ))}
        </div>
      </nav>
    </div>
  );
}

const Index = () => (
  <LanguageProvider>
    <AppInner />
  </LanguageProvider>
);

export default Index;
