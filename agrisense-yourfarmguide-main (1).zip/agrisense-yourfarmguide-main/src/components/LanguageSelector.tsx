import React from 'react';
import { LANGUAGES, type LangCode } from '@/lib/languages';
import { useLanguage } from '@/hooks/useLanguage';
import { Sprout } from 'lucide-react';

interface Props {
  onComplete: () => void;
}

export default function LanguageSelector({ onComplete }: Props) {
  const { lang, setLang } = useLanguage();

  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-background p-6">
      <div className="flex items-center gap-3 mb-4">
        <div className="w-14 h-14 rounded-full bg-primary flex items-center justify-center">
          <Sprout className="w-8 h-8 text-primary-foreground" />
        </div>
        <h1 className="text-3xl font-black text-foreground">AgriSense</h1>
      </div>
      <p className="text-muted-foreground mb-8 text-lg">🌾 Smart Farming Intelligence</p>

      <p className="text-foreground font-semibold text-xl mb-6">Select Your Language / अपनी भाषा चुनें</p>

      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-3 max-w-2xl w-full mb-8">
        {LANGUAGES.map((l) => (
          <button
            key={l.code}
            onClick={() => setLang(l.code)}
            className={`rounded-2xl p-4 text-center transition-all duration-200 border-2 ${
              lang === l.code
                ? 'border-primary bg-primary text-primary-foreground shadow-lg scale-105'
                : 'border-border bg-card text-foreground hover:border-primary/50 hover:shadow-md'
            }`}
          >
            <div className="text-lg font-bold">{l.nativeName}</div>
            <div className={`text-xs mt-1 ${lang === l.code ? 'text-primary-foreground/80' : 'text-muted-foreground'}`}>{l.name}</div>
          </button>
        ))}
      </div>

      <button
        onClick={onComplete}
        className="bg-primary text-primary-foreground font-bold text-lg px-10 py-4 rounded-2xl shadow-lg hover:shadow-xl transition-all active:scale-95"
      >
        {lang === 'en' ? 'Get Started →' : '→ शुरू करें'}
      </button>
    </div>
  );
}
