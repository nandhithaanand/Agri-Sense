import React, { useMemo } from 'react';
import { useLanguage } from '@/hooks/useLanguage';
import { useSpeechSynthesis } from '@/hooks/useSpeech';
import { t } from '@/lib/languages';
import { generateMockWeather, generateAdvisory, type Advisory } from '@/lib/advisoryEngine';
import { type FarmData } from '@/components/OnboardingForm';
import { Thermometer, Droplets, CloudRain, Volume2, VolumeX, AlertTriangle, CheckCircle, Info } from 'lucide-react';

interface Props {
  farmData: FarmData;
}

export default function DashboardTab({ farmData }: Props) {
  const { lang } = useLanguage();
  const { isSpeaking, speak, stop } = useSpeechSynthesis(lang);

  const weather = useMemo(() => generateMockWeather(), []);
  const advisories = useMemo(() => generateAdvisory(weather, farmData.soilMoisture), [weather, farmData.soilMoisture]);

  const playAdvisory = () => {
    const text = advisories.map(a => t(lang, a.message as any)).join('. ');
    speak(text);
  };

  const iconForType = (type: Advisory['type']) => {
    switch (type) {
      case 'danger': return <AlertTriangle className="w-5 h-5 text-destructive" />;
      case 'warning': return <AlertTriangle className="w-5 h-5 text-warning" />;
      case 'success': return <CheckCircle className="w-5 h-5 text-success" />;
      default: return <Info className="w-5 h-5 text-sky" />;
    }
  };

  const bgForType = (type: Advisory['type']) => {
    switch (type) {
      case 'danger': return 'border-destructive/30 bg-destructive/5';
      case 'warning': return 'border-warning/30 bg-warning/5';
      case 'success': return 'border-success/30 bg-success/5';
      default: return 'border-sky/30 bg-sky/5';
    }
  };

  return (
    <div className="space-y-4">
      {/* Farm summary */}
      <div className="agri-card">
        <h3 className="font-bold text-foreground mb-2">{t(lang, 'farmProfile')}</h3>
        <div className="grid grid-cols-2 gap-2 text-sm">
          <div><span className="text-muted-foreground">{t(lang, 'location')}:</span> <span className="font-semibold text-foreground">{farmData.location}</span></div>
          <div><span className="text-muted-foreground">{t(lang, 'crop')}:</span> <span className="font-semibold text-foreground">{t(lang, farmData.crop.toLowerCase() as any)}</span></div>
          <div><span className="text-muted-foreground">{t(lang, 'landSize')}:</span> <span className="font-semibold text-foreground">{farmData.landSize} {t(lang, 'acres')}</span></div>
          <div><span className="text-muted-foreground">{t(lang, 'soilMoisture')}:</span> <span className="font-semibold text-foreground">{farmData.soilMoisture}{t(lang, 'percent')}</span></div>
        </div>
      </div>

      {/* Weather */}
      <div className="agri-card">
        <h3 className="font-bold text-foreground mb-3">{t(lang, 'weatherAdvisory')}</h3>
        <div className="grid grid-cols-3 gap-3">
          <div className="flex flex-col items-center p-3 bg-muted rounded-2xl">
            <Thermometer className="w-6 h-6 text-destructive mb-1" />
            <span className="text-xl font-black text-foreground">{weather.temperature}°C</span>
            <span className="text-xs text-muted-foreground">{t(lang, 'temperature')}</span>
          </div>
          <div className="flex flex-col items-center p-3 bg-muted rounded-2xl">
            <Droplets className="w-6 h-6 text-sky mb-1" />
            <span className="text-xl font-black text-foreground">{weather.humidity}%</span>
            <span className="text-xs text-muted-foreground">{t(lang, 'humidity')}</span>
          </div>
          <div className="flex flex-col items-center p-3 bg-muted rounded-2xl">
            <CloudRain className="w-6 h-6 text-sky mb-1" />
            <span className="text-xl font-black text-foreground">{weather.rainfall}mm</span>
            <span className="text-xs text-muted-foreground">{t(lang, 'rainfall')}</span>
          </div>
        </div>
      </div>

      {/* Advisories */}
      <div className="space-y-2">
        {advisories.map(a => (
          <div key={a.key} className={`p-4 rounded-2xl border-2 flex items-start gap-3 ${bgForType(a.type)}`}>
            {iconForType(a.type)}
            <p className="text-sm font-medium text-foreground flex-1">{t(lang, a.message as any)}</p>
          </div>
        ))}
      </div>

      {/* Play audio button */}
      <button
        onClick={isSpeaking ? stop : playAdvisory}
        className="w-full py-4 rounded-2xl font-bold flex items-center justify-center gap-2 transition-all active:scale-95 bg-secondary text-secondary-foreground shadow-md"
      >
        {isSpeaking ? <><VolumeX className="w-5 h-5" /> {t(lang, 'stopAudio')}</> : <><Volume2 className="w-5 h-5" /> {t(lang, 'playAudio')}</>}
      </button>
    </div>
  );
}
