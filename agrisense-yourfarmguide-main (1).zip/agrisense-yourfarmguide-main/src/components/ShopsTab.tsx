import React, { useEffect, useRef } from 'react';
import { useLanguage } from '@/hooks/useLanguage';
import { t } from '@/lib/languages';
import { getMockShops } from '@/lib/advisoryEngine';
import { MapPin, Phone, Package, Navigation } from 'lucide-react';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';

export default function ShopsTab() {
  const { lang } = useLanguage();
  const shops = getMockShops();
  const mapRef = useRef<HTMLDivElement>(null);
  const mapInstanceRef = useRef<L.Map | null>(null);

  useEffect(() => {
    if (!mapRef.current || mapInstanceRef.current) return;

    const map = L.map(mapRef.current).setView([11.0168, 76.9558], 13);
    mapInstanceRef.current = map;

    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      attribution: '© OpenStreetMap',
    }).addTo(map);

    const shopIcon = L.divIcon({
      html: '<div style="background:#16a34a;color:white;border-radius:50%;width:32px;height:32px;display:flex;align-items:center;justify-content:center;font-size:16px;border:2px solid white;box-shadow:0 2px 8px rgba(0,0,0,0.3);">🏪</div>',
      iconSize: [32, 32],
      className: '',
    });

    shops.forEach(shop => {
      if (shop.lat && shop.lng) {
        L.marker([shop.lat, shop.lng], { icon: shopIcon })
          .addTo(map)
          .bindPopup(`<b>${shop.name}</b><br>${shop.type}<br>📞 ${shop.phone}`);
      }
    });

    return () => {
      map.remove();
      mapInstanceRef.current = null;
    };
  }, []);

  const openDirections = (lat: number, lng: number) => {
    window.open(`https://www.google.com/maps/dir/?api=1&destination=${lat},${lng}`, '_blank');
  };

  return (
    <div className="space-y-4">
      <div className="agri-card text-center">
        <MapPin className="w-10 h-10 mx-auto text-secondary mb-2" />
        <h3 className="font-bold text-lg text-foreground">{t(lang, 'nearbyShops')}</h3>
      </div>

      <div ref={mapRef} className="rounded-3xl overflow-hidden h-56 shadow-lg z-0" />

      {shops.map((shop, i) => (
        <div key={i} className="agri-card">
          <div className="flex items-start justify-between mb-2">
            <div>
              <h4 className="font-bold text-foreground">{shop.name}</h4>
              <p className="text-xs text-muted-foreground">{shop.type} • {shop.distance}</p>
            </div>
            <div className="flex gap-1">
              <a
                href={`tel:${shop.phone}`}
                className="bg-primary text-primary-foreground px-3 py-2 rounded-xl text-xs font-bold flex items-center gap-1 active:scale-95 transition-all"
              >
                <Phone className="w-3 h-3" /> {t(lang, 'callNow')}
              </a>
              {shop.lat && shop.lng && (
                <button
                  onClick={() => openDirections(shop.lat!, shop.lng!)}
                  className="bg-secondary text-secondary-foreground px-3 py-2 rounded-xl text-xs font-bold flex items-center gap-1 active:scale-95 transition-all"
                >
                  <Navigation className="w-3 h-3" /> {t(lang, 'getDirections')}
                </button>
              )}
            </div>
          </div>
          <div className="flex flex-wrap gap-1 mt-2">
            {shop.products.map(p => (
              <span key={p} className="bg-accent text-accent-foreground text-xs px-2 py-1 rounded-lg font-medium flex items-center gap-1">
                <Package className="w-3 h-3" /> {p}
              </span>
            ))}
          </div>
        </div>
      ))}
    </div>
  );
}
