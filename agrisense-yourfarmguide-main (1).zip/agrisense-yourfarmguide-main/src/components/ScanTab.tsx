import React, { useState, useRef } from 'react';
import { useLanguage } from '@/hooks/useLanguage';
import { t } from '@/lib/languages';
import { simulatePestDetection, type PestResult } from '@/lib/advisoryEngine';
import { Upload, Leaf, Bug } from 'lucide-react';

// Localized pest results
const LOCALIZED_DISEASES: Record<string, { disease: string; treatment: string; dosage: string; timing: string }[]> = {
  en: [
    { disease: 'Late Blight', treatment: 'Mancozeb 75% WP', dosage: '2.5g/L water', timing: 'Spray every 7 days' },
    { disease: 'Powdery Mildew', treatment: 'Sulphur 80% WP', dosage: '3g/L water', timing: 'Spray every 10 days' },
    { disease: 'Leaf Spot', treatment: 'Carbendazim 50% WP', dosage: '1g/L water', timing: 'Spray every 14 days' },
    { disease: 'Bacterial Wilt', treatment: 'Copper Oxychloride', dosage: '3g/L water', timing: 'Drench soil weekly' },
  ],
  hi: [
    { disease: 'झुलसा रोग', treatment: 'मैंकोजेब 75% WP', dosage: '2.5 ग्राम/लीटर पानी', timing: 'हर 7 दिन छिड़काव' },
    { disease: 'चूर्णी फफूंदी', treatment: 'सल्फर 80% WP', dosage: '3 ग्राम/लीटर पानी', timing: 'हर 10 दिन छिड़काव' },
    { disease: 'पत्ती धब्बा रोग', treatment: 'कार्बेंडाजिम 50% WP', dosage: '1 ग्राम/लीटर पानी', timing: 'हर 14 दिन छिड़काव' },
    { disease: 'जीवाणु म्लानि', treatment: 'कॉपर ऑक्सीक्लोराइड', dosage: '3 ग्राम/लीटर पानी', timing: 'हर सप्ताह मिट्टी में डालें' },
  ],
  ta: [
    { disease: 'கருகல் நோய்', treatment: 'மான்கோசெப் 75% WP', dosage: '2.5 கிராம்/லிட்டர் தண்ணீர்', timing: 'ஒவ்வொரு 7 நாளும் தெளிக்கவும்' },
    { disease: 'பொடி பூஞ்சை', treatment: 'கந்தகம் 80% WP', dosage: '3 கிராம்/லிட்டர் தண்ணீர்', timing: 'ஒவ்வொரு 10 நாளும் தெளிக்கவும்' },
    { disease: 'இலைப் புள்ளி நோய்', treatment: 'கார்பெண்டாசிம் 50% WP', dosage: '1 கிராம்/லிட்டர் தண்ணீர்', timing: 'ஒவ்வொரு 14 நாளும் தெளிக்கவும்' },
    { disease: 'பாக்டீரியா வாடல்', treatment: 'காப்பர் ஆக்சிகுளோரைடு', dosage: '3 கிராம்/லிட்டர் தண்ணீர்', timing: 'வாரம் ஒருமுறை மண்ணில் ஊற்றவும்' },
  ],
  te: [
    { disease: 'ఆలస్య కాలుష్యం', treatment: 'మాన్కోజెబ్ 75% WP', dosage: '2.5 గ్రాం/లీటర్ నీరు', timing: 'ప్రతి 7 రోజులకు పిచికారీ' },
    { disease: 'పొడి బూజు', treatment: 'సల్ఫర్ 80% WP', dosage: '3 గ్రాం/లీటర్ నీరు', timing: 'ప్రతి 10 రోజులకు పిచికారీ' },
    { disease: 'ఆకు మచ్చ వ్యాధి', treatment: 'కార్బెండజిమ్ 50% WP', dosage: '1 గ్రాం/లీటర్ నీరు', timing: 'ప్రతి 14 రోజులకు పిచికారీ' },
    { disease: 'బ్యాక్టీరియా వాడు', treatment: 'కాపర్ ఆక్సీక్లోరైడ్', dosage: '3 గ్రాం/లీటర్ నీరు', timing: 'వారానికి ఒకసారి మట్టిలో పోయండి' },
  ],
  ml: [
    { disease: 'വൈകിയ ബ്ലൈറ്റ്', treatment: 'മാൻകോസെബ് 75% WP', dosage: '2.5 ഗ്രാം/ലിറ്റർ വെള്ളം', timing: 'ഓരോ 7 ദിവസവും തളിക്കുക' },
    { disease: 'പൊടിപ്പൂപ്പ്', treatment: 'സൾഫർ 80% WP', dosage: '3 ഗ്രാം/ലിറ്റർ വെള്ളം', timing: 'ഓരോ 10 ദിവസവും തളിക്കുക' },
    { disease: 'ഇലപ്പുള്ളി രോഗം', treatment: 'കാർബൻഡാസിം 50% WP', dosage: '1 ഗ്രാം/ലിറ്റർ വെള്ളം', timing: 'ഓരോ 14 ദിവസവും തളിക്കുക' },
    { disease: 'ബാക്ടീരിയ വാട്ടം', treatment: 'കോപ്പർ ഓക്സിക്ലോറൈഡ്', dosage: '3 ഗ്രാം/ലിറ്റർ വെള്ളം', timing: 'ആഴ്ചയിൽ ഒരിക്കൽ മണ്ണിൽ ഒഴിക്കുക' },
  ],
  kn: [
    { disease: 'ತಡ ಕೊಳೆ ರೋಗ', treatment: 'ಮ್ಯಾಂಕೋಜೆಬ್ 75% WP', dosage: '2.5 ಗ್ರಾಂ/ಲೀಟರ್ ನೀರು', timing: 'ಪ್ರತಿ 7 ದಿನಗಳಿಗೆ ಸಿಂಪಡಿಸಿ' },
    { disease: 'ಬೂದಿ ರೋಗ', treatment: 'ಗಂಧಕ 80% WP', dosage: '3 ಗ್ರಾಂ/ಲೀಟರ್ ನೀರು', timing: 'ಪ್ರತಿ 10 ದಿನಗಳಿಗೆ ಸಿಂಪಡಿಸಿ' },
    { disease: 'ಎಲೆ ಕಲೆ ರೋಗ', treatment: 'ಕಾರ್ಬೆಂಡಾಜಿಮ್ 50% WP', dosage: '1 ಗ್ರಾಂ/ಲೀಟರ್ ನೀರು', timing: 'ಪ್ರತಿ 14 ದಿನಗಳಿಗೆ ಸಿಂಪಡಿಸಿ' },
    { disease: 'ಬ್ಯಾಕ್ಟೀರಿಯಾ ಬಾಡುವಿಕೆ', treatment: 'ಕಾಪರ್ ಆಕ್ಸಿಕ್ಲೋರೈಡ್', dosage: '3 ಗ್ರಾಂ/ಲೀಟರ್ ನೀರು', timing: 'ವಾರಕ್ಕೆ ಒಮ್ಮೆ ಮಣ್ಣಿಗೆ ಹಾಕಿ' },
  ],
  mr: [
    { disease: 'उशीरा करपा', treatment: 'मॅन्कोझेब 75% WP', dosage: '2.5 ग्रॅम/लिटर पाणी', timing: 'दर 7 दिवसांनी फवारणी' },
    { disease: 'भुरी', treatment: 'सल्फर 80% WP', dosage: '3 ग्रॅम/लिटर पाणी', timing: 'दर 10 दिवसांनी फवारणी' },
    { disease: 'पानावरील ठिपके', treatment: 'कार्बेंडाझिम 50% WP', dosage: '1 ग्रॅम/लिटर पाणी', timing: 'दर 14 दिवसांनी फवारणी' },
    { disease: 'जिवाणूजन्य मर', treatment: 'कॉपर ऑक्सिक्लोराईड', dosage: '3 ग्रॅम/लिटर पाणी', timing: 'दर आठवड्याला मातीत टाका' },
  ],
  pa: [
    { disease: 'ਝੁਲਸ ਰੋਗ', treatment: 'ਮੈਂਕੋਜ਼ੇਬ 75% WP', dosage: '2.5 ਗ੍ਰਾਮ/ਲੀਟਰ ਪਾਣੀ', timing: 'ਹਰ 7 ਦਿਨ ਛਿੜਕਾਅ' },
    { disease: 'ਧੂੜ ਉੱਲੀ', treatment: 'ਸਲਫ਼ਰ 80% WP', dosage: '3 ਗ੍ਰਾਮ/ਲੀਟਰ ਪਾਣੀ', timing: 'ਹਰ 10 ਦਿਨ ਛਿੜਕਾਅ' },
    { disease: 'ਪੱਤੇ ਦਾ ਧੱਬਾ', treatment: 'ਕਾਰਬੈਂਡਾਜ਼ਿਮ 50% WP', dosage: '1 ਗ੍ਰਾਮ/ਲੀਟਰ ਪਾਣੀ', timing: 'ਹਰ 14 ਦਿਨ ਛਿੜਕਾਅ' },
    { disease: 'ਬੈਕਟੀਰੀਅਲ ਮੁਰਝਾਣਾ', treatment: 'ਕਾਪਰ ਆਕਸੀਕਲੋਰਾਈਡ', dosage: '3 ਗ੍ਰਾਮ/ਲੀਟਰ ਪਾਣੀ', timing: 'ਹਰ ਹਫ਼ਤੇ ਮਿੱਟੀ ਵਿੱਚ ਪਾਓ' },
  ],
  bn: [
    { disease: 'বিলম্বিত ব্লাইট', treatment: 'ম্যানকোজেব 75% WP', dosage: '2.5 গ্রাম/লিটার জল', timing: 'প্রতি 7 দিন স্প্রে করুন' },
    { disease: 'পাউডারি মিলডিউ', treatment: 'সালফার 80% WP', dosage: '3 গ্রাম/লিটার জল', timing: 'প্রতি 10 দিন স্প্রে করুন' },
    { disease: 'পাতার দাগ', treatment: 'কার্বেন্ডাজিম 50% WP', dosage: '1 গ্রাম/লিটার জল', timing: 'প্রতি 14 দিন স্প্রে করুন' },
    { disease: 'ব্যাকটেরিয়াল উইল্ট', treatment: 'কপার অক্সিক্লোরাইড', dosage: '3 গ্রাম/লিটার জল', timing: 'সাপ্তাহিক মাটিতে দিন' },
  ],
  ur: [
    { disease: 'دیر سے جھلسا', treatment: 'مینکوزیب 75% WP', dosage: '2.5 گرام/لیٹر پانی', timing: 'ہر 7 دن چھڑکاؤ' },
    { disease: 'پاؤڈری مائلڈیو', treatment: 'سلفر 80% WP', dosage: '3 گرام/لیٹر پانی', timing: 'ہر 10 دن چھڑکاؤ' },
    { disease: 'پتوں کے داغ', treatment: 'کاربینڈازم 50% WP', dosage: '1 گرام/لیٹر پانی', timing: 'ہر 14 دن چھڑکاؤ' },
    { disease: 'بیکٹیریل مرجھاؤ', treatment: 'کاپر آکسی کلورائیڈ', dosage: '3 گرام/لیٹر پانی', timing: 'ہفتہ وار مٹی میں ڈالیں' },
  ],
};

function getLocalizedPestResult(lang: string): PestResult & { localDisease: string; localTreatment: string; localDosage: string; localTiming: string } {
  const diseases = LOCALIZED_DISEASES[lang] || LOCALIZED_DISEASES.en;
  const enDiseases = LOCALIZED_DISEASES.en;
  const idx = Math.floor(Math.random() * diseases.length);
  const pick = diseases[idx];
  const enPick = enDiseases[idx];
  return {
    disease: enPick.disease,
    confidence: 85 + Math.floor(Math.random() * 12),
    treatment: enPick.treatment,
    dosage: enPick.dosage,
    timing: enPick.timing,
    localDisease: pick.disease,
    localTreatment: pick.treatment,
    localDosage: pick.dosage,
    localTiming: pick.timing,
  };
}

export default function ScanTab() {
  const { lang } = useLanguage();
  const [scanning, setScanning] = useState(false);
  const [result, setResult] = useState<ReturnType<typeof getLocalizedPestResult> | null>(null);
  const [imageUrl, setImageUrl] = useState<string | null>(null);
  const fileRef = useRef<HTMLInputElement>(null);

  const handleFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setImageUrl(URL.createObjectURL(file));
    setScanning(true);
    setResult(null);
    setTimeout(() => {
      setResult(getLocalizedPestResult(lang));
      setScanning(false);
    }, 2500);
  };

  return (
    <div className="space-y-4">
      <div className="agri-card text-center">
        <Bug className="w-10 h-10 mx-auto text-primary mb-2" />
        <h3 className="font-bold text-lg text-foreground">{t(lang, 'pestDetection')}</h3>
        <p className="text-sm text-muted-foreground mt-1">{t(lang, 'uploadLeaf')}</p>
      </div>

      <input ref={fileRef} type="file" accept="image/*" capture="environment" onChange={handleFile} className="hidden" />

      <button
        onClick={() => fileRef.current?.click()}
        className="w-full py-12 border-2 border-dashed border-primary/40 rounded-3xl flex flex-col items-center gap-3 bg-accent/30 hover:bg-accent/50 transition-all active:scale-95"
      >
        <Upload className="w-10 h-10 text-primary" />
        <span className="text-foreground font-semibold">{t(lang, 'uploadLeaf')}</span>
      </button>

      {imageUrl && (
        <div className="relative rounded-2xl overflow-hidden">
          <img src={imageUrl} alt="Leaf" className="w-full h-48 object-cover rounded-2xl" />
          {scanning && (
            <div className="absolute inset-0 bg-foreground/20 flex items-center justify-center">
              <div className="absolute top-0 left-0 right-0 h-1 bg-primary animate-scan-line" />
              <span className="text-primary-foreground font-bold text-lg bg-foreground/60 px-4 py-2 rounded-xl">{t(lang, 'scanning')}</span>
            </div>
          )}
        </div>
      )}

      {result && (
        <div className="agri-card border-2 border-destructive/30">
          <div className="flex items-center gap-2 mb-3">
            <Leaf className="w-5 h-5 text-destructive" />
            <h4 className="font-bold text-foreground">{t(lang, 'diseaseDetected')}</h4>
          </div>
          <div className="space-y-2 text-sm">
            <div className="flex justify-between p-2 bg-destructive/5 rounded-xl">
              <span className="text-muted-foreground">🦠 {t(lang, 'diseaseDetected')}</span>
              <span className="font-bold text-foreground">{result.localDisease} ({result.confidence}%)</span>
            </div>
            <div className="flex justify-between p-2 bg-muted rounded-xl">
              <span className="text-muted-foreground">💊 {t(lang, 'treatment')}</span>
              <span className="font-semibold text-foreground">{result.localTreatment}</span>
            </div>
            <div className="flex justify-between p-2 bg-muted rounded-xl">
              <span className="text-muted-foreground">📏 {t(lang, 'dosage')}</span>
              <span className="font-semibold text-foreground">{result.localDosage}</span>
            </div>
            <div className="flex justify-between p-2 bg-muted rounded-xl">
              <span className="text-muted-foreground">⏰ {t(lang, 'timing')}</span>
              <span className="font-semibold text-foreground">{result.localTiming}</span>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
