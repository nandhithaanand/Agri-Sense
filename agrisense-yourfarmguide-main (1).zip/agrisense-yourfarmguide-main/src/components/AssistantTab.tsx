import React, { useState, useRef, useEffect } from 'react';
import { useLanguage } from '@/hooks/useLanguage';
import { useSpeechRecognition, useSpeechSynthesis } from '@/hooks/useSpeech';
import { t } from '@/lib/languages';
import { getAssistantResponse } from '@/lib/advisoryEngine';
import { Mic, MicOff, Send, Bot, User } from 'lucide-react';

interface Message {
  role: 'user' | 'assistant';
  text: string;
}

export default function AssistantTab() {
  const { lang } = useLanguage();
  const { isListening, transcript, startListening, stopListening, setTranscript } = useSpeechRecognition(lang);
  const { speak } = useSpeechSynthesis(lang);
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const [thinking, setThinking] = useState(false);
  const bottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, thinking]);

  // Handle speech transcript
  useEffect(() => {
    if (transcript) {
      handleSend(transcript);
      setTranscript('');
    }
  }, [transcript]);

  const handleSend = (text?: string) => {
    const msg = text || input;
    if (!msg.trim()) return;
    setInput('');
    setMessages(prev => [...prev, { role: 'user', text: msg }]);
    setThinking(true);

    setTimeout(() => {
      const response = getAssistantResponse(msg, lang);
      setMessages(prev => [...prev, { role: 'assistant', text: response }]);
      setThinking(false);
      speak(response);
    }, 1200);
  };

  return (
    <div className="flex flex-col h-[calc(100vh-13rem)]">
      <div className="agri-card text-center mb-3">
        <Bot className="w-8 h-8 mx-auto text-primary mb-1" />
        <h3 className="font-bold text-foreground">{t(lang, 'voiceAssistant')}</h3>
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto space-y-3 mb-3 px-1">
        {messages.length === 0 && (
          <p className="text-center text-muted-foreground text-sm mt-10">{t(lang, 'askQuestion')}</p>
        )}
        {messages.map((m, i) => (
          <div key={i} className={`flex items-start gap-2 ${m.role === 'user' ? 'flex-row-reverse' : ''}`}>
            <div className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 ${
              m.role === 'user' ? 'bg-secondary' : 'bg-primary'
            }`}>
              {m.role === 'user' ? <User className="w-4 h-4 text-secondary-foreground" /> : <Bot className="w-4 h-4 text-primary-foreground" />}
            </div>
            <div className={`max-w-[80%] px-4 py-3 rounded-2xl text-sm ${
              m.role === 'user' ? 'bg-secondary text-secondary-foreground rounded-tr-sm' : 'bg-card border border-border text-foreground rounded-tl-sm'
            }`}>
              {m.text}
            </div>
          </div>
        ))}
        {thinking && (
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-full bg-primary flex items-center justify-center">
              <Bot className="w-4 h-4 text-primary-foreground" />
            </div>
            <div className="bg-card border border-border px-4 py-3 rounded-2xl rounded-tl-sm">
              <span className="text-sm text-muted-foreground animate-pulse">{t(lang, 'thinking')}</span>
            </div>
          </div>
        )}
        <div ref={bottomRef} />
      </div>

      {/* Input area */}
      <div className="flex gap-2">
        <button
          onClick={isListening ? stopListening : startListening}
          className={`w-12 h-12 rounded-2xl flex items-center justify-center flex-shrink-0 transition-all ${
            isListening ? 'bg-destructive mic-pulse' : 'bg-primary'
          }`}
        >
          {isListening ? <MicOff className="w-5 h-5 text-destructive-foreground" /> : <Mic className="w-5 h-5 text-primary-foreground" />}
        </button>
        <input
          value={input}
          onChange={e => setInput(e.target.value)}
          onKeyDown={e => e.key === 'Enter' && handleSend()}
          className="flex-1 px-4 py-3 rounded-2xl bg-card border border-border text-foreground text-sm focus:ring-2 focus:ring-primary outline-none"
          placeholder={t(lang, 'askQuestion')}
        />
        <button onClick={() => handleSend()} className="w-12 h-12 rounded-2xl bg-primary flex items-center justify-center flex-shrink-0 active:scale-95 transition-all">
          <Send className="w-5 h-5 text-primary-foreground" />
        </button>
      </div>
    </div>
  );
}
