import React, { useState, useMemo } from 'react';
import { useLanguage } from '@/hooks/useLanguage';
import { t } from '@/lib/languages';
import { useSpeechSynthesis } from '@/hooks/useSpeech';
import { type FarmData } from '@/components/OnboardingForm';
import { Droplets, Wind, Cloud, Thermometer, Volume2, VolumeX } from 'lucide-react';

interface Props {
  farmData: FarmData;
}

interface AdvisoryInput {
  temperature: number;
  humidity: number;
  windSpeed: number;
  chanceOfRain: number;
  soilType: string;
  crop: string;
  cropStage: string;
  ndviHealth: string;
}

function generateAdvisory(input: AdvisoryInput, lang: string): Record<string, string> {
  const { temperature, humidity, windSpeed, chanceOfRain, soilType, crop, cropStage, ndviHealth } = input;

  // Localized advisory generation
  const advisoryData: Record<string, Record<string, string>> = {
    en: {
      irrigationDecision: '',
      irrigationMethod: '',
      soilAdvice: '',
      cropStageAdvice: '',
      ndviWarning: '',
      mulchingTip: '',
      farmPractice: '',
      waterSaved: '',
    },
    // We'll generate in English logic then use translation keys
  };

  // 1. Irrigation Decision
  let irrigationDecision = '';
  let skipCount = 0;
  if (chanceOfRain > 60) { irrigationDecision = getLocalText(lang, 'skipRain'); skipCount++; }
  else if (humidity > 75 && temperature < 30) { irrigationDecision = getLocalText(lang, 'skipHumid'); skipCount++; }
  else if (windSpeed > 25) { irrigationDecision = getLocalText(lang, 'delayWind'); }
  else if (soilType === 'clay' && humidity > 70) { irrigationDecision = getLocalText(lang, 'skipClay'); skipCount++; }
  else if (soilType === 'sandy' && temperature > 32) { irrigationDecision = getLocalText(lang, 'lightMorning'); }
  else if (temperature > 35) { irrigationDecision = getLocalText(lang, 'earlyIrrigation'); }
  else { irrigationDecision = getLocalText(lang, 'normalIrrigation'); }

  // 2. Irrigation Method by Crop
  const methodMap: Record<string, string> = {
    paddy: 'methodPaddy', sugarcane: 'methodSugarcane', banana: 'methodBanana',
    vegetables: 'methodVegetables', cotton: 'methodCotton',
  };
  const irrigationMethod = getLocalText(lang, methodMap[crop] || 'methodPaddy');

  // 3. Soil Practice
  const soilMap: Record<string, string> = {
    sandy: 'soilSandy', clay: 'soilClay', loamy: 'soilLoamy',
  };
  const soilAdvice = getLocalText(lang, soilMap[soilType] || 'soilLoamy');

  // 4. Crop Stage Practice
  const stageMap: Record<string, string> = {
    seedling: 'stageSeedling', vegetative: 'stageVegetative',
    flowering: 'stageFlowering', harvest: 'stageHarvest',
  };
  const cropStageAdvice = getLocalText(lang, stageMap[cropStage] || 'stageSeedling');

  // 5. NDVI Warning
  const ndviMap: Record<string, string> = {
    green: 'ndviGreen', yellow: 'ndviYellow', red: 'ndviRed',
  };
  const ndviWarning = getLocalText(lang, ndviMap[ndviHealth] || 'ndviGreen');

  // 6. Mulching Tip
  let mulchingTip = getLocalText(lang, 'noMulchNeeded');
  if (temperature > 33) mulchingTip = getLocalText(lang, 'mulchHot');
  if (crop === 'vegetables' && temperature > 32) mulchingTip = getLocalText(lang, 'mulchVeg');

  // 7. Today's Farm Practice
  let farmPractice = getLocalText(lang, 'practiceNormal');
  if (chanceOfRain > 60) farmPractice = getLocalText(lang, 'practiceRain');
  else if (temperature > 35) farmPractice = getLocalText(lang, 'practiceHot');
  else if (humidity < 40) farmPractice = getLocalText(lang, 'practiceDry');
  else if (windSpeed > 25) farmPractice = getLocalText(lang, 'practiceWindy');

  // 8. Water Saved
  let waterSaved = 0;
  waterSaved += skipCount * 200;
  if (crop !== 'paddy') waterSaved += 150; // drip suggestion
  if (temperature > 33) waterSaved += 150; // mulch suggestion

  return {
    irrigationDecision,
    irrigationMethod,
    soilAdvice,
    cropStageAdvice,
    ndviWarning,
    mulchingTip,
    farmPractice,
    waterSaved: `${waterSaved} ${getLocalText(lang, 'liters')}`,
  };
}

// Localized text for advisory
function getLocalText(lang: string, key: string): string {
  const texts: Record<string, Record<string, string>> = {
    en: {
      skipRain: 'Skip irrigation today. Rain expected (>60% chance). Save water.',
      skipHumid: 'Skip irrigation. High humidity and moderate temperature — soil has enough moisture.',
      delayWind: 'Delay irrigation. High wind speed will waste water through evaporation.',
      skipClay: 'Skip irrigation. Clay soil retains moisture well in high humidity.',
      lightMorning: 'Light irrigation early morning only. Sandy soil dries fast in heat.',
      earlyIrrigation: 'Irrigate before 9 AM. Temperature is very high — avoid midday watering.',
      normalIrrigation: 'Normal irrigation schedule today. Conditions are balanced.',
      methodPaddy: 'Use Alternate Wetting and Drying (AWD). Do not keep field flooded continuously.',
      methodSugarcane: 'Use drip irrigation. Saves up to 50% water compared to flood irrigation.',
      methodBanana: 'Use basin irrigation with mulch cover to reduce evaporation.',
      methodVegetables: 'Use drip or sprinkler irrigation. Light, frequent watering is best.',
      methodCotton: 'Use alternate furrow irrigation to save water.',
      soilSandy: 'Sandy soil: Apply small amounts of water frequently. Add organic matter to improve retention.',
      soilClay: 'Clay soil: Avoid over-irrigation. Check soil moisture before watering.',
      soilLoamy: 'Loamy soil: Normal irrigation schedule is suitable. Good water retention.',
      stageSeedling: 'Seedling stage: Light irrigation only. Protect young roots from waterlogging.',
      stageVegetative: 'Vegetative stage: Remove weeds, maintain proper spacing. Regular watering needed.',
      stageFlowering: 'Flowering stage: Critical water period! Do NOT skip irrigation now.',
      stageHarvest: 'Harvest stage: Stop irrigation. Let the crop dry for proper harvesting.',
      ndviGreen: 'Crop health is normal (Green). Continue regular care.',
      ndviYellow: 'Mild stress detected (Yellow). Check soil moisture and irrigate if dry.',
      ndviRed: 'HIGH STRESS detected (Red)! Irrigate immediately. Check for pest/disease too.',
      noMulchNeeded: 'No mulching needed currently. Temperature is moderate.',
      mulchHot: 'Apply straw or dry leaf mulch around plants to reduce soil evaporation.',
      mulchVeg: 'STRONGLY recommended: Apply thick mulch layer on vegetable beds. Hot weather causes rapid moisture loss.',
      practiceNormal: 'Continue regular farm maintenance. Monitor crop health daily.',
      practiceRain: 'Rain expected — do not irrigate. Prepare drainage channels.',
      practiceHot: 'Very hot day — irrigate early morning only. Provide shade if possible.',
      practiceDry: 'Low humidity — check soil moisture in the evening. Plants may wilt.',
      practiceWindy: 'Windy conditions — avoid sprinkler irrigation. Use drip instead.',
      liters: 'liters saved today',
    },
    hi: {
      skipRain: 'आज सिंचाई छोड़ दें। बारिश की संभावना (>60%) है। पानी बचाएं।',
      skipHumid: 'सिंचाई छोड़ दें। उच्च नमी और मध्यम तापमान — मिट्टी में पर्याप्त नमी है।',
      delayWind: 'सिंचाई में देरी करें। तेज हवा से पानी भाप बनकर उड़ जाएगा।',
      skipClay: 'सिंचाई छोड़ दें। चिकनी मिट्टी उच्च नमी में पानी अच्छे से रोकती है।',
      lightMorning: 'केवल सुबह जल्दी हल्की सिंचाई करें। रेतीली मिट्टी गर्मी में जल्दी सूखती है।',
      earlyIrrigation: 'सुबह 9 बजे से पहले सिंचाई करें। तापमान बहुत अधिक है।',
      normalIrrigation: 'आज सामान्य सिंचाई करें। स्थिति संतुलित है।',
      methodPaddy: 'बारी-बारी गीला-सूखा (AWD) तरीका अपनाएं। खेत को लगातार डूबा न रखें।',
      methodSugarcane: 'ड्रिप सिंचाई का उपयोग करें। बाढ़ सिंचाई की तुलना में 50% पानी बचता है।',
      methodBanana: 'थाला सिंचाई का उपयोग करें और मल्चिंग से वाष्पीकरण कम करें।',
      methodVegetables: 'ड्रिप या स्प्रिंकलर सिंचाई का उपयोग करें। हल्का, बार-बार पानी देना सबसे अच्छा है।',
      methodCotton: 'पानी बचाने के लिए वैकल्पिक नाली सिंचाई का उपयोग करें।',
      soilSandy: 'रेतीली मिट्टी: थोड़ा-थोड़ा पानी बार-बार दें। जैविक पदार्थ मिलाएं।',
      soilClay: 'चिकनी मिट्टी: अधिक सिंचाई से बचें। पानी देने से पहले मिट्टी की नमी जांचें।',
      soilLoamy: 'दोमट मिट्टी: सामान्य सिंचाई कार्यक्रम उपयुक्त है। अच्छी जल धारण क्षमता।',
      stageSeedling: 'पौध अवस्था: केवल हल्की सिंचाई। जड़ों को जलभराव से बचाएं।',
      stageVegetative: 'वानस्पतिक अवस्था: खरपतवार हटाएं, उचित दूरी बनाए रखें। नियमित पानी दें।',
      stageFlowering: 'फूल आने की अवस्था: महत्वपूर्ण! अभी सिंचाई न छोड़ें।',
      stageHarvest: 'कटाई अवस्था: सिंचाई बंद करें। फसल को सूखने दें।',
      ndviGreen: 'फसल स्वास्थ्य सामान्य (हरा)। नियमित देखभाल जारी रखें।',
      ndviYellow: 'हल्का तनाव (पीला)। मिट्टी की नमी जांचें और सूखी हो तो सिंचाई करें।',
      ndviRed: 'गंभीर तनाव (लाल)! तुरंत सिंचाई करें। कीट/रोग भी जांचें।',
      noMulchNeeded: 'अभी मल्चिंग की जरूरत नहीं। तापमान मध्यम है।',
      mulchHot: 'पौधों के चारों ओर पुआल या सूखी पत्तियों का मल्च लगाएं।',
      mulchVeg: 'अत्यधिक अनुशंसित: सब्जियों की क्यारियों पर मोटी मल्च परत लगाएं।',
      practiceNormal: 'नियमित खेत रखरखाव जारी रखें। फसल स्वास्थ्य रोज देखें।',
      practiceRain: 'बारिश की संभावना — सिंचाई न करें। जल निकासी तैयार रखें।',
      practiceHot: 'बहुत गर्म दिन — केवल सुबह जल्दी सिंचाई करें।',
      practiceDry: 'कम नमी — शाम को मिट्टी की नमी जांचें।',
      practiceWindy: 'तेज हवा — स्प्रिंकलर सिंचाई से बचें। ड्रिप का उपयोग करें।',
      liters: 'लीटर पानी आज बचाया',
    },
    ta: {
      skipRain: 'இன்று பாசனம் தவிர்க்கவும். மழை எதிர்பார்க்கப்படுகிறது (>60%). தண்ணீர் சேமியுங்கள்.',
      skipHumid: 'பாசனம் தவிர்க்கவும். அதிக ஈரப்பதம் — மண்ணில் போதுமான ஈரம் உள்ளது.',
      delayWind: 'பாசனத்தை தாமதிக்கவும். அதிக காற்று வேகம் தண்ணீரை வீணடிக்கும்.',
      skipClay: 'பாசனம் தவிர்க்கவும். களிமண் அதிக ஈரப்பதத்தில் நீரை நன்கு தக்கவைக்கும்.',
      lightMorning: 'காலையில் மட்டும் லேசான பாசனம். மணல் மண் வெப்பத்தில் விரைவாக காயும்.',
      earlyIrrigation: 'காலை 9 மணிக்கு முன் பாசனம் செய்யவும். வெப்பநிலை மிக அதிகம்.',
      normalIrrigation: 'இன்று வழக்கமான பாசனம். நிலைமைகள் சமநிலையில் உள்ளன.',
      methodPaddy: 'மாறி மாறி ஈரம்-உலர்த்தல் (AWD) முறையைப் பயன்படுத்துங்கள்.',
      methodSugarcane: 'சொட்டு நீர்ப்பாசனம் பயன்படுத்துங்கள். 50% தண்ணீர் சேமிக்கும்.',
      methodBanana: 'பேசின் பாசனம் + மல்ச்சிங் பயன்படுத்துங்கள்.',
      methodVegetables: 'சொட்டு அல்லது தெளிப்பு பாசனம் பயன்படுத்துங்கள்.',
      methodCotton: 'தண்ணீர் சேமிக்க மாற்று சால் பாசனம் பயன்படுத்துங்கள்.',
      soilSandy: 'மணல் மண்: சிறிய அளவு தண்ணீர் அடிக்கடி கொடுங்கள்.',
      soilClay: 'களிமண்: அதிக பாசனத்தைத் தவிர்க்கவும். மண் ஈரப்பதம் சோதிக்கவும்.',
      soilLoamy: 'கரிசல் மண்: வழக்கமான பாசன அட்டவணை பொருத்தமானது.',
      stageSeedling: 'நாற்று நிலை: லேசான பாசனம் மட்டும். வேர்களை பாதுகாக்கவும்.',
      stageVegetative: 'வளர்ச்சி நிலை: களையெடுங்கள், தகுந்த இடைவெளி பராமரியுங்கள்.',
      stageFlowering: 'பூக்கும் நிலை: முக்கியமான நீர் காலம்! பாசனம் தவிர்க்காதீர்கள்.',
      stageHarvest: 'அறுவடை நிலை: பாசனம் நிறுத்துங்கள். பயிரை உலரவிடுங்கள்.',
      ndviGreen: 'பயிர் ஆரோக்கியம் இயல்பானது (பச்சை). வழக்கமான பராமரிப்பு தொடரவும்.',
      ndviYellow: 'லேசான அழுத்தம் (மஞ்சள்). மண் ஈரப்பதம் சோதிக்கவும்.',
      ndviRed: 'அதிக அழுத்தம் (சிவப்பு)! உடனடியாக பாசனம் செய்யவும்.',
      noMulchNeeded: 'இப்போது மல்ச்சிங் தேவையில்லை. வெப்பநிலை மிதமானது.',
      mulchHot: 'தாவரங்களைச் சுற்றி வைக்கோல் மல்ச் போடுங்கள்.',
      mulchVeg: 'மிகவும் பரிந்துரைக்கப்படுகிறது: காய்கறிப் படுக்கைகளில் மல்ச் போடுங்கள்.',
      practiceNormal: 'வழக்கமான பண்ணை பராமரிப்பு தொடரவும்.',
      practiceRain: 'மழை எதிர்பார்க்கப்படுகிறது — பாசனம் வேண்டாம்.',
      practiceHot: 'மிகவும் வெப்பமான நாள் — காலையில் மட்டும் பாசனம்.',
      practiceDry: 'குறைந்த ஈரப்பதம் — மாலையில் மண் ஈரப்பதம் சோதிக்கவும்.',
      practiceWindy: 'காற்று அதிகம் — தெளிப்பு பாசனம் தவிர்க்கவும்.',
      liters: 'லிட்டர் தண்ணீர் சேமிக்கப்பட்டது',
    },
    te: {
      skipRain: 'ఈ రోజు నీటిపారుదల వద్దు. వర్షం అంచనా (>60%). నీటిని ఆదా చేయండి.',
      skipHumid: 'నీటిపారుదల వద్దు. అధిక తేమ — మట్టిలో తగినంత నీరు ఉంది.',
      delayWind: 'నీటిపారుదల ఆలస్యం చేయండి. అధిక గాలి వేగం నీటిని వృధా చేస్తుంది.',
      skipClay: 'నీటిపారుదల వద్దు. బంక మట్టి అధిక తేమలో నీటిని బాగా నిలుపుకుంటుంది.',
      lightMorning: 'ఉదయం మాత్రమే తేలికపాటి నీటిపారుదల. ఇసుక మట్టి వేడిలో త్వరగా ఎండిపోతుంది.',
      earlyIrrigation: 'ఉదయం 9 గంటల లోపు నీటిపారుదల చేయండి.',
      normalIrrigation: 'ఈ రోజు సాధారణ నీటిపారుదల. పరిస్థితులు సమతుల్యంగా ఉన్నాయి.',
      methodPaddy: 'ఆల్టర్నేట్ వెటింగ్ అండ్ డ్రైయింగ్ (AWD) ఉపయోగించండి.',
      methodSugarcane: 'డ్రిప్ ఇరిగేషన్ ఉపయోగించండి. 50% నీటిని ఆదా చేస్తుంది.',
      methodBanana: 'బేసిన్ ఇరిగేషన్ + మల్చింగ్ ఉపయోగించండి.',
      methodVegetables: 'డ్రిప్ లేదా స్ప్రింక్లర్ ఇరిగేషన్ ఉపయోగించండి.',
      methodCotton: 'ఆల్టర్నేట్ ఫరో ఇరిగేషన్ ఉపయోగించండి.',
      soilSandy: 'ఇసుక మట్టి: తక్కువ నీరు తరచుగా ఇవ్వండి.',
      soilClay: 'బంక మట్టి: అధిక నీటిపారుదల తగ్గించండి. మట్టి తేమ తనిఖీ చేయండి.',
      soilLoamy: 'గోరు మట్టి: సాధారణ నీటిపారుదల అనువైనది.',
      stageSeedling: 'మొలక దశ: తేలికపాటి నీటిపారుదల మాత్రమే. వేర్లను కాపాడండి.',
      stageVegetative: 'వృద్ధి దశ: కలుపు తీయండి, సరైన దూరం పాటించండి.',
      stageFlowering: 'పూత దశ: కీలకమైన నీటి సమయం! నీటిపారుదల వదలకండి.',
      stageHarvest: 'కోత దశ: నీటిపారుదల ఆపండి. పంటను ఎండనివ్వండి.',
      ndviGreen: 'పంట ఆరోగ్యం సాధారణం (ఆకుపచ్చ).',
      ndviYellow: 'స్వల్ప ఒత్తిడి (పసుపు). మట్టి తేమ తనిఖీ చేయండి.',
      ndviRed: 'తీవ్ర ఒత్తిడి (ఎరుపు)! వెంటనే నీటిపారుదల చేయండి.',
      noMulchNeeded: 'ఇప్పుడు మల్చింగ్ అవసరం లేదు.',
      mulchHot: 'మొక్కల చుట్టూ గడ్డి మల్చ్ వేయండి.',
      mulchVeg: 'అత్యంత సిఫార్సు: కూరగాయల మడులపై మల్చ్ వేయండి.',
      practiceNormal: 'సాధారణ పొలం నిర్వహణ కొనసాగించండి.',
      practiceRain: 'వర్షం అంచనా — నీటిపారుదల వద్దు.',
      practiceHot: 'చాలా వేడి రోజు — ఉదయం మాత్రమే నీటిపారుదల.',
      practiceDry: 'తక్కువ తేమ — సాయంత్రం మట్టి తేమ తనిఖీ చేయండి.',
      practiceWindy: 'గాలి ఎక్కువ — స్ప్రింక్లర్ వాడకండి. డ్రిప్ వాడండి.',
      liters: 'లీటర్లు ఆదా అయింది',
    },
    ml: {
      skipRain: 'ഇന്ന് ജലസേചനം ഒഴിവാക്കുക. മഴ പ്രതീക്ഷിക്കുന്നു (>60%). വെള്ളം ലാഭിക്കുക.',
      skipHumid: 'ജലസേചനം ഒഴിവാക്കുക. ഉയർന്ന ഈർപ്പം — മണ്ണിൽ മതിയായ ഈർപ്പം ഉണ്ട്.',
      delayWind: 'ജലസേചനം വൈകിപ്പിക്കുക. ശക്തമായ കാറ്റ് വെള്ളം പാഴാക്കും.',
      skipClay: 'ജലസേചനം ഒഴിവാക്കുക. കളിമണ്ണ് ഈർപ്പം നന്നായി നിലനിർത്തും.',
      lightMorning: 'രാവിലെ മാത്രം ചെറിയ ജലസേചനം. മണൽ മണ്ണ് ചൂടിൽ വേഗം ഉണങ്ങും.',
      earlyIrrigation: 'രാവിലെ 9 മണിക്ക് മുമ്പ് ജലസേചനം ചെയ്യുക.',
      normalIrrigation: 'ഇന്ന് സാധാരണ ജലസേചനം. സാഹചര്യങ്ങൾ സന്തുലിതമാണ്.',
      methodPaddy: 'ഓൾട്ടർനേറ്റ് വെറ്റിംഗ് ആൻഡ് ഡ്രൈയിംഗ് (AWD) ഉപയോഗിക്കുക.',
      methodSugarcane: 'ഡ്രിപ്പ് ഇറിഗേഷൻ ഉപയോഗിക്കുക. 50% വെള്ളം ലാഭിക്കാം.',
      methodBanana: 'ബേസിൻ ഇറിഗേഷൻ + മൾച്ചിംഗ് ഉപയോഗിക്കുക.',
      methodVegetables: 'ഡ്രിപ്പ് അല്ലെങ്കിൽ സ്പ്രിങ്ക്ലർ ഇറിഗേഷൻ ഉപയോഗിക്കുക.',
      methodCotton: 'ഓൾട്ടർനേറ്റ് ഫറോ ഇറിഗേഷൻ ഉപയോഗിക്കുക.',
      soilSandy: 'മണൽ മണ്ണ്: കുറച്ച് വെള്ളം ഇടയ്ക്കിടെ നൽകുക.',
      soilClay: 'കളിമണ്ണ്: അമിത ജലസേചനം ഒഴിവാക്കുക.',
      soilLoamy: 'കളിമ്പ മണ്ണ്: സാധാരണ ജലസേചനം അനുയോജ്യമാണ്.',
      stageSeedling: 'തൈ ഘട്ടം: ചെറിയ ജലസേചനം മാത്രം. വേരുകൾ സംരക്ഷിക്കുക.',
      stageVegetative: 'വളർച്ചാ ഘട്ടം: കളകൾ നീക്കുക, അകലം നിലനിർത്തുക.',
      stageFlowering: 'പൂവിടുന്ന ഘട്ടം: നിർണായക ജല സമയം! ജലസേചനം ഒഴിവാക്കരുത്.',
      stageHarvest: 'വിളവെടുപ്പ് ഘട്ടം: ജലസേചനം നിർത്തുക.',
      ndviGreen: 'വിള ആരോഗ്യം സാധാരണം (പച്ച).',
      ndviYellow: 'നേരിയ സമ്മർദ്ദം (മഞ്ഞ). മണ്ണിലെ ഈർപ്പം പരിശോധിക്കുക.',
      ndviRed: 'ഉയർന്ന സമ്മർദ്ദം (ചുവപ്പ്)! ഉടൻ ജലസേചനം ചെയ്യുക.',
      noMulchNeeded: 'ഇപ്പോൾ മൾച്ചിംഗ് ആവശ്യമില്ല.',
      mulchHot: 'ചെടികൾക്ക് ചുറ്റും വയ്ക്കോൽ മൾച്ച് ഇടുക.',
      mulchVeg: 'ശക്തമായ ശുപാർശ: പച്ചക്കറി തടങ്ങളിൽ മൾച്ച് ഇടുക.',
      practiceNormal: 'സാധാരണ കൃഷി പരിപാലനം തുടരുക.',
      practiceRain: 'മഴ പ്രതീക്ഷിക്കുന്നു — ജലസേചനം വേണ്ട.',
      practiceHot: 'വളരെ ചൂടുള്ള ദിവസം — രാവിലെ മാത്രം ജലസേചനം.',
      practiceDry: 'കുറഞ്ഞ ഈർപ്പം — വൈകുന്നേരം മണ്ണ് പരിശോധിക്കുക.',
      practiceWindy: 'കാറ്റ് ശക്തം — സ്പ്രിങ്ക്ലർ ഒഴിവാക്കുക. ഡ്രിപ്പ് ഉപയോഗിക്കുക.',
      liters: 'ലിറ്റർ വെള്ളം ലാഭിച്ചു',
    },
    kn: {
      skipRain: 'ಇಂದು ನೀರಾವರಿ ಬೇಡ. ಮಳೆ ನಿರೀಕ್ಷೆ (>60%). ನೀರು ಉಳಿಸಿ.',
      skipHumid: 'ನೀರಾವರಿ ಬೇಡ. ಹೆಚ್ಚಿನ ತೇವಾಂಶ — ಮಣ್ಣಿನಲ್ಲಿ ಸಾಕಷ್ಟು ನೀರಿದೆ.',
      delayWind: 'ನೀರಾವರಿ ವಿಳಂಬ ಮಾಡಿ. ಜೋರಾದ ಗಾಳಿ ನೀರನ್ನು ವ್ಯರ್ಥ ಮಾಡುತ್ತದೆ.',
      skipClay: 'ನೀರಾವರಿ ಬೇಡ. ಜೇಡಿ ಮಣ್ಣು ತೇವಾಂಶವನ್ನು ಚೆನ್ನಾಗಿ ಹಿಡಿಯುತ್ತದೆ.',
      lightMorning: 'ಬೆಳಿಗ್ಗೆ ಮಾತ್ರ ಲಘು ನೀರಾವರಿ.',
      earlyIrrigation: 'ಬೆಳಿಗ್ಗೆ 9 ಗಂಟೆ ಮೊದಲು ನೀರಾವರಿ ಮಾಡಿ.',
      normalIrrigation: 'ಇಂದು ಸಾಮಾನ್ಯ ನೀರಾವರಿ.',
      methodPaddy: 'AWD ವಿಧಾನ ಬಳಸಿ. ಹೊಲವನ್ನು ನಿರಂತರ ಮುಳುಗಿಸಬೇಡಿ.',
      methodSugarcane: 'ಡ್ರಿಪ್ ನೀರಾವರಿ ಬಳಸಿ. 50% ನೀರು ಉಳಿಸುತ್ತದೆ.',
      methodBanana: 'ಬೇಸಿನ್ ನೀರಾವರಿ + ಮಲ್ಚಿಂಗ್ ಬಳಸಿ.',
      methodVegetables: 'ಡ್ರಿಪ್ ಅಥವಾ ಸ್ಪ್ರಿಂಕ್ಲರ್ ನೀರಾವರಿ ಬಳಸಿ.',
      methodCotton: 'ಪರ್ಯಾಯ ಕಾಲುವೆ ನೀರಾವರಿ ಬಳಸಿ.',
      soilSandy: 'ಮರಳು ಮಣ್ಣು: ಕಡಿಮೆ ನೀರು ಆಗಾಗ ನೀಡಿ.',
      soilClay: 'ಜೇಡಿ ಮಣ್ಣು: ಅತಿಯಾದ ನೀರಾವರಿ ತಪ್ಪಿಸಿ.',
      soilLoamy: 'ಗೋಡು ಮಣ್ಣು: ಸಾಮಾನ್ಯ ನೀರಾವರಿ ಸೂಕ್ತ.',
      stageSeedling: 'ಸಸಿ ಹಂತ: ಲಘು ನೀರಾವರಿ ಮಾತ್ರ.',
      stageVegetative: 'ಬೆಳವಣಿಗೆ ಹಂತ: ಕಳೆ ತೆಗೆಯಿರಿ, ಅಂತರ ಕಾಪಾಡಿ.',
      stageFlowering: 'ಹೂಬಿಡುವ ಹಂತ: ನಿರ್ಣಾಯಕ! ನೀರಾವರಿ ತಪ್ಪಿಸಬೇಡಿ.',
      stageHarvest: 'ಕೊಯ್ಲು ಹಂತ: ನೀರಾವರಿ ನಿಲ್ಲಿಸಿ.',
      ndviGreen: 'ಬೆಳೆ ಆರೋಗ್ಯ ಸಾಮಾನ್ಯ (ಹಸಿರು).',
      ndviYellow: 'ಸೌಮ್ಯ ಒತ್ತಡ (ಹಳದಿ). ಮಣ್ಣಿನ ತೇವಾಂಶ ಪರಿಶೀಲಿಸಿ.',
      ndviRed: 'ತೀವ್ರ ಒತ್ತಡ (ಕೆಂಪು)! ತಕ್ಷಣ ನೀರಾವರಿ ಮಾಡಿ.',
      noMulchNeeded: 'ಈಗ ಮಲ್ಚಿಂಗ್ ಅಗತ್ಯವಿಲ್ಲ.',
      mulchHot: 'ಗಿಡಗಳ ಸುತ್ತ ಹುಲ್ಲು ಮಲ್ಚ್ ಹಾಕಿ.',
      mulchVeg: 'ಹೆಚ್ಚು ಶಿಫಾರಸು: ತರಕಾರಿ ಪಾತಿಗಳಲ್ಲಿ ಮಲ್ಚ್ ಹಾಕಿ.',
      practiceNormal: 'ಸಾಮಾನ್ಯ ಹೊಲ ನಿರ್ವಹಣೆ ಮುಂದುವರಿಸಿ.',
      practiceRain: 'ಮಳೆ ನಿರೀಕ್ಷೆ — ನೀರಾವರಿ ಬೇಡ.',
      practiceHot: 'ತುಂಬಾ ಬಿಸಿ ದಿನ — ಬೆಳಿಗ್ಗೆ ಮಾತ್ರ ನೀರಾವರಿ.',
      practiceDry: 'ಕಡಿಮೆ ತೇವಾಂಶ — ಸಂಜೆ ಮಣ್ಣು ಪರಿಶೀಲಿಸಿ.',
      practiceWindy: 'ಗಾಳಿ ಹೆಚ್ಚು — ಸ್ಪ್ರಿಂಕ್ಲರ್ ಬೇಡ. ಡ್ರಿಪ್ ಬಳಸಿ.',
      liters: 'ಲೀಟರ್ ನೀರು ಉಳಿಸಲಾಯಿತು',
    },
    mr: {
      skipRain: 'आज सिंचन टाळा. पावसाची शक्यता (>60%). पाणी वाचवा.',
      skipHumid: 'सिंचन टाळा. उच्च आर्द्रता — मातीत पुरेसा ओलावा आहे.',
      delayWind: 'सिंचन उशीर करा. तीव्र वारा पाणी वाया घालवेल.',
      skipClay: 'सिंचन टाळा. चिकण माती ओलावा चांगला धरून ठेवते.',
      lightMorning: 'सकाळीच हलके सिंचन. वाळू माती उष्णतेत लवकर सुकते.',
      earlyIrrigation: 'सकाळी 9 पूर्वी सिंचन करा.',
      normalIrrigation: 'आज सामान्य सिंचन. परिस्थिती संतुलित आहे.',
      methodPaddy: 'AWD पद्धत वापरा. शेत सतत पाण्यात ठेवू नका.',
      methodSugarcane: 'ठिबक सिंचन वापरा. 50% पाणी वाचते.',
      methodBanana: 'आळे सिंचन + आच्छादन वापरा.',
      methodVegetables: 'ठिबक किंवा तुषार सिंचन वापरा.',
      methodCotton: 'पर्यायी सरी सिंचन वापरा.',
      soilSandy: 'वाळू माती: थोडे पाणी वारंवार द्या.',
      soilClay: 'चिकण माती: अतिसिंचन टाळा.',
      soilLoamy: 'कसदार माती: सामान्य सिंचन योग्य.',
      stageSeedling: 'रोप अवस्था: फक्त हलके सिंचन.',
      stageVegetative: 'वाढीची अवस्था: तण काढा, अंतर राखा.',
      stageFlowering: 'फुलोरा अवस्था: महत्त्वाचा! सिंचन टाळू नका.',
      stageHarvest: 'कापणी अवस्था: सिंचन बंद करा.',
      ndviGreen: 'पीक आरोग्य सामान्य (हिरवे).',
      ndviYellow: 'सौम्य ताण (पिवळे). मातीतील ओलावा तपासा.',
      ndviRed: 'तीव्र ताण (लाल)! लगेच सिंचन करा.',
      noMulchNeeded: 'सध्या आच्छादनाची गरज नाही.',
      mulchHot: 'झाडांभोवती पेंढ्याचे आच्छादन करा.',
      mulchVeg: 'अत्यंत शिफारस: भाजीपाला वाफ्यांवर आच्छादन करा.',
      practiceNormal: 'नियमित शेती देखभाल सुरू ठेवा.',
      practiceRain: 'पाऊस अपेक्षित — सिंचन नको.',
      practiceHot: 'खूप गरम दिवस — सकाळीच सिंचन.',
      practiceDry: 'कमी आर्द्रता — संध्याकाळी माती तपासा.',
      practiceWindy: 'वारा जास्त — तुषार सिंचन टाळा. ठिबक वापरा.',
      liters: 'लिटर पाणी वाचवले',
    },
    pa: {
      skipRain: 'ਅੱਜ ਸਿੰਚਾਈ ਛੱਡੋ। ਮੀਂਹ ਦੀ ਸੰਭਾਵਨਾ (>60%). ਪਾਣੀ ਬਚਾਓ।',
      skipHumid: 'ਸਿੰਚਾਈ ਛੱਡੋ। ਉੱਚ ਨਮੀ — ਮਿੱਟੀ ਵਿੱਚ ਕਾਫ਼ੀ ਨਮੀ ਹੈ।',
      delayWind: 'ਸਿੰਚਾਈ ਦੇਰੀ ਕਰੋ। ਤੇਜ਼ ਹਵਾ ਪਾਣੀ ਬਰਬਾਦ ਕਰੇਗੀ।',
      skipClay: 'ਸਿੰਚਾਈ ਛੱਡੋ। ਚੀਕਣੀ ਮਿੱਟੀ ਨਮੀ ਚੰਗੀ ਤਰ੍ਹਾਂ ਰੱਖਦੀ ਹੈ।',
      lightMorning: 'ਸਵੇਰੇ ਹੀ ਹਲਕੀ ਸਿੰਚਾਈ। ਰੇਤਲੀ ਮਿੱਟੀ ਗਰਮੀ ਵਿੱਚ ਜਲਦੀ ਸੁੱਕਦੀ ਹੈ।',
      earlyIrrigation: 'ਸਵੇਰੇ 9 ਵਜੇ ਤੋਂ ਪਹਿਲਾਂ ਸਿੰਚਾਈ ਕਰੋ।',
      normalIrrigation: 'ਅੱਜ ਆਮ ਸਿੰਚਾਈ। ਹਾਲਾਤ ਸੰਤੁਲਿਤ ਹਨ।',
      methodPaddy: 'AWD ਤਰੀਕਾ ਵਰਤੋ। ਖੇਤ ਨੂੰ ਲਗਾਤਾਰ ਡੁੱਬਾ ਨਾ ਰੱਖੋ।',
      methodSugarcane: 'ਡ੍ਰਿਪ ਸਿੰਚਾਈ ਵਰਤੋ। 50% ਪਾਣੀ ਬਚਦਾ ਹੈ।',
      methodBanana: 'ਬੇਸਿਨ ਸਿੰਚਾਈ + ਮਲਚਿੰਗ ਵਰਤੋ।',
      methodVegetables: 'ਡ੍ਰਿਪ ਜਾਂ ਸਪ੍ਰਿੰਕਲਰ ਸਿੰਚਾਈ ਵਰਤੋ।',
      methodCotton: 'ਬਦਲਵੀਂ ਨਾਲੀ ਸਿੰਚਾਈ ਵਰਤੋ।',
      soilSandy: 'ਰੇਤਲੀ ਮਿੱਟੀ: ਥੋੜਾ ਪਾਣੀ ਵਾਰ-ਵਾਰ ਦਿਓ।',
      soilClay: 'ਚੀਕਣੀ ਮਿੱਟੀ: ਜ਼ਿਆਦਾ ਸਿੰਚਾਈ ਤੋਂ ਬਚੋ।',
      soilLoamy: 'ਦੋਮਟ ਮਿੱਟੀ: ਆਮ ਸਿੰਚਾਈ ਢੁੱਕਵੀਂ ਹੈ।',
      stageSeedling: 'ਪਨੀਰੀ ਪੜਾਅ: ਹਲਕੀ ਸਿੰਚਾਈ ਹੀ।',
      stageVegetative: 'ਵਧਣ ਪੜਾਅ: ਨਦੀਨ ਕੱਢੋ, ਦੂਰੀ ਰੱਖੋ।',
      stageFlowering: 'ਫੁੱਲ ਪੜਾਅ: ਮਹੱਤਵਪੂਰਨ! ਸਿੰਚਾਈ ਨਾ ਛੱਡੋ।',
      stageHarvest: 'ਵਾਢੀ ਪੜਾਅ: ਸਿੰਚਾਈ ਬੰਦ ਕਰੋ।',
      ndviGreen: 'ਫਸਲ ਸਿਹਤ ਆਮ (ਹਰਾ)।',
      ndviYellow: 'ਹਲਕਾ ਤਣਾਅ (ਪੀਲਾ)। ਮਿੱਟੀ ਦੀ ਨਮੀ ਚੈੱਕ ਕਰੋ।',
      ndviRed: 'ਗੰਭੀਰ ਤਣਾਅ (ਲਾਲ)! ਤੁਰੰਤ ਸਿੰਚਾਈ ਕਰੋ।',
      noMulchNeeded: 'ਹੁਣ ਮਲਚਿੰਗ ਦੀ ਲੋੜ ਨਹੀਂ।',
      mulchHot: 'ਬੂਟਿਆਂ ਦੇ ਆਲੇ-ਦੁਆਲੇ ਤੂੜੀ ਦੀ ਮਲਚ ਪਾਓ।',
      mulchVeg: 'ਬਹੁਤ ਸਿਫ਼ਾਰਸ਼: ਸਬਜ਼ੀਆਂ ਦੀਆਂ ਕਿਆਰੀਆਂ \'ਤੇ ਮਲਚ ਪਾਓ।',
      practiceNormal: 'ਆਮ ਖੇਤ ਦੇਖਭਾਲ ਜਾਰੀ ਰੱਖੋ।',
      practiceRain: 'ਮੀਂਹ ਦੀ ਸੰਭਾਵਨਾ — ਸਿੰਚਾਈ ਨਾ ਕਰੋ।',
      practiceHot: 'ਬਹੁਤ ਗਰਮ ਦਿਨ — ਸਵੇਰੇ ਹੀ ਸਿੰਚਾਈ।',
      practiceDry: 'ਘੱਟ ਨਮੀ — ਸ਼ਾਮ ਨੂੰ ਮਿੱਟੀ ਚੈੱਕ ਕਰੋ।',
      practiceWindy: 'ਹਵਾ ਤੇਜ਼ — ਸਪ੍ਰਿੰਕਲਰ ਨਾ ਵਰਤੋ। ਡ੍ਰਿਪ ਵਰਤੋ।',
      liters: 'ਲੀਟਰ ਪਾਣੀ ਬਚਾਇਆ',
    },
    bn: {
      skipRain: 'আজ সেচ এড়িয়ে যান। বৃষ্টির সম্ভাবনা (>60%)। জল বাঁচান।',
      skipHumid: 'সেচ এড়িয়ে যান। উচ্চ আর্দ্রতা — মাটিতে পর্যাপ্ত জল আছে।',
      delayWind: 'সেচ বিলম্বিত করুন। তীব্র বাতাস জল নষ্ট করবে।',
      skipClay: 'সেচ এড়িয়ে যান। এঁটেল মাটি আর্দ্রতা ভালো ধরে রাখে।',
      lightMorning: 'সকালে শুধু হালকা সেচ। বালি মাটি গরমে তাড়াতাড়ি শুকায়।',
      earlyIrrigation: 'সকাল 9টার আগে সেচ দিন।',
      normalIrrigation: 'আজ স্বাভাবিক সেচ। পরিস্থিতি ভারসাম্যপূর্ণ।',
      methodPaddy: 'AWD পদ্ধতি ব্যবহার করুন। ক্ষেত ক্রমাগত ডুবিয়ে রাখবেন না।',
      methodSugarcane: 'ড্রিপ সেচ ব্যবহার করুন। 50% জল বাঁচে।',
      methodBanana: 'বেসিন সেচ + মালচিং ব্যবহার করুন।',
      methodVegetables: 'ড্রিপ বা স্প্রিংকলার সেচ ব্যবহার করুন।',
      methodCotton: 'পর্যায়ক্রমে নালা সেচ ব্যবহার করুন।',
      soilSandy: 'বালি মাটি: অল্প জল ঘন ঘন দিন।',
      soilClay: 'এঁটেল মাটি: অতিরিক্ত সেচ এড়িয়ে চলুন।',
      soilLoamy: 'দোআঁশ মাটি: স্বাভাবিক সেচ উপযুক্ত।',
      stageSeedling: 'চারা পর্ব: শুধু হালকা সেচ।',
      stageVegetative: 'বৃদ্ধি পর্ব: আগাছা তুলুন, দূরত্ব বজায় রাখুন।',
      stageFlowering: 'ফুল পর্ব: গুরুত্বপূর্ণ! সেচ বাদ দেবেন না।',
      stageHarvest: 'ফসল কাটা পর্ব: সেচ বন্ধ করুন।',
      ndviGreen: 'ফসল স্বাস্থ্য স্বাভাবিক (সবুজ)।',
      ndviYellow: 'হালকা চাপ (হলুদ)। মাটির আর্দ্রতা পরীক্ষা করুন।',
      ndviRed: 'তীব্র চাপ (লাল)! এখনই সেচ দিন।',
      noMulchNeeded: 'এখন মালচিং প্রয়োজন নেই।',
      mulchHot: 'গাছের চারপাশে খড়ের মালচ দিন।',
      mulchVeg: 'অত্যন্ত সুপারিশ: সবজি বেডে মালচ দিন।',
      practiceNormal: 'নিয়মিত খামার পরিচর্যা চালিয়ে যান।',
      practiceRain: 'বৃষ্টি প্রত্যাশিত — সেচ দেবেন না।',
      practiceHot: 'খুব গরম দিন — সকালেই সেচ।',
      practiceDry: 'কম আর্দ্রতা — সন্ধ্যায় মাটি পরীক্ষা করুন।',
      practiceWindy: 'বাতাস বেশি — স্প্রিংকলার এড়িয়ে চলুন। ড্রিপ ব্যবহার করুন।',
      liters: 'লিটার জল সাশ্রয়',
    },
    ur: {
      skipRain: 'آج آبپاشی چھوڑ دیں۔ بارش کا امکان (>60%)۔ پانی بچائیں۔',
      skipHumid: 'آبپاشی چھوڑ دیں۔ زیادہ نمی — مٹی میں کافی نمی ہے۔',
      delayWind: 'آبپاشی میں تاخیر کریں۔ تیز ہوا پانی ضائع کرے گی۔',
      skipClay: 'آبپاشی چھوڑ دیں۔ چکنی مٹی نمی اچھی طرح رکھتی ہے۔',
      lightMorning: 'صبح صرف ہلکی آبپاشی۔ ریتلی مٹی گرمی میں جلدی سوکھتی ہے۔',
      earlyIrrigation: 'صبح 9 بجے سے پہلے آبپاشی کریں۔',
      normalIrrigation: 'آج عام آبپاشی۔ حالات متوازن ہیں۔',
      methodPaddy: 'AWD طریقہ استعمال کریں۔ کھیت کو مسلسل ڈبوئے نہ رکھیں۔',
      methodSugarcane: 'ڈرپ آبپاشی استعمال کریں۔ 50% پانی بچتا ہے۔',
      methodBanana: 'بیسن آبپاشی + ملچنگ استعمال کریں۔',
      methodVegetables: 'ڈرپ یا اسپرنکلر آبپاشی استعمال کریں۔',
      methodCotton: 'باری باری نالی آبپاشی استعمال کریں۔',
      soilSandy: 'ریتلی مٹی: تھوڑا پانی بار بار دیں۔',
      soilClay: 'چکنی مٹی: زیادہ آبپاشی سے بچیں۔',
      soilLoamy: 'زرخیز مٹی: عام آبپاشی مناسب ہے۔',
      stageSeedling: 'پنیری مرحلہ: صرف ہلکی آبپاشی۔',
      stageVegetative: 'بڑھوتری مرحلہ: جڑی بوٹیاں نکالیں، فاصلہ رکھیں۔',
      stageFlowering: 'پھول مرحلہ: اہم! آبپاشی نہ چھوڑیں۔',
      stageHarvest: 'کٹائی مرحلہ: آبپاشی بند کریں۔',
      ndviGreen: 'فصل صحت عام (سبز)۔',
      ndviYellow: 'ہلکا دباؤ (پیلا)۔ مٹی کی نمی چیک کریں۔',
      ndviRed: 'شدید دباؤ (لال)! فوری آبپاشی کریں۔',
      noMulchNeeded: 'ابھی ملچنگ کی ضرورت نہیں۔',
      mulchHot: 'پودوں کے ارد گرد بھوسے کی ملچ ڈالیں۔',
      mulchVeg: 'بہت سفارش: سبزیوں کی کیاریوں پر ملچ ڈالیں۔',
      practiceNormal: 'باقاعدہ کھیت دیکھ بھال جاری رکھیں۔',
      practiceRain: 'بارش متوقع — آبپاشی نہ کریں۔',
      practiceHot: 'بہت گرم دن — صبح ہی آبپاشی۔',
      practiceDry: 'کم نمی — شام کو مٹی چیک کریں۔',
      practiceWindy: 'ہوا تیز — اسپرنکلر نہ استعمال کریں۔ ڈرپ استعمال کریں۔',
      liters: 'لیٹر پانی بچایا',
    },
  };

  return (texts[lang] || texts.en)[key] || (texts.en)[key] || key;
}

const SOIL_TYPES = ['sandy', 'loamy', 'clay'];
const CROPS = ['paddy', 'sugarcane', 'banana', 'vegetables', 'cotton'];
const CROP_STAGES = ['seedling', 'vegetative', 'flowering', 'harvest'];
const NDVI_OPTIONS = ['green', 'yellow', 'red'];

export default function WaterAdvisoryTab({ farmData }: Props) {
  const { lang } = useLanguage();
  const { isSpeaking, speak, stop } = useSpeechSynthesis(lang);
  const [advisory, setAdvisory] = useState<Record<string, string> | null>(null);
  const [input, setInput] = useState<AdvisoryInput>({
    temperature: 34,
    humidity: 65,
    windSpeed: 12,
    chanceOfRain: 30,
    soilType: 'loamy',
    crop: 'paddy',
    cropStage: 'vegetative',
    ndviHealth: 'green',
  });

  const handleGenerate = () => {
    const result = generateAdvisory(input, lang);
    setAdvisory(result);
  };

  const advisoryLabels: Record<string, Record<string, string>> = {
    en: { irrigationDecision: '💧 Irrigation Decision', irrigationMethod: '🔧 Recommended Method', soilAdvice: '🏜️ Soil-based Advice', cropStageAdvice: '🌱 Crop Stage Advice', ndviWarning: '🛰️ Crop Health (NDVI)', mulchingTip: '🍂 Mulching Tip', farmPractice: '🌾 Today\'s Practice', waterSaved: '💰 Water Saved' },
    hi: { irrigationDecision: '💧 सिंचाई निर्णय', irrigationMethod: '🔧 अनुशंसित विधि', soilAdvice: '🏜️ मिट्टी सलाह', cropStageAdvice: '🌱 फसल चरण सलाह', ndviWarning: '🛰️ फसल स्वास्थ्य (NDVI)', mulchingTip: '🍂 मल्चिंग सुझाव', farmPractice: '🌾 आज का अभ्यास', waterSaved: '💰 पानी बचाया' },
    ta: { irrigationDecision: '💧 பாசன முடிவு', irrigationMethod: '🔧 பரிந்துரைக்கப்பட்ட முறை', soilAdvice: '🏜️ மண் ஆலோசனை', cropStageAdvice: '🌱 பயிர் நிலை ஆலோசனை', ndviWarning: '🛰️ பயிர் ஆரோக்கியம்', mulchingTip: '🍂 மல்ச்சிங் குறிப்பு', farmPractice: '🌾 இன்றைய நடைமுறை', waterSaved: '💰 தண்ணீர் சேமிப்பு' },
    te: { irrigationDecision: '💧 నీటిపారుదల నిర్ణయం', irrigationMethod: '🔧 సిఫార్సు పద్ధతి', soilAdvice: '🏜️ మట్టి సలహా', cropStageAdvice: '🌱 పంట దశ సలహా', ndviWarning: '🛰️ పంట ఆరోగ్యం', mulchingTip: '🍂 మల్చింగ్ చిట్కా', farmPractice: '🌾 ఈ రోజు అభ్యాసం', waterSaved: '💰 నీరు ఆదా' },
    ml: { irrigationDecision: '💧 ജലസേചന തീരുമാനം', irrigationMethod: '🔧 ശുപാർശ ചെയ്ത രീതി', soilAdvice: '🏜️ മണ്ണ് ഉപദേശം', cropStageAdvice: '🌱 വിള ഘട്ട ഉപദേശം', ndviWarning: '🛰️ വിള ആരോഗ്യം', mulchingTip: '🍂 മൾച്ചിംഗ് നുറുങ്ങ്', farmPractice: '🌾 ഇന്നത്തെ പ്രയോഗം', waterSaved: '💰 വെള്ളം ലാഭം' },
    kn: { irrigationDecision: '💧 ನೀರಾವರಿ ನಿರ್ಧಾರ', irrigationMethod: '🔧 ಶಿಫಾರಸು ವಿಧಾನ', soilAdvice: '🏜️ ಮಣ್ಣು ಸಲಹೆ', cropStageAdvice: '🌱 ಬೆಳೆ ಹಂತ ಸಲಹೆ', ndviWarning: '🛰️ ಬೆಳೆ ಆರೋಗ್ಯ', mulchingTip: '🍂 ಮಲ್ಚಿಂಗ್ ಸಲಹೆ', farmPractice: '🌾 ಇಂದಿನ ಅಭ್ಯಾಸ', waterSaved: '💰 ನೀರು ಉಳಿತಾಯ' },
    mr: { irrigationDecision: '💧 सिंचन निर्णय', irrigationMethod: '🔧 शिफारस पद्धत', soilAdvice: '🏜️ माती सल्ला', cropStageAdvice: '🌱 पीक टप्पा सल्ला', ndviWarning: '🛰️ पीक आरोग्य', mulchingTip: '🍂 आच्छादन सल्ला', farmPractice: '🌾 आजचा सराव', waterSaved: '💰 पाणी वाचवले' },
    pa: { irrigationDecision: '💧 ਸਿੰਚਾਈ ਫੈਸਲਾ', irrigationMethod: '🔧 ਸਿਫ਼ਾਰਸ਼ ਤਰੀਕਾ', soilAdvice: '🏜️ ਮਿੱਟੀ ਸਲਾਹ', cropStageAdvice: '🌱 ਫਸਲ ਪੜਾਅ ਸਲਾਹ', ndviWarning: '🛰️ ਫਸਲ ਸਿਹਤ', mulchingTip: '🍂 ਮਲਚਿੰਗ ਸੁਝਾਅ', farmPractice: '🌾 ਅੱਜ ਦਾ ਅਭਿਆਸ', waterSaved: '💰 ਪਾਣੀ ਬਚਾਇਆ' },
    bn: { irrigationDecision: '💧 সেচ সিদ্ধান্ত', irrigationMethod: '🔧 প্রস্তাবিত পদ্ধতি', soilAdvice: '🏜️ মাটি পরামর্শ', cropStageAdvice: '🌱 ফসল পর্ব পরামর্শ', ndviWarning: '🛰️ ফসল স্বাস্থ্য', mulchingTip: '🍂 মালচিং পরামর্শ', farmPractice: '🌾 আজকের অনুশীলন', waterSaved: '💰 জল সাশ্রয়' },
    ur: { irrigationDecision: '💧 آبپاشی فیصلہ', irrigationMethod: '🔧 تجویز کردہ طریقہ', soilAdvice: '🏜️ مٹی مشورہ', cropStageAdvice: '🌱 فصل مرحلہ مشورہ', ndviWarning: '🛰️ فصل صحت', mulchingTip: '🍂 ملچنگ مشورہ', farmPractice: '🌾 آج کا عمل', waterSaved: '💰 پانی بچایا' },
  };

  const labels = advisoryLabels[lang] || advisoryLabels.en;

  const fieldLabels: Record<string, Record<string, string>> = {
    en: { temperature: 'Temperature (°C)', humidity: 'Humidity (%)', windSpeed: 'Wind Speed (km/h)', chanceOfRain: 'Chance of Rain (%)', soilType: 'Soil Type', crop: 'Crop', cropStage: 'Crop Stage', ndviHealth: 'NDVI Health', getAdvisory: 'Get Advisory', waterAdvisory: 'Water & Practices Advisory' },
    hi: { temperature: 'तापमान (°C)', humidity: 'नमी (%)', windSpeed: 'हवा की गति (km/h)', chanceOfRain: 'बारिश की संभावना (%)', soilType: 'मिट्टी का प्रकार', crop: 'फसल', cropStage: 'फसल चरण', ndviHealth: 'NDVI स्वास्थ्य', getAdvisory: 'सलाह प्राप्त करें', waterAdvisory: 'पानी और अभ्यास सलाह' },
    ta: { temperature: 'வெப்பநிலை (°C)', humidity: 'ஈரப்பதம் (%)', windSpeed: 'காற்று வேகம் (km/h)', chanceOfRain: 'மழை வாய்ப்பு (%)', soilType: 'மண் வகை', crop: 'பயிர்', cropStage: 'பயிர் நிலை', ndviHealth: 'NDVI ஆரோக்கியம்', getAdvisory: 'ஆலோசனை பெறு', waterAdvisory: 'நீர் & நடைமுறை ஆலோசனை' },
    te: { temperature: 'ఉష్ణోగ్రత (°C)', humidity: 'తేమ (%)', windSpeed: 'గాలి వేగం (km/h)', chanceOfRain: 'వర్షం అవకాశం (%)', soilType: 'మట్టి రకం', crop: 'పంట', cropStage: 'పంట దశ', ndviHealth: 'NDVI ఆరోగ్యం', getAdvisory: 'సలహా పొందండి', waterAdvisory: 'నీటి & పద్ధతుల సలహా' },
    ml: { temperature: 'താപനില (°C)', humidity: 'ഈർപ്പം (%)', windSpeed: 'കാറ്റ് വേഗം (km/h)', chanceOfRain: 'മഴ സാധ്യത (%)', soilType: 'മണ്ണ് തരം', crop: 'വിള', cropStage: 'വിള ഘട്ടം', ndviHealth: 'NDVI ആരോഗ്യം', getAdvisory: 'ഉപദേശം നേടുക', waterAdvisory: 'ജല & പ്രയോഗ ഉപദേശം' },
    kn: { temperature: 'ಉಷ್ಣತೆ (°C)', humidity: 'ತೇವಾಂಶ (%)', windSpeed: 'ಗಾಳಿ ವೇಗ (km/h)', chanceOfRain: 'ಮಳೆ ಸಾಧ್ಯತೆ (%)', soilType: 'ಮಣ್ಣು ಪ್ರಕಾರ', crop: 'ಬೆಳೆ', cropStage: 'ಬೆಳೆ ಹಂತ', ndviHealth: 'NDVI ಆರೋಗ್ಯ', getAdvisory: 'ಸಲಹೆ ಪಡೆಯಿರಿ', waterAdvisory: 'ನೀರು & ಅಭ್ಯಾಸ ಸಲಹೆ' },
    mr: { temperature: 'तापमान (°C)', humidity: 'आर्द्रता (%)', windSpeed: 'वारा वेग (km/h)', chanceOfRain: 'पावसाची शक्यता (%)', soilType: 'मातीचा प्रकार', crop: 'पीक', cropStage: 'पीक टप्पा', ndviHealth: 'NDVI आरोग्य', getAdvisory: 'सल्ला मिळवा', waterAdvisory: 'पाणी आणि सराव सल्ला' },
    pa: { temperature: 'ਤਾਪਮਾਨ (°C)', humidity: 'ਨਮੀ (%)', windSpeed: 'ਹਵਾ ਦੀ ਰਫ਼ਤਾਰ (km/h)', chanceOfRain: 'ਮੀਂਹ ਦੀ ਸੰਭਾਵਨਾ (%)', soilType: 'ਮਿੱਟੀ ਦੀ ਕਿਸਮ', crop: 'ਫਸਲ', cropStage: 'ਫਸਲ ਪੜਾਅ', ndviHealth: 'NDVI ਸਿਹਤ', getAdvisory: 'ਸਲਾਹ ਲਓ', waterAdvisory: 'ਪਾਣੀ ਅਤੇ ਅਭਿਆਸ ਸਲਾਹ' },
    bn: { temperature: 'তাপমাত্রা (°C)', humidity: 'আর্দ্রতা (%)', windSpeed: 'বাতাসের গতি (km/h)', chanceOfRain: 'বৃষ্টির সম্ভাবনা (%)', soilType: 'মাটির ধরন', crop: 'ফসল', cropStage: 'ফসল পর্ব', ndviHealth: 'NDVI স্বাস্থ্য', getAdvisory: 'পরামর্শ নিন', waterAdvisory: 'জল ও অনুশীলন পরামর্শ' },
    ur: { temperature: 'درجہ حرارت (°C)', humidity: 'نمی (%)', windSpeed: 'ہوا کی رفتار (km/h)', chanceOfRain: 'بارش کا امکان (%)', soilType: 'مٹی کی قسم', crop: 'فصل', cropStage: 'فصل مرحلہ', ndviHealth: 'NDVI صحت', getAdvisory: 'مشورہ حاصل کریں', waterAdvisory: 'پانی اور عمل مشورہ' },
  };

  const fl = fieldLabels[lang] || fieldLabels.en;

  const soilLabels: Record<string, Record<string, string>> = {
    en: { sandy: 'Sandy', loamy: 'Loamy', clay: 'Clay' },
    hi: { sandy: 'रेतीली', loamy: 'दोमट', clay: 'चिकनी' },
    ta: { sandy: 'மணல்', loamy: 'கரிசல்', clay: 'களிமண்' },
    te: { sandy: 'ఇసుక', loamy: 'గోరు', clay: 'బంక' },
    ml: { sandy: 'മണൽ', loamy: 'കളിമ്പ', clay: 'കളിമണ്ണ്' },
    kn: { sandy: 'ಮರಳು', loamy: 'ಗೋಡು', clay: 'ಜೇಡಿ' },
    mr: { sandy: 'वाळू', loamy: 'कसदार', clay: 'चिकण' },
    pa: { sandy: 'ਰੇਤਲੀ', loamy: 'ਦੋਮਟ', clay: 'ਚੀਕਣੀ' },
    bn: { sandy: 'বালি', loamy: 'দোআঁশ', clay: 'এঁটেল' },
    ur: { sandy: 'ریتلی', loamy: 'زرخیز', clay: 'چکنی' },
  };

  const cropLabels: Record<string, Record<string, string>> = {
    en: { paddy: 'Paddy', sugarcane: 'Sugarcane', banana: 'Banana', vegetables: 'Vegetables', cotton: 'Cotton' },
    hi: { paddy: 'धान', sugarcane: 'गन्ना', banana: 'केला', vegetables: 'सब्जियां', cotton: 'कपास' },
    ta: { paddy: 'நெல்', sugarcane: 'கரும்பு', banana: 'வாழை', vegetables: 'காய்கறிகள்', cotton: 'பருத்தி' },
    te: { paddy: 'వరి', sugarcane: 'చెరకు', banana: 'అరటి', vegetables: 'కూరగాయలు', cotton: 'పత్తి' },
    ml: { paddy: 'നെല്ല്', sugarcane: 'കരിമ്പ്', banana: 'വാഴ', vegetables: 'പച്ചക്കറികൾ', cotton: 'പരുത്തി' },
    kn: { paddy: 'ಭತ್ತ', sugarcane: 'ಕಬ್ಬು', banana: 'ಬಾಳೆ', vegetables: 'ತರಕಾರಿ', cotton: 'ಹತ್ತಿ' },
    mr: { paddy: 'भात', sugarcane: 'ऊस', banana: 'केळी', vegetables: 'भाजीपाला', cotton: 'कापूस' },
    pa: { paddy: 'ਝੋਨਾ', sugarcane: 'ਗੰਨਾ', banana: 'ਕੇਲਾ', vegetables: 'ਸਬਜ਼ੀਆਂ', cotton: 'ਕਪਾਹ' },
    bn: { paddy: 'ধান', sugarcane: 'আখ', banana: 'কলা', vegetables: 'সবজি', cotton: 'তুলা' },
    ur: { paddy: 'دھان', sugarcane: 'گنا', banana: 'کیلا', vegetables: 'سبزیاں', cotton: 'کپاس' },
  };

  const stageLabels: Record<string, Record<string, string>> = {
    en: { seedling: 'Seedling', vegetative: 'Vegetative', flowering: 'Flowering', harvest: 'Harvest' },
    hi: { seedling: 'पौध', vegetative: 'वानस्पतिक', flowering: 'फूल', harvest: 'कटाई' },
    ta: { seedling: 'நாற்று', vegetative: 'வளர்ச்சி', flowering: 'பூக்கும்', harvest: 'அறுவடை' },
    te: { seedling: 'మొలక', vegetative: 'వృద్ధి', flowering: 'పూత', harvest: 'కోత' },
    ml: { seedling: 'തൈ', vegetative: 'വളർച്ച', flowering: 'പൂവിടുന്ന', harvest: 'വിളവെടുപ്പ്' },
    kn: { seedling: 'ಸಸಿ', vegetative: 'ಬೆಳವಣಿಗೆ', flowering: 'ಹೂಬಿಡುವ', harvest: 'ಕೊಯ್ಲು' },
    mr: { seedling: 'रोप', vegetative: 'वाढ', flowering: 'फुलोरा', harvest: 'कापणी' },
    pa: { seedling: 'ਪਨੀਰੀ', vegetative: 'ਵਧਣ', flowering: 'ਫੁੱਲ', harvest: 'ਵਾਢੀ' },
    bn: { seedling: 'চারা', vegetative: 'বৃদ্ধি', flowering: 'ফুল', harvest: 'ফসল কাটা' },
    ur: { seedling: 'پنیری', vegetative: 'بڑھوتری', flowering: 'پھول', harvest: 'کٹائی' },
  };

  const sl = soilLabels[lang] || soilLabels.en;
  const cl = cropLabels[lang] || cropLabels.en;
  const stl = stageLabels[lang] || stageLabels.en;

  const readAdvisory = () => {
    if (!advisory) return;
    const text = Object.entries(advisory).map(([k, v]) => `${(labels as any)[k] || k}: ${v}`).join('. ');
    speak(text);
  };

  return (
    <div className="space-y-4">
      <div className="agri-card">
        <div className="flex items-center gap-2 mb-3">
          <Droplets className="w-6 h-6 text-primary" />
          <h3 className="font-bold text-foreground text-lg">{fl.waterAdvisory}</h3>
        </div>

        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="text-xs font-semibold text-muted-foreground">{fl.temperature}</label>
            <input type="number" value={input.temperature} onChange={e => setInput(i => ({ ...i, temperature: +e.target.value }))}
              className="w-full mt-1 px-3 py-2 rounded-xl bg-card border border-border text-foreground text-sm focus:ring-2 focus:ring-primary outline-none" />
          </div>
          <div>
            <label className="text-xs font-semibold text-muted-foreground">{fl.humidity}</label>
            <input type="number" value={input.humidity} onChange={e => setInput(i => ({ ...i, humidity: +e.target.value }))}
              className="w-full mt-1 px-3 py-2 rounded-xl bg-card border border-border text-foreground text-sm focus:ring-2 focus:ring-primary outline-none" />
          </div>
          <div>
            <label className="text-xs font-semibold text-muted-foreground">{fl.windSpeed}</label>
            <input type="number" value={input.windSpeed} onChange={e => setInput(i => ({ ...i, windSpeed: +e.target.value }))}
              className="w-full mt-1 px-3 py-2 rounded-xl bg-card border border-border text-foreground text-sm focus:ring-2 focus:ring-primary outline-none" />
          </div>
          <div>
            <label className="text-xs font-semibold text-muted-foreground">{fl.chanceOfRain}</label>
            <input type="number" value={input.chanceOfRain} onChange={e => setInput(i => ({ ...i, chanceOfRain: +e.target.value }))}
              className="w-full mt-1 px-3 py-2 rounded-xl bg-card border border-border text-foreground text-sm focus:ring-2 focus:ring-primary outline-none" />
          </div>
        </div>

        <div className="grid grid-cols-2 gap-3 mt-3">
          <div>
            <label className="text-xs font-semibold text-muted-foreground">{fl.soilType}</label>
            <select value={input.soilType} onChange={e => setInput(i => ({ ...i, soilType: e.target.value }))}
              className="w-full mt-1 px-3 py-2 rounded-xl bg-card border border-border text-foreground text-sm focus:ring-2 focus:ring-primary outline-none">
              {SOIL_TYPES.map(s => <option key={s} value={s}>{sl[s]}</option>)}
            </select>
          </div>
          <div>
            <label className="text-xs font-semibold text-muted-foreground">{fl.crop}</label>
            <select value={input.crop} onChange={e => setInput(i => ({ ...i, crop: e.target.value }))}
              className="w-full mt-1 px-3 py-2 rounded-xl bg-card border border-border text-foreground text-sm focus:ring-2 focus:ring-primary outline-none">
              {CROPS.map(c => <option key={c} value={c}>{cl[c]}</option>)}
            </select>
          </div>
          <div>
            <label className="text-xs font-semibold text-muted-foreground">{fl.cropStage}</label>
            <select value={input.cropStage} onChange={e => setInput(i => ({ ...i, cropStage: e.target.value }))}
              className="w-full mt-1 px-3 py-2 rounded-xl bg-card border border-border text-foreground text-sm focus:ring-2 focus:ring-primary outline-none">
              {CROP_STAGES.map(s => <option key={s} value={s}>{stl[s]}</option>)}
            </select>
          </div>
          <div>
            <label className="text-xs font-semibold text-muted-foreground">{fl.ndviHealth}</label>
            <select value={input.ndviHealth} onChange={e => setInput(i => ({ ...i, ndviHealth: e.target.value }))}
              className="w-full mt-1 px-3 py-2 rounded-xl bg-card border border-border text-foreground text-sm focus:ring-2 focus:ring-primary outline-none">
              {NDVI_OPTIONS.map(n => <option key={n} value={n}>{n === 'green' ? '🟢' : n === 'yellow' ? '🟡' : '🔴'} {n.charAt(0).toUpperCase() + n.slice(1)}</option>)}
            </select>
          </div>
        </div>

        <button onClick={handleGenerate}
          className="w-full mt-4 py-3 rounded-2xl bg-primary text-primary-foreground font-bold flex items-center justify-center gap-2 active:scale-95 transition-all shadow-lg">
          <Droplets className="w-5 h-5" /> {fl.getAdvisory}
        </button>
      </div>

      {advisory && (
        <div className="space-y-2">
          {Object.entries(advisory).map(([key, value]) => (
            <div key={key} className={`agri-card border-2 ${
              key === 'ndviWarning' && input.ndviHealth === 'red' ? 'border-destructive/40 bg-destructive/5' :
              key === 'waterSaved' ? 'border-primary/40 bg-primary/5' : 'border-border'
            }`}>
              <h4 className="font-bold text-foreground text-sm mb-1">{labels[key] || key}</h4>
              <p className="text-sm text-foreground leading-relaxed">{value}</p>
            </div>
          ))}
          <button onClick={isSpeaking ? stop : readAdvisory}
            className="w-full py-3 rounded-2xl bg-secondary text-secondary-foreground font-bold flex items-center justify-center gap-2 active:scale-95 transition-all">
            {isSpeaking ? <><VolumeX className="w-5 h-5" /> {t(lang, 'stopAudio')}</> : <><Volume2 className="w-5 h-5" /> {t(lang, 'playAudio')}</>}
          </button>
        </div>
      )}
    </div>
  );
}
