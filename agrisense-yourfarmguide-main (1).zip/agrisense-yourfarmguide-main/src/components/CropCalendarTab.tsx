import React from 'react';
import { useLanguage } from '@/hooks/useLanguage';
import { t } from '@/lib/languages';
import { type FarmData } from '@/components/OnboardingForm';
import { Calendar, Sprout, Sun, CloudRain, Scissors } from 'lucide-react';

interface Props {
  farmData: FarmData;
}

interface CropPhase {
  nameKey: string;
  icon: React.ReactNode;
  months: string;
  color: string;
  description: string;
}

const CROP_CALENDARS: Record<string, CropPhase[]> = {
  Wheat: [
    { nameKey: 'landPreparation', icon: <Sun className="w-4 h-4" />, months: 'Oct', color: 'bg-amber-500', description: 'plowAndLevel' },
    { nameKey: 'sowing', icon: <Sprout className="w-4 h-4" />, months: 'Nov', color: 'bg-primary', description: 'sowSeeds' },
    { nameKey: 'irrigation', icon: <CloudRain className="w-4 h-4" />, months: 'Dec-Feb', color: 'bg-sky-500', description: 'waterRegularly' },
    { nameKey: 'harvesting', icon: <Scissors className="w-4 h-4" />, months: 'Mar-Apr', color: 'bg-success', description: 'harvestCrop' },
  ],
  Rice: [
    { nameKey: 'landPreparation', icon: <Sun className="w-4 h-4" />, months: 'May-Jun', color: 'bg-amber-500', description: 'plowAndLevel' },
    { nameKey: 'sowing', icon: <Sprout className="w-4 h-4" />, months: 'Jun-Jul', color: 'bg-primary', description: 'transplantSeedlings' },
    { nameKey: 'irrigation', icon: <CloudRain className="w-4 h-4" />, months: 'Jul-Oct', color: 'bg-sky-500', description: 'maintainWaterLevel' },
    { nameKey: 'harvesting', icon: <Scissors className="w-4 h-4" />, months: 'Oct-Nov', color: 'bg-success', description: 'harvestCrop' },
  ],
  Cotton: [
    { nameKey: 'landPreparation', icon: <Sun className="w-4 h-4" />, months: 'Mar-Apr', color: 'bg-amber-500', description: 'plowAndLevel' },
    { nameKey: 'sowing', icon: <Sprout className="w-4 h-4" />, months: 'Apr-May', color: 'bg-primary', description: 'sowSeeds' },
    { nameKey: 'irrigation', icon: <CloudRain className="w-4 h-4" />, months: 'Jun-Sep', color: 'bg-sky-500', description: 'waterRegularly' },
    { nameKey: 'harvesting', icon: <Scissors className="w-4 h-4" />, months: 'Oct-Dec', color: 'bg-success', description: 'pickBolls' },
  ],
  Sugarcane: [
    { nameKey: 'landPreparation', icon: <Sun className="w-4 h-4" />, months: 'Jan-Feb', color: 'bg-amber-500', description: 'plowAndLevel' },
    { nameKey: 'sowing', icon: <Sprout className="w-4 h-4" />, months: 'Feb-Mar', color: 'bg-primary', description: 'plantSetts' },
    { nameKey: 'irrigation', icon: <CloudRain className="w-4 h-4" />, months: 'Apr-Oct', color: 'bg-sky-500', description: 'waterRegularly' },
    { nameKey: 'harvesting', icon: <Scissors className="w-4 h-4" />, months: 'Dec-Mar', color: 'bg-success', description: 'cutCanes' },
  ],
  Maize: [
    { nameKey: 'landPreparation', icon: <Sun className="w-4 h-4" />, months: 'May', color: 'bg-amber-500', description: 'plowAndLevel' },
    { nameKey: 'sowing', icon: <Sprout className="w-4 h-4" />, months: 'Jun', color: 'bg-primary', description: 'sowSeeds' },
    { nameKey: 'irrigation', icon: <CloudRain className="w-4 h-4" />, months: 'Jul-Aug', color: 'bg-sky-500', description: 'waterRegularly' },
    { nameKey: 'harvesting', icon: <Scissors className="w-4 h-4" />, months: 'Sep-Oct', color: 'bg-success', description: 'harvestCrop' },
  ],
  Millet: [
    { nameKey: 'landPreparation', icon: <Sun className="w-4 h-4" />, months: 'May', color: 'bg-amber-500', description: 'plowAndLevel' },
    { nameKey: 'sowing', icon: <Sprout className="w-4 h-4" />, months: 'Jun-Jul', color: 'bg-primary', description: 'sowSeeds' },
    { nameKey: 'irrigation', icon: <CloudRain className="w-4 h-4" />, months: 'Jul-Sep', color: 'bg-sky-500', description: 'waterRegularly' },
    { nameKey: 'harvesting', icon: <Scissors className="w-4 h-4" />, months: 'Oct-Nov', color: 'bg-success', description: 'harvestCrop' },
  ],
};

const MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

export default function CropCalendarTab({ farmData }: Props) {
  const { lang } = useLanguage();
  const phases = CROP_CALENDARS[farmData.crop] || CROP_CALENDARS['Wheat'];
  const currentMonth = MONTHS[new Date().getMonth()];

  return (
    <div className="space-y-4">
      <div className="agri-card">
        <div className="flex items-center gap-2 mb-3">
          <Calendar className="w-5 h-5 text-primary" />
          <h3 className="font-bold text-foreground">{t(lang, 'cropCalendar')}</h3>
        </div>
        <p className="text-sm text-muted-foreground mb-4">
          {t(lang, 'calendarFor')} {t(lang, farmData.crop.toLowerCase() as any)} — {farmData.location}
        </p>

        {/* Timeline */}
        <div className="space-y-3">
          {phases.map((phase, i) => (
            <div key={i} className={`p-4 rounded-2xl border-2 transition-all ${
              phase.months.includes(currentMonth) 
                ? 'border-primary bg-primary/10 shadow-md' 
                : 'border-border bg-card'
            }`}>
              <div className="flex items-center gap-3">
                <div className={`w-10 h-10 rounded-xl ${phase.color} flex items-center justify-center text-white`}>
                  {phase.icon}
                </div>
                <div className="flex-1">
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-foreground text-sm">{t(lang, phase.nameKey as any)}</span>
                    <span className="text-xs font-semibold bg-muted px-2 py-1 rounded-lg text-muted-foreground">{phase.months}</span>
                  </div>
                  <p className="text-xs text-muted-foreground mt-1">{t(lang, phase.description as any)}</p>
                </div>
              </div>
              {phase.months.includes(currentMonth) && (
                <div className="mt-2 flex items-center gap-1">
                  <span className="w-2 h-2 rounded-full bg-primary animate-pulse" />
                  <span className="text-xs font-bold text-primary">{t(lang, 'currentPhase')}</span>
                </div>
              )}
            </div>
          ))}
        </div>
      </div>

      {/* Month bar */}
      <div className="agri-card">
        <h4 className="text-sm font-bold text-foreground mb-3">{t(lang, 'yearOverview')}</h4>
        <div className="grid grid-cols-12 gap-1">
          {MONTHS.map((m, i) => {
            const active = phases.some(p => p.months.includes(m));
            const isCurrent = m === currentMonth;
            return (
              <div key={m} className="flex flex-col items-center">
                <div className={`w-full h-8 rounded-lg ${
                  isCurrent ? 'bg-primary' : active ? 'bg-primary/30' : 'bg-muted'
                }`} />
                <span className={`text-[8px] mt-1 font-semibold ${isCurrent ? 'text-primary' : 'text-muted-foreground'}`}>{m.charAt(0)}</span>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
