import React, { useEffect, useRef } from 'react';
import { useLanguage } from '@/hooks/useLanguage';
import { t } from '@/lib/languages';
import { Phone, Navigation, UserCheck, Star } from 'lucide-react';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';

interface Consultant {
  name: string;
  specialty: string;
  phone: string;
  rating: number;
  experience: string;
  lat: number;
  lng: number;
  distance: string;
}

const getMockConsultants = (): Consultant[] => [
  { name: 'Dr. Ramesh Kumar', specialty: 'cropDoctor', phone: '+91 98765 11111', rating: 4.8, experience: '15', lat: 11.018, lng: 76.958, distance: '1.5 km' },
  { name: 'Dr. Lakshmi Devi', specialty: 'soilExpert', phone: '+91 98765 22222', rating: 4.9, experience: '20', lat: 11.022, lng: 76.950, distance: '3.2 km' },
  { name: 'Suresh Agri Services', specialty: 'pestExpert', phone: '+91 98765 33333', rating: 4.5, experience: '10', lat: 11.010, lng: 76.965, distance: '4.8 km' },
  { name: 'Dr. Fatima Begum', specialty: 'irrigationExpert', phone: '+91 98765 44444', rating: 4.7, experience: '12', lat: 11.025, lng: 76.945, distance: '6.1 km' },
];

export default function ConsultantsTab() {
  const { lang } = useLanguage();
  const consultants = getMockConsultants();
  const mapRef = useRef<HTMLDivElement>(null);
  const mapInstanceRef = useRef<L.Map | null>(null);

  useEffect(() => {
    if (!mapRef.current || mapInstanceRef.current) return;

    const map = L.map(mapRef.current).setView([11.0168, 76.9558], 13);
    mapInstanceRef.current = map;

    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      attribution: '© OpenStreetMap',
    }).addTo(map);

    const icon = L.divIcon({
      html: '<div style="background:#2563eb;color:white;border-radius:50%;width:32px;height:32px;display:flex;align-items:center;justify-content:center;font-size:16px;border:2px solid white;box-shadow:0 2px 8px rgba(0,0,0,0.3);">👨‍⚕️</div>',
      iconSize: [32, 32],
      className: '',
    });

    consultants.forEach(c => {
      L.marker([c.lat, c.lng], { icon })
        .addTo(map)
        .bindPopup(`<b>${c.name}</b><br>📞 ${c.phone}`);
    });

    return () => {
      map.remove();
      mapInstanceRef.current = null;
    };
  }, []);

  const openDirections = (lat: number, lng: number) => {
    window.open(`https://www.google.com/maps/dir/?api=1&destination=${lat},${lng}`, '_blank');
  };

  return (
    <div className="space-y-4">
      <div className="agri-card text-center">
        <UserCheck className="w-10 h-10 mx-auto text-primary mb-2" />
        <h3 className="font-bold text-lg text-foreground">{t(lang, 'farmConsultants')}</h3>
        <p className="text-sm text-muted-foreground">{t(lang, 'consultantsNearby')}</p>
      </div>

      <div ref={mapRef} className="rounded-3xl overflow-hidden h-48 shadow-lg z-0" />

      {consultants.map((c, i) => (
        <div key={i} className="agri-card">
          <div className="flex items-start justify-between mb-2">
            <div>
              <h4 className="font-bold text-foreground">{c.name}</h4>
              <p className="text-xs text-muted-foreground">
                {t(lang, c.specialty as any)} • {c.distance}
              </p>
              <div className="flex items-center gap-1 mt-1">
                <Star className="w-3 h-3 text-secondary fill-secondary" />
                <span className="text-xs font-bold text-secondary">{c.rating}</span>
                <span className="text-xs text-muted-foreground">• {c.experience} {t(lang, 'yearsExp')}</span>
              </div>
            </div>
          </div>
          <div className="flex gap-2 mt-3">
            <a
              href={`tel:${c.phone}`}
              className="flex-1 bg-primary text-primary-foreground px-4 py-2.5 rounded-xl text-sm font-bold flex items-center justify-center gap-2 active:scale-95 transition-all"
            >
              <Phone className="w-4 h-4" /> {t(lang, 'callNow')}
            </a>
            <button
              onClick={() => openDirections(c.lat, c.lng)}
              className="flex-1 bg-secondary text-secondary-foreground px-4 py-2.5 rounded-xl text-sm font-bold flex items-center justify-center gap-2 active:scale-95 transition-all"
            >
              <Navigation className="w-4 h-4" /> {t(lang, 'getDirections')}
            </button>
          </div>
        </div>
      ))}
    </div>
  );
}
