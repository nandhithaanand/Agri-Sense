import React, { useMemo } from 'react';
import { useLanguage } from '@/hooks/useLanguage';
import { t } from '@/lib/languages';
import { type FarmData } from '@/components/OnboardingForm';
import { TrendingUp, TrendingDown, Minus, IndianRupee, BarChart3 } from 'lucide-react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Area, AreaChart } from 'recharts';

interface Props {
  farmData: FarmData;
}

interface MandiPrice {
  mandi: string;
  price: number;
  change: number;
  minPrice: number;
  maxPrice: number;
}

interface PriceTrend {
  month: string;
  price: number;
  msp: number;
}

const BASE_PRICES: Record<string, number> = {
  Wheat: 2275, Rice: 2183, Cotton: 6620, Sugarcane: 315, Maize: 2090, Millet: 2500,
};

const MONTH_NAMES: Record<string, string[]> = {
  en: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
  hi: ['जन', 'फर', 'मार्च', 'अप्रै', 'मई', 'जून', 'जुला', 'अग', 'सित', 'अक्टू', 'नव', 'दिस'],
  ta: ['ஜன', 'பிப்', 'மார்', 'ஏப்', 'மே', 'ஜூன்', 'ஜூலை', 'ஆக', 'செப்', 'அக்', 'நவ', 'டிச'],
  te: ['జన', 'ఫిబ్', 'మార్', 'ఏప్రి', 'మే', 'జూన్', 'జూలై', 'ఆగ', 'సెప్', 'అక్టో', 'నవ', 'డిస'],
  ml: ['ജനു', 'ഫെബ്', 'മാർ', 'ഏപ്രി', 'മേ', 'ജൂൺ', 'ജൂലൈ', 'ഓഗ', 'സെപ്', 'ഒക്ടോ', 'നവ', 'ഡിസ'],
  kn: ['ಜನ', 'ಫೆಬ್', 'ಮಾರ್', 'ಏಪ್ರಿ', 'ಮೇ', 'ಜೂನ್', 'ಜೂಲೈ', 'ಆಗ', 'ಸೆಪ್', 'ಅಕ್ಟೋ', 'ನವ', 'ಡಿಸ'],
  mr: ['जाने', 'फेब्', 'मार्च', 'एप्रि', 'मे', 'जून', 'जुलै', 'ऑग', 'सप्टें', 'ऑक्टो', 'नोव्हें', 'डिसें'],
  pa: ['ਜਨ', 'ਫਰ', 'ਮਾਰ', 'ਅਪ੍ਰੈ', 'ਮਈ', 'ਜੂਨ', 'ਜੁਲਾ', 'ਅਗ', 'ਸਤੰ', 'ਅਕ੍ਤੂ', 'ਨਵੰ', 'ਦਸੰ'],
  bn: ['জান', 'ফেব', 'মার্চ', 'এপ্রি', 'মে', 'জুন', 'জুলাই', 'আগ', 'সেপ', 'অক্টো', 'নভ', 'ডিস'],
  ur: ['جن', 'فر', 'مار', 'اپر', 'مئی', 'جون', 'جول', 'اگ', 'ستمب', 'اکتو', 'نومب', 'دسمب'],
};

function generateMandiPrices(crop: string, location: string): MandiPrice[] {
  const base = BASE_PRICES[crop] || 2000;
  const mandis = [
    `${location} Mandi`,
    'APMC Main Market',
    'District Agricultural Market',
    'State Cooperative Market',
    'e-NAM Portal',
  ];
  return mandis.map((mandi, i) => {
    const variance = (Math.sin(i * 7 + crop.length) * 0.1);
    const price = Math.round(base * (1 + variance));
    const change = Math.round((Math.sin(i * 3) * 5) * 10) / 10;
    return { mandi, price, change, minPrice: Math.round(price * 0.92), maxPrice: Math.round(price * 1.08) };
  });
}

function generateTrends(crop: string, lang: string): PriceTrend[] {
  const base = BASE_PRICES[crop] || 2000;
  const months = MONTH_NAMES[lang] || MONTH_NAMES.en;
  return months.map((month, i) => ({
    month,
    price: Math.round(base * (1 + Math.sin(i * 0.8) * 0.12)),
    msp: base,
  }));
}

export default function MarketPricesTab({ farmData }: Props) {
  const { lang } = useLanguage();
  const prices = useMemo(() => generateMandiPrices(farmData.crop, farmData.location), [farmData.crop, farmData.location]);
  const trends = useMemo(() => generateTrends(farmData.crop, lang), [farmData.crop, lang]);
  const msp = BASE_PRICES[farmData.crop] || 2000;

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="agri-card">
        <div className="flex items-center gap-2 mb-2">
          <IndianRupee className="w-5 h-5 text-primary" />
          <h3 className="font-bold text-foreground">{t(lang, 'marketPrices')}</h3>
        </div>
        <p className="text-sm text-muted-foreground">
          {t(lang, 'pricesFor')} {t(lang, farmData.crop.toLowerCase() as any)} — {farmData.location}
        </p>
        <div className="mt-3 p-3 bg-primary/10 rounded-xl flex items-center justify-between">
          <span className="text-sm font-semibold text-foreground">{t(lang, 'msp')}</span>
          <span className="text-lg font-black text-primary">₹{msp}/{t(lang, 'quintal')}</span>
        </div>
      </div>

      {/* Price trend chart - recharts area */}
      <div className="agri-card">
        <div className="flex items-center gap-2 mb-3">
          <BarChart3 className="w-5 h-5 text-primary" />
          <h4 className="font-bold text-foreground text-sm">{t(lang, 'priceTrend')}</h4>
        </div>
        <div className="h-48 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={trends} margin={{ top: 5, right: 5, left: -20, bottom: 0 }}>
              <defs>
                <linearGradient id="priceGradient" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="hsl(142, 50%, 32%)" stopOpacity={0.3} />
                  <stop offset="95%" stopColor="hsl(142, 50%, 32%)" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(40, 20%, 85%)" />
              <XAxis dataKey="month" tick={{ fontSize: 10 }} stroke="hsl(150, 10%, 45%)" />
              <YAxis tick={{ fontSize: 10 }} stroke="hsl(150, 10%, 45%)" />
              <Tooltip
                contentStyle={{ background: 'hsl(40, 40%, 98%)', border: '1px solid hsl(40, 20%, 85%)', borderRadius: '12px', fontSize: '12px' }}
                formatter={(value: number) => [`₹${value}`, '']}
              />
              <Area type="monotone" dataKey="price" stroke="hsl(142, 50%, 32%)" fillOpacity={1} fill="url(#priceGradient)" strokeWidth={2} />
              <Line type="monotone" dataKey="msp" stroke="hsl(0, 72%, 51%)" strokeDasharray="5 5" strokeWidth={1.5} dot={false} />
            </AreaChart>
          </ResponsiveContainer>
        </div>
        <div className="flex items-center gap-4 mt-2 text-xs text-muted-foreground">
          <span className="flex items-center gap-1"><span className="w-3 h-0.5 bg-primary inline-block rounded" /> {t(lang, 'marketPrices')}</span>
          <span className="flex items-center gap-1"><span className="w-3 h-0.5 bg-destructive inline-block rounded border-dashed" /> {t(lang, 'msp')}</span>
        </div>
      </div>

      {/* Mandi rates list */}
      <div className="space-y-2">
        {prices.map((p, i) => (
          <div key={i} className="agri-card">
            <div className="flex items-center justify-between">
              <div className="flex-1">
                <h4 className="font-bold text-foreground text-sm">{p.mandi}</h4>
                <div className="flex items-center gap-2 mt-1">
                  <span className="text-xs text-muted-foreground">
                    {t(lang, 'range')}: ₹{p.minPrice} - ₹{p.maxPrice}
                  </span>
                </div>
              </div>
              <div className="text-right">
                <span className="text-lg font-black text-foreground">₹{p.price}</span>
                <div className={`flex items-center justify-end gap-0.5 text-xs font-bold ${
                  p.change > 0 ? 'text-success' : p.change < 0 ? 'text-destructive' : 'text-muted-foreground'
                }`}>
                  {p.change > 0 ? <TrendingUp className="w-3 h-3" /> : p.change < 0 ? <TrendingDown className="w-3 h-3" /> : <Minus className="w-3 h-3" />}
                  {p.change > 0 ? '+' : ''}{p.change}%
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
