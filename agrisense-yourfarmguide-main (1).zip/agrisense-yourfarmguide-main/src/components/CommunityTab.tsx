import React, { useState, useEffect } from 'react';
import { useLanguage } from '@/hooks/useLanguage';
import { useSpeechRecognition } from '@/hooks/useSpeech';
import { t } from '@/lib/languages';
import { MessageSquare, ThumbsUp, Send, User, Clock, Mic, MicOff, ChevronDown, ChevronUp } from 'lucide-react';

interface ForumReply {
  id: number;
  author: string;
  message: string;
  timeAgo: string;
}

interface ForumPost {
  id: number;
  author: string;
  location: string;
  crop: string;
  message: string;
  likes: number;
  replies: ForumReply[];
  replyCount: number;
  timeAgo: string;
  liked: boolean;
}

const MOCK_POSTS: Record<string, ForumPost[]> = {
  en: [
    { id: 1, author: 'Ramesh Kumar', location: 'Punjab', crop: 'Wheat', message: 'My wheat leaves are turning yellow at the tips. Any advice on fertilizer dosage?', likes: 12, replies: [], replyCount: 5, timeAgo: '2h', liked: false },
    { id: 2, author: 'Lakshmi Devi', location: 'Tamil Nadu', crop: 'Rice', message: 'Best organic pest control method for rice paddy? I want to avoid chemicals.', likes: 24, replies: [], replyCount: 8, timeAgo: '4h', liked: false },
    { id: 3, author: 'Suresh Patil', location: 'Maharashtra', crop: 'Cotton', message: 'Got excellent yield this season with drip irrigation! Sharing my schedule for cotton growers.', likes: 45, replies: [], replyCount: 15, timeAgo: '6h', liked: false },
    { id: 4, author: 'Priya Singh', location: 'UP', crop: 'Sugarcane', message: 'When is the best time to apply urea for sugarcane in North India?', likes: 8, replies: [], replyCount: 3, timeAgo: '1d', liked: false },
  ],
  hi: [
    { id: 1, author: 'रमेश कुमार', location: 'पंजाब', crop: 'गेहूं', message: 'मेरे गेहूं की पत्तियों की नोक पीली हो रही है। खाद की मात्रा पर कोई सलाह?', likes: 12, replies: [], replyCount: 5, timeAgo: '2h', liked: false },
    { id: 2, author: 'लक्ष्मी देवी', location: 'तमिलनाडु', crop: 'चावल', message: 'धान के लिए सबसे अच्छा जैविक कीट नियंत्रण? मैं रसायनों से बचना चाहती हूं।', likes: 24, replies: [], replyCount: 8, timeAgo: '4h', liked: false },
    { id: 3, author: 'सुरेश पाटिल', location: 'महाराष्ट्र', crop: 'कपास', message: 'इस सीजन ड्रिप सिंचाई से शानदार उपज मिली! कपास उगाने वालों के लिए अपना शेड्यूल साझा कर रहा हूं।', likes: 45, replies: [], replyCount: 15, timeAgo: '6h', liked: false },
  ],
  ta: [
    { id: 1, author: 'ரமேஷ் குமார்', location: 'பஞ்சாப்', crop: 'கோதுமை', message: 'என் கோதுமை இலைகள் நுனியில் மஞ்சளாக மாறுகின்றன. உரம் அளவு பற்றி ஆலோசனை?', likes: 12, replies: [], replyCount: 5, timeAgo: '2h', liked: false },
    { id: 2, author: 'லக்ஷ்மி தேவி', location: 'தமிழ்நாடு', crop: 'அரிசி', message: 'நெல் வயலுக்கு சிறந்த இயற்கை பூச்சி கட்டுப்பாடு? ரசாயனங்களை தவிர்க்க விரும்புகிறேன்.', likes: 24, replies: [], replyCount: 8, timeAgo: '4h', liked: false },
  ],
};

export default function CommunityTab() {
  const { lang } = useLanguage();
  const { isListening, transcript, startListening, stopListening, setTranscript } = useSpeechRecognition(lang);
  const [posts, setPosts] = useState<ForumPost[]>([]);
  const [newPost, setNewPost] = useState('');
  const [replyingTo, setReplyingTo] = useState<number | null>(null);
  const [replyText, setReplyText] = useState('');
  const [expandedPost, setExpandedPost] = useState<number | null>(null);
  const [voiceTarget, setVoiceTarget] = useState<'post' | number>('post');

  useEffect(() => {
    const langPosts = MOCK_POSTS[lang] || MOCK_POSTS['en'];
    const saved = localStorage.getItem('communityPosts-' + lang);
    if (saved) {
      setPosts([...JSON.parse(saved), ...langPosts]);
    } else {
      setPosts(langPosts);
    }
  }, [lang]);

  useEffect(() => {
    if (transcript) {
      if (voiceTarget === 'post') {
        setNewPost(prev => prev + ' ' + transcript);
      } else {
        setReplyText(prev => prev + ' ' + transcript);
      }
      setTranscript('');
    }
  }, [transcript]);

  const handleLike = (id: number) => {
    setPosts(prev => prev.map(p => p.id === id ? { ...p, likes: p.liked ? p.likes - 1 : p.likes + 1, liked: !p.liked } : p));
  };

  const handlePost = () => {
    if (!newPost.trim()) return;
    const farmData = JSON.parse(localStorage.getItem('farmData') || '{}');
    const post: ForumPost = {
      id: Date.now(),
      author: t(lang, 'you' as any),
      location: farmData.location || '',
      crop: farmData.crop || '',
      message: newPost.trim(),
      likes: 0,
      replies: [],
      replyCount: 0,
      timeAgo: t(lang, 'justNow' as any),
      liked: false,
    };
    const updated = [post, ...posts];
    setPosts(updated);
    localStorage.setItem('communityPosts-' + lang, JSON.stringify([post]));
    setNewPost('');
  };

  const handleReply = (postId: number) => {
    if (!replyText.trim()) return;
    setPosts(prev => prev.map(p => {
      if (p.id === postId) {
        return {
          ...p,
          replies: [...p.replies, { id: Date.now(), author: t(lang, 'you' as any), message: replyText.trim(), timeAgo: t(lang, 'justNow' as any) }],
          replyCount: p.replyCount + 1,
        };
      }
      return p;
    }));
    setReplyText('');
    setReplyingTo(null);
  };

  const startVoiceForPost = () => {
    setVoiceTarget('post');
    startListening();
  };

  const startVoiceForReply = (postId: number) => {
    setVoiceTarget(postId);
    setReplyingTo(postId);
    startListening();
  };

  const commentLabel: Record<string, string> = {
    en: 'Write a comment...', hi: 'टिप्पणी लिखें...', ta: 'கருத்து எழுதுங்கள்...', te: 'వ్యాఖ్య రాయండి...',
    ml: 'അഭിപ്രായം എഴുതുക...', kn: 'ಕಾಮೆಂಟ್ ಬರೆಯಿರಿ...', mr: 'टिप्पणी लिहा...', pa: 'ਟਿੱਪਣੀ ਲਿਖੋ...',
    bn: 'মন্তব্য লিখুন...', ur: '...تبصرہ لکھیں',
  };

  return (
    <div className="space-y-4">
      {/* New post */}
      <div className="agri-card">
        <div className="flex items-center gap-2 mb-3">
          <MessageSquare className="w-5 h-5 text-primary" />
          <h3 className="font-bold text-foreground">{t(lang, 'community')}</h3>
        </div>
        <div className="flex gap-2">
          <button onClick={isListening && voiceTarget === 'post' ? stopListening : startVoiceForPost}
            className={`w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0 transition-all ${
              isListening && voiceTarget === 'post' ? 'bg-destructive mic-pulse' : 'bg-primary'
            }`}>
            {isListening && voiceTarget === 'post' ? <MicOff className="w-4 h-4 text-destructive-foreground" /> : <Mic className="w-4 h-4 text-primary-foreground" />}
          </button>
          <input
            value={newPost}
            onChange={e => setNewPost(e.target.value)}
            onKeyDown={e => e.key === 'Enter' && handlePost()}
            placeholder={t(lang, 'shareYourTip')}
            className="flex-1 px-4 py-3 rounded-xl bg-muted border border-border text-foreground text-sm focus:ring-2 focus:ring-primary outline-none"
          />
          <button onClick={handlePost} disabled={!newPost.trim()}
            className="px-4 py-3 rounded-xl bg-primary text-primary-foreground font-bold disabled:opacity-50 active:scale-95 transition-all">
            <Send className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Posts */}
      <div className="space-y-3">
        {posts.map(post => (
          <div key={post.id} className="agri-card">
            <div className="flex items-start gap-3">
              <div className="w-10 h-10 rounded-full bg-primary/20 flex items-center justify-center flex-shrink-0">
                <User className="w-5 h-5 text-primary" />
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 flex-wrap">
                  <span className="font-bold text-foreground text-sm">{post.author}</span>
                  {post.location && <span className="text-xs text-muted-foreground">📍 {post.location}</span>}
                  {post.crop && <span className="text-xs bg-primary/10 text-primary font-semibold px-2 py-0.5 rounded-lg">🌾 {post.crop}</span>}
                </div>
                <p className="text-sm text-foreground mt-1.5 leading-relaxed">{post.message}</p>
                <div className="flex items-center gap-4 mt-3">
                  <button onClick={() => handleLike(post.id)}
                    className={`flex items-center gap-1 text-xs font-semibold transition-all ${post.liked ? 'text-primary' : 'text-muted-foreground'}`}>
                    <ThumbsUp className="w-3.5 h-3.5" /> {post.likes}
                  </button>
                  <button onClick={() => setExpandedPost(expandedPost === post.id ? null : post.id)}
                    className="flex items-center gap-1 text-xs text-muted-foreground font-semibold">
                    <MessageSquare className="w-3.5 h-3.5" /> {post.replyCount + post.replies.length}
                    {expandedPost === post.id ? <ChevronUp className="w-3 h-3" /> : <ChevronDown className="w-3 h-3" />}
                  </button>
                  <button onClick={() => { setReplyingTo(replyingTo === post.id ? null : post.id); setReplyText(''); }}
                    className="text-xs text-primary font-semibold">
                    {t(lang, 'replies' as any)}
                  </button>
                  <span className="flex items-center gap-1 text-xs text-muted-foreground ml-auto">
                    <Clock className="w-3 h-3" /> {post.timeAgo}
                  </span>
                </div>

                {/* Replies section */}
                {expandedPost === post.id && post.replies.length > 0 && (
                  <div className="mt-3 space-y-2 border-l-2 border-primary/20 pl-3">
                    {post.replies.map(reply => (
                      <div key={reply.id} className="p-2 bg-muted rounded-lg">
                        <div className="flex items-center gap-2">
                          <span className="text-xs font-bold text-foreground">{reply.author}</span>
                          <span className="text-[10px] text-muted-foreground">{reply.timeAgo}</span>
                        </div>
                        <p className="text-xs text-foreground mt-1">{reply.message}</p>
                      </div>
                    ))}
                  </div>
                )}

                {/* Reply input */}
                {replyingTo === post.id && (
                  <div className="mt-3 flex gap-2">
                    <button onClick={isListening && voiceTarget === post.id ? stopListening : () => startVoiceForReply(post.id)}
                      className={`w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0 transition-all ${
                        isListening && voiceTarget === post.id ? 'bg-destructive mic-pulse' : 'bg-primary'
                      }`}>
                      {isListening && voiceTarget === post.id ? <MicOff className="w-3 h-3 text-destructive-foreground" /> : <Mic className="w-3 h-3 text-primary-foreground" />}
                    </button>
                    <input
                      value={replyText}
                      onChange={e => setReplyText(e.target.value)}
                      onKeyDown={e => e.key === 'Enter' && handleReply(post.id)}
                      placeholder={commentLabel[lang] || commentLabel.en}
                      className="flex-1 px-3 py-2 rounded-lg bg-muted border border-border text-foreground text-xs focus:ring-2 focus:ring-primary outline-none"
                    />
                    <button onClick={() => handleReply(post.id)} disabled={!replyText.trim()}
                      className="px-3 py-2 rounded-lg bg-primary text-primary-foreground text-xs font-bold disabled:opacity-50">
                      <Send className="w-3 h-3" />
                    </button>
                  </div>
                )}
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
