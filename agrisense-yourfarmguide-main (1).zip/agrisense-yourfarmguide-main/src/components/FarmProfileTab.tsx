import React, { useState, useEffect } from 'react';
import { useLanguage } from '@/hooks/useLanguage';
import { useSpeechRecognition } from '@/hooks/useSpeech';
import { t, parseSpeechForFarmData } from '@/lib/languages';
import { type FarmData } from '@/components/OnboardingForm';
import { Mic, MicOff, Save, User, Edit3 } from 'lucide-react';

const CROPS = ['Wheat', 'Rice', 'Cotton', 'Sugarcane', 'Maize', 'Millet'];

interface Props {
  farmData: FarmData;
  onUpdate: (data: FarmData) => void;
}

export default function FarmProfileTab({ farmData, onUpdate }: Props) {
  const { lang } = useLanguage();
  const { isListening, transcript, startListening, stopListening } = useSpeechRecognition(lang);
  const [editing, setEditing] = useState(false);
  const [form, setForm] = useState<FarmData>(farmData);

  useEffect(() => {
    setForm(farmData);
  }, [farmData]);

  useEffect(() => {
    if (transcript) {
      const parsed = parseSpeechForFarmData(transcript);
      setForm(prev => ({
        ...prev,
        ...(parsed.crop ? { crop: parsed.crop } : {}),
        ...(parsed.landSize ? { landSize: parsed.landSize } : {}),
        ...(parsed.location ? { location: parsed.location } : {}),
      }));
      setEditing(true);
    }
  }, [transcript]);

  const handleSave = () => {
    if (!form.location || !form.crop) return;
    localStorage.setItem('farmData', JSON.stringify(form));
    onUpdate(form);
    setEditing(false);
  };

  const cropKey = (c: string) => c.toLowerCase() as any;

  if (!editing) {
    return (
      <div className="space-y-4">
        <div className="agri-card">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-12 h-12 rounded-full bg-primary/20 flex items-center justify-center">
              <User className="w-6 h-6 text-primary" />
            </div>
            <div>
              <h3 className="font-bold text-foreground text-lg">{t(lang, 'farmProfile')}</h3>
              <p className="text-xs text-muted-foreground">{t(lang, 'welcome')}</p>
            </div>
          </div>

          <div className="space-y-3">
            <div className="flex justify-between p-3 bg-muted rounded-xl">
              <span className="text-muted-foreground text-sm">📍 {t(lang, 'location')}</span>
              <span className="font-bold text-foreground text-sm">{form.location}</span>
            </div>
            <div className="flex justify-between p-3 bg-muted rounded-xl">
              <span className="text-muted-foreground text-sm">🌾 {t(lang, 'crop')}</span>
              <span className="font-bold text-foreground text-sm">{t(lang, cropKey(form.crop))}</span>
            </div>
            <div className="flex justify-between p-3 bg-muted rounded-xl">
              <span className="text-muted-foreground text-sm">📏 {t(lang, 'landSize')}</span>
              <span className="font-bold text-foreground text-sm">{form.landSize} {t(lang, 'acres')}</span>
            </div>
            <div className="flex justify-between p-3 bg-muted rounded-xl">
              <span className="text-muted-foreground text-sm">💧 {t(lang, 'soilMoisture')}</span>
              <span className="font-bold text-foreground text-sm">{form.soilMoisture}{t(lang, 'percent')}</span>
            </div>
            <div className="flex justify-between p-3 bg-muted rounded-xl">
              <span className="text-muted-foreground text-sm">📅 {t(lang, 'sowingDate')}</span>
              <span className="font-bold text-foreground text-sm">{form.sowingDate || '—'}</span>
            </div>
          </div>

          <button
            onClick={() => setEditing(true)}
            className="w-full mt-4 py-3 rounded-2xl bg-primary text-primary-foreground font-bold flex items-center justify-center gap-2 active:scale-95 transition-all"
          >
            <Edit3 className="w-4 h-4" /> {t(lang, 'editProfile')}
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <div className="agri-card">
        <h3 className="font-bold text-foreground text-lg mb-4">{t(lang, 'editProfile')}</h3>

        {/* Voice input */}
        <div className="flex flex-col items-center mb-4">
          <button
            onClick={isListening ? stopListening : startListening}
            className={`w-16 h-16 rounded-full flex items-center justify-center transition-all ${
              isListening ? 'bg-destructive mic-pulse' : 'bg-primary'
            }`}
          >
            {isListening ? <MicOff className="w-7 h-7 text-destructive-foreground" /> : <Mic className="w-7 h-7 text-primary-foreground" />}
          </button>
          <p className="mt-2 text-xs text-muted-foreground">
            {isListening ? t(lang, 'listening') : t(lang, 'tapMicToSpeak')}
          </p>
        </div>

        <div className="space-y-4">
          <div>
            <label className="text-sm font-semibold text-foreground">{t(lang, 'location')}</label>
            <input
              value={form.location}
              onChange={e => setForm(f => ({ ...f, location: e.target.value }))}
              className="w-full mt-1 px-4 py-3 rounded-xl bg-card border border-border text-foreground focus:ring-2 focus:ring-primary outline-none"
            />
          </div>

          <div>
            <label className="text-sm font-semibold text-foreground">{t(lang, 'crop')}</label>
            <div className="grid grid-cols-3 gap-2 mt-1">
              {CROPS.map(c => (
                <button
                  key={c}
                  onClick={() => setForm(f => ({ ...f, crop: c }))}
                  className={`py-2 rounded-xl text-sm font-semibold border-2 transition-all ${
                    form.crop === c ? 'border-primary bg-primary text-primary-foreground' : 'border-border bg-card text-foreground'
                  }`}
                >
                  {t(lang, cropKey(c))}
                </button>
              ))}
            </div>
          </div>

          <div>
            <label className="text-sm font-semibold text-foreground">{t(lang, 'landSize')} ({t(lang, 'acres')})</label>
            <input
              type="number"
              value={form.landSize}
              onChange={e => setForm(f => ({ ...f, landSize: e.target.value }))}
              className="w-full mt-1 px-4 py-3 rounded-xl bg-card border border-border text-foreground focus:ring-2 focus:ring-primary outline-none"
            />
          </div>

          <div>
            <label className="text-sm font-semibold text-foreground">{t(lang, 'soilMoisture')} ({form.soilMoisture}{t(lang, 'percent')})</label>
            <input
              type="range" min="0" max="100" value={form.soilMoisture}
              onChange={e => setForm(f => ({ ...f, soilMoisture: Number(e.target.value) }))}
              className="w-full mt-1 accent-primary"
            />
          </div>

          <div>
            <label className="text-sm font-semibold text-foreground">{t(lang, 'sowingDate')}</label>
            <input
              type="date"
              value={form.sowingDate}
              onChange={e => setForm(f => ({ ...f, sowingDate: e.target.value }))}
              className="w-full mt-1 px-4 py-3 rounded-xl bg-card border border-border text-foreground focus:ring-2 focus:ring-primary outline-none"
            />
          </div>

          <button
            onClick={handleSave}
            disabled={!form.location || !form.crop}
            className="w-full bg-primary text-primary-foreground font-bold py-4 rounded-2xl shadow-lg flex items-center justify-center gap-2 disabled:opacity-50 active:scale-95 transition-all"
          >
            <Save className="w-5 h-5" /> {t(lang, 'saveFarm')}
          </button>
        </div>
      </div>
    </div>
  );
}
