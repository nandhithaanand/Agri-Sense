import React, { useState } from 'react';
import { useLanguage } from '@/hooks/useLanguage';
import { useSpeechRecognition } from '@/hooks/useSpeech';
import { t, parseSpeechForFarmData } from '@/lib/languages';

export interface FarmData {
  location: string;
  crop: string;
  sowingDate: string;
  soilMoisture: number;
  landSize: string;
}
import { Mic, MicOff, Save } from 'lucide-react';

interface Props {
  onComplete: (data: FarmData) => void;
}

const CROPS = ['Wheat', 'Rice', 'Cotton', 'Sugarcane', 'Maize', 'Millet'];

export default function OnboardingForm({ onComplete }: Props) {
  const { lang } = useLanguage();
  const { isListening, transcript, startListening, stopListening } = useSpeechRecognition(lang);
  const [form, setForm] = useState<FarmData>({
    location: '', crop: '', sowingDate: '', soilMoisture: 45, landSize: '',
  });
  const [showManual, setShowManual] = useState(false);

  // When speech finishes, parse and fill
  React.useEffect(() => {
    if (transcript) {
      const parsed = parseSpeechForFarmData(transcript);
      setForm(prev => ({
        ...prev,
        ...(parsed.crop ? { crop: parsed.crop } : {}),
        ...(parsed.landSize ? { landSize: parsed.landSize } : {}),
        ...(parsed.location ? { location: parsed.location } : {}),
      }));
      setShowManual(true);
    }
  }, [transcript]);

  const handleSubmit = () => {
    if (!form.location || !form.crop) return;
    localStorage.setItem('farmData', JSON.stringify(form));
    onComplete(form);
  };

  const cropKey = (c: string) => c.toLowerCase() as any;

  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-background p-4">
      <div className="w-full max-w-md">
        <h2 className="text-2xl font-black text-foreground mb-2">{t(lang, 'onboarding')}</h2>
        <p className="text-muted-foreground mb-6">{t(lang, 'tapMicToSpeak')}</p>

        {/* Voice input */}
        <div className="flex flex-col items-center mb-6">
          <button
            onClick={isListening ? stopListening : startListening}
            className={`w-24 h-24 rounded-full flex items-center justify-center transition-all ${
              isListening ? 'bg-destructive mic-pulse' : 'bg-primary hover:bg-primary/90'
            }`}
          >
            {isListening ? <MicOff className="w-10 h-10 text-destructive-foreground" /> : <Mic className="w-10 h-10 text-primary-foreground" />}
          </button>
          <p className="mt-3 text-sm text-muted-foreground font-medium">
            {isListening ? t(lang, 'listening') : t(lang, 'speakNow')}
          </p>
          {transcript && (
            <div className="mt-3 p-3 bg-accent rounded-xl text-sm text-accent-foreground w-full text-center">
              "{transcript}"
            </div>
          )}
        </div>

        {/* Manual toggle */}
        {!showManual && (
          <button onClick={() => setShowManual(true)} className="w-full text-center text-primary font-semibold underline mb-4">
            {t(lang, 'orFillManually')}
          </button>
        )}

        {showManual && (
          <div className="space-y-4">
            <div>
              <label className="text-sm font-semibold text-foreground">{t(lang, 'location')}</label>
              <input
                value={form.location}
                onChange={e => setForm(f => ({ ...f, location: e.target.value }))}
                className="w-full mt-1 px-4 py-3 rounded-xl bg-card border border-border text-foreground focus:ring-2 focus:ring-primary outline-none"
                placeholder="e.g. Palakkad, Kerala"
              />
            </div>

            <div>
              <label className="text-sm font-semibold text-foreground">{t(lang, 'crop')}</label>
              <div className="grid grid-cols-3 gap-2 mt-1">
                {CROPS.map(c => (
                  <button
                    key={c}
                    onClick={() => setForm(f => ({ ...f, crop: c }))}
                    className={`py-2 rounded-xl text-sm font-semibold border-2 transition-all ${
                      form.crop === c ? 'border-primary bg-primary text-primary-foreground' : 'border-border bg-card text-foreground'
                    }`}
                  >
                    {t(lang, cropKey(c))}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="text-sm font-semibold text-foreground">{t(lang, 'landSize')} ({t(lang, 'acres')})</label>
              <input
                type="number"
                value={form.landSize}
                onChange={e => setForm(f => ({ ...f, landSize: e.target.value }))}
                className="w-full mt-1 px-4 py-3 rounded-xl bg-card border border-border text-foreground focus:ring-2 focus:ring-primary outline-none"
                placeholder="e.g. 5"
              />
            </div>

            <div>
              <label className="text-sm font-semibold text-foreground">{t(lang, 'soilMoisture')} ({form.soilMoisture}{t(lang, 'percent')})</label>
              <input
                type="range" min="0" max="100" value={form.soilMoisture}
                onChange={e => setForm(f => ({ ...f, soilMoisture: Number(e.target.value) }))}
                className="w-full mt-1 accent-primary"
              />
            </div>

            <div>
              <label className="text-sm font-semibold text-foreground">{t(lang, 'sowingDate')}</label>
              <input
                type="date"
                value={form.sowingDate}
                onChange={e => setForm(f => ({ ...f, sowingDate: e.target.value }))}
                className="w-full mt-1 px-4 py-3 rounded-xl bg-card border border-border text-foreground focus:ring-2 focus:ring-primary outline-none"
              />
            </div>

            <button
              onClick={handleSubmit}
              disabled={!form.location || !form.crop}
              className="w-full bg-primary text-primary-foreground font-bold py-4 rounded-2xl shadow-lg flex items-center justify-center gap-2 disabled:opacity-50 active:scale-95 transition-all"
            >
              <Save className="w-5 h-5" /> {t(lang, 'saveFarm')}
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
