import React, { useEffect, useRef, useState } from 'react';
import { useLanguage } from '@/hooks/useLanguage';
import { t } from '@/lib/languages';
import { Satellite, AlertTriangle, Navigation, RefreshCw } from 'lucide-react';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';

interface NDVIData {
  healthy: number;
  moderate: number;
  stressed: number;
  poor: number;
  imageUrl?: string;
  lastUpdated: string;
  stressedCoords?: { lat: number; lng: number };
  alert?: string;
}

// Default field polygon (demo farm near Coimbatore)
const DEFAULT_FIELD: [number, number][] = [
  [11.0150, 76.9530],
  [11.0150, 76.9590],
  [11.0190, 76.9590],
  [11.0190, 76.9530],
];

const AGRO_API_KEY = ''; // User can add their Agromonitoring API key here

function generateMockNDVI(): NDVIData {
  const h = 35 + Math.floor(Math.random() * 20);
  const m = 20 + Math.floor(Math.random() * 15);
  const s = 10 + Math.floor(Math.random() * 12);
  const p = 100 - h - m - s;
  return {
    healthy: h,
    moderate: m,
    stressed: s,
    poor: Math.max(0, p),
    lastUpdated: new Date().toLocaleDateString(),
    stressedCoords: { lat: 11.0175, lng: 76.9565 },
  };
}

async function fetchNDVIFromAPI(polygon: [number, number][]): Promise<NDVIData | null> {
  if (!AGRO_API_KEY) return null;

  try {
    // Create polygon on Agromonitoring
    const geoJSON = {
      name: 'AgriSense Field',
      geo_json: {
        type: 'Feature',
        properties: {},
        geometry: {
          type: 'Polygon',
          coordinates: [polygon.map(([lat, lng]) => [lng, lat])],
        },
      },
    };

    const polyRes = await fetch(`https://api.agromonitoring.com/agro/1.0/polygons?appid=${AGRO_API_KEY}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(geoJSON),
    });

    let polyId: string;
    if (polyRes.ok) {
      const polyData = await polyRes.json();
      polyId = polyData.id;
    } else {
      // Try to get existing polygon
      const listRes = await fetch(`https://api.agromonitoring.com/agro/1.0/polygons?appid=${AGRO_API_KEY}`);
      const list = await listRes.json();
      if (list.length > 0) {
        polyId = list[0].id;
      } else {
        return null;
      }
    }

    // Fetch satellite imagery
    const end = Math.floor(Date.now() / 1000);
    const start = end - 30 * 24 * 60 * 60; // Last 30 days
    const satRes = await fetch(
      `https://api.agromonitoring.com/agro/1.0/image/search?start=${start}&end=${end}&polyid=${polyId}&appid=${AGRO_API_KEY}`
    );
    const satData = await satRes.json();

    // Filter out cloudy images (cloud_coverage > 20%)
    const clearImages = satData.filter((img: any) => (img.dc || 0) < 20);

    if (clearImages.length === 0) return null;

    const latest = clearImages[clearImages.length - 1];

    // Fetch NDVI stats
    const statsRes = await fetch(latest.stats.ndvi);
    const stats = await statsRes.json();

    // Categorize NDVI values
    const mean = stats.mean || 0.5;
    const healthy = Math.round(Math.max(0, (mean - 0.3) / 0.7) * 100);
    const moderate = Math.round(Math.min(30, (1 - mean) * 40));
    const stressed = Math.round(Math.min(20, (0.6 - mean) * 30));
    const poor = Math.max(0, 100 - healthy - moderate - stressed);

    return {
      healthy,
      moderate,
      stressed,
      poor,
      imageUrl: latest.image?.ndvi,
      lastUpdated: new Date(latest.dt * 1000).toLocaleDateString(),
      stressedCoords: { lat: 11.0175, lng: 76.9565 },
    };
  } catch (err) {
    console.error('Agromonitoring API error:', err);
    return null;
  }
}

export default function MapTab() {
  const { lang } = useLanguage();
  const mapRef = useRef<HTMLDivElement>(null);
  const mapInstanceRef = useRef<L.Map | null>(null);
  const [ndviData, setNdviData] = useState<NDVIData | null>(null);
  const [loading, setLoading] = useState(false);
  const [previousData, setPreviousData] = useState<NDVIData | null>(null);
  const [alert, setAlert] = useState<string | null>(null);

  const zones = [
    { key: 'healthy' as const, color: 'bg-green-500', ndviColor: '#22c55e', label: t(lang, 'healthy') },
    { key: 'moderate' as const, color: 'bg-yellow-400', ndviColor: '#facc15', label: t(lang, 'moderate') },
    { key: 'stressed' as const, color: 'bg-orange-500', ndviColor: '#f97316', label: t(lang, 'stressed') },
    { key: 'poor' as const, color: 'bg-red-500', ndviColor: '#ef4444', label: t(lang, 'critical') },
  ];

  const loadNDVI = async () => {
    setLoading(true);
    let data = await fetchNDVIFromAPI(DEFAULT_FIELD);
    if (!data) {
      data = generateMockNDVI();
    }

    // Check for stress increase alert
    if (previousData) {
      const prevStress = previousData.stressed + previousData.poor;
      const currStress = data.stressed + data.poor;
      if (currStress - prevStress > 10) {
        setAlert(t(lang, 'stressAlert'));
      }
    }

    setPreviousData(ndviData);
    setNdviData(data);
    setLoading(false);
  };

  useEffect(() => {
    loadNDVI();
  }, []);

  useEffect(() => {
    if (!mapRef.current || mapInstanceRef.current) return;

    const map = L.map(mapRef.current).setView([11.0170, 76.9560], 16);
    mapInstanceRef.current = map;

    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      attribution: '© OpenStreetMap',
    }).addTo(map);

    // Draw field boundary
    const fieldPolygon = L.polygon(DEFAULT_FIELD, {
      color: '#16a34a',
      weight: 3,
      fillOpacity: 0.1,
    }).addTo(map);

    // Simulate NDVI zones on map
    const ndviZones: [number, number][][] = [
      [[11.0150, 76.9530], [11.0150, 76.9560], [11.0170, 76.9560], [11.0170, 76.9530]], // bottom-left
      [[11.0150, 76.9560], [11.0150, 76.9590], [11.0170, 76.9590], [11.0170, 76.9560]], // bottom-right
      [[11.0170, 76.9530], [11.0170, 76.9560], [11.0190, 76.9560], [11.0190, 76.9530]], // top-left
      [[11.0170, 76.9560], [11.0170, 76.9590], [11.0190, 76.9590], [11.0190, 76.9560]], // top-right
    ];

    const zoneColors = ['#22c55e', '#22c55e', '#facc15', '#f97316'];
    ndviZones.forEach((coords, i) => {
      L.polygon(coords, {
        color: zoneColors[i],
        fillColor: zoneColors[i],
        fillOpacity: 0.5,
        weight: 1,
      }).addTo(map);
    });

    // Mark stressed area
    const stressIcon = L.divIcon({
      html: '<div style="background:#ef4444;color:white;border-radius:50%;width:28px;height:28px;display:flex;align-items:center;justify-content:center;font-size:14px;border:2px solid white;box-shadow:0 2px 8px rgba(0,0,0,0.3);">⚠️</div>',
      iconSize: [28, 28],
      className: '',
    });

    L.marker([11.0180, 76.9575], { icon: stressIcon })
      .addTo(map)
      .bindPopup(`<b>${t(lang, 'stressed')}</b><br>NDVI < 0.3`);

    return () => {
      map.remove();
      mapInstanceRef.current = null;
    };
  }, []);

  const goToStressedArea = () => {
    if (ndviData?.stressedCoords) {
      window.open(
        `https://www.google.com/maps/dir/?api=1&destination=${ndviData.stressedCoords.lat},${ndviData.stressedCoords.lng}`,
        '_blank'
      );
    }
  };

  return (
    <div className="space-y-4">
      <div className="agri-card text-center">
        <Satellite className="w-10 h-10 mx-auto text-primary mb-2" />
        <h3 className="font-bold text-lg text-foreground">{t(lang, 'satelliteHealth')}</h3>
        <p className="text-sm text-muted-foreground">NDVI • Sentinel-2</p>
      </div>

      {alert && (
        <div className="agri-card border-destructive bg-destructive/10">
          <div className="flex items-center gap-2">
            <AlertTriangle className="w-5 h-5 text-destructive flex-shrink-0" />
            <p className="text-sm font-bold text-destructive">{alert}</p>
          </div>
        </div>
      )}

      {/* Leaflet Map */}
      <div ref={mapRef} className="rounded-3xl overflow-hidden h-56 shadow-lg z-0" />

      {/* Health Zone Breakdown */}
      {ndviData && (
        <div className="agri-card">
          <div className="flex items-center justify-between mb-3">
            <h4 className="font-bold text-foreground">{t(lang, 'fieldHealthZones')}</h4>
            <button
              onClick={loadNDVI}
              disabled={loading}
              className="flex items-center gap-1 text-xs font-bold text-primary"
            >
              <RefreshCw className={`w-3 h-3 ${loading ? 'animate-spin' : ''}`} />
              {loading ? '...' : t(lang, 'refresh')}
            </button>
          </div>
          <div className="space-y-3">
            {zones.map(z => (
              <div key={z.key} className="flex items-center gap-3">
                <div className={`w-4 h-4 rounded-full ${z.color}`} />
                <span className="flex-1 text-sm font-medium text-foreground">{z.label}</span>
                <div className="w-24 bg-muted rounded-full h-2.5 overflow-hidden">
                  <div
                    className={`h-full rounded-full ${z.color}`}
                    style={{ width: `${ndviData[z.key]}%` }}
                  />
                </div>
                <span className="text-sm font-bold text-muted-foreground w-10 text-right">
                  {ndviData[z.key]}%
                </span>
              </div>
            ))}
          </div>
          <p className="text-xs text-muted-foreground mt-3">
            {t(lang, 'lastUpdated')}: {ndviData.lastUpdated}
          </p>
        </div>
      )}

      {/* Go to stressed area */}
      {ndviData && (ndviData.stressed > 15 || ndviData.poor > 5) && (
        <button
          onClick={goToStressedArea}
          className="w-full agri-card flex items-center justify-center gap-2 bg-destructive/10 border-destructive/30 active:scale-95 transition-all"
        >
          <Navigation className="w-5 h-5 text-destructive" />
          <span className="font-bold text-destructive text-sm">{t(lang, 'goToStressed')}</span>
        </button>
      )}

      {!AGRO_API_KEY && (
        <p className="text-xs text-center text-muted-foreground">
          {t(lang, 'demoMode')} — {t(lang, 'addApiKey')}
        </p>
      )}
    </div>
  );
}
