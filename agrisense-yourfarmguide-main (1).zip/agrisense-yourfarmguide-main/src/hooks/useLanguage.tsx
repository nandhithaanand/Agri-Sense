import React, { createContext, useContext, useState, useEffect, type ReactNode } from 'react';
import { type LangCode, getLangMeta, type LangMeta } from '@/lib/languages';

interface LanguageContextType {
  lang: LangCode;
  meta: LangMeta;
  setLang: (code: LangCode) => void;
  isRTL: boolean;
}

const LanguageContext = createContext<LanguageContextType>({
  lang: 'en',
  meta: getLangMeta('en'),
  setLang: () => {},
  isRTL: false,
});

export function LanguageProvider({ children }: { children: ReactNode }) {
  const [lang, setLangState] = useState<LangCode>(() => {
    return (localStorage.getItem('agrisense-lang') as LangCode) || 'en';
  });

  const setLang = (code: LangCode) => {
    setLangState(code);
    localStorage.setItem('agrisense-lang', code);
  };

  const meta = getLangMeta(lang);
  const isRTL = meta.rtl;

  useEffect(() => {
    document.documentElement.dir = isRTL ? 'rtl' : 'ltr';
  }, [isRTL]);

  return (
    <LanguageContext.Provider value={{ lang, meta, setLang, isRTL }}>
      {children}
    </LanguageContext.Provider>
  );
}

export const useLanguage = () => useContext(LanguageContext);
