export type LangCode = 'en' | 'hi' | 'ta' | 'te' | 'ml' | 'kn' | 'mr' | 'pa' | 'bn' | 'ur';

export interface LangMeta {
  code: LangCode;
  name: string;
  nativeName: string;
  speechCode: string;
  rtl: boolean;
}

export const LANGUAGES: LangMeta[] = [
  { code: 'en', name: 'English', nativeName: 'English', speechCode: 'en-IN', rtl: false },
  { code: 'hi', name: 'Hindi', nativeName: 'हिन्दी', speechCode: 'hi-IN', rtl: false },
  { code: 'ta', name: 'Tamil', nativeName: 'தமிழ்', speechCode: 'ta-IN', rtl: false },
  { code: 'te', name: 'Telugu', nativeName: 'తెలుగు', speechCode: 'te-IN', rtl: false },
  { code: 'ml', name: 'Malayalam', nativeName: 'മലയാളം', speechCode: 'ml-IN', rtl: false },
  { code: 'kn', name: 'Kannada', nativeName: 'ಕನ್ನಡ', speechCode: 'kn-IN', rtl: false },
  { code: 'mr', name: 'Marathi', nativeName: 'मराठी', speechCode: 'mr-IN', rtl: false },
  { code: 'pa', name: 'Punjabi', nativeName: 'ਪੰਜਾਬੀ', speechCode: 'pa-IN', rtl: false },
  { code: 'bn', name: 'Bengali', nativeName: 'বাংলা', speechCode: 'bn-IN', rtl: false },
  { code: 'ur', name: 'Urdu', nativeName: 'اردو', speechCode: 'ur-PK', rtl: true },
];

type TranslationKeys =
  | 'appName' | 'tagline' | 'selectLanguage' | 'getStarted'
  | 'dashboard' | 'scan' | 'map' | 'shops' | 'assistant' | 'calendar' | 'community' | 'prices'
  | 'onboarding' | 'farmProfile' | 'location' | 'crop' | 'sowingDate' | 'soilMoisture' | 'landSize' | 'saveFarm'
  | 'speakNow' | 'tapMicToSpeak' | 'orFillManually'
  | 'weatherAdvisory' | 'playAudio' | 'stopAudio'
  | 'temperature' | 'humidity' | 'rainfall'
  | 'heatStress' | 'irrigationAdvice' | 'pestRiskAlert' | 'goodConditions'
  | 'pestDetection' | 'uploadLeaf' | 'scanning' | 'diseaseDetected' | 'treatment' | 'dosage' | 'timing'
  | 'satelliteHealth' | 'healthy' | 'moderate' | 'stressed' | 'critical'
  | 'nearbyShops' | 'distance' | 'available' | 'callNow'
  | 'voiceAssistant' | 'askQuestion' | 'listening' | 'thinking'
  | 'offline' | 'online' | 'offlineMode' | 'lastSynced' | 'syncNow'
  | 'acres' | 'percent' | 'celsius'
  | 'welcome' | 'farmSaved' | 'noData'
  | 'wheat' | 'rice' | 'cotton' | 'sugarcane' | 'maize' | 'millet'
  | 'cropCalendar' | 'calendarFor' | 'currentPhase' | 'yearOverview'
  | 'landPreparation' | 'sowing' | 'irrigation' | 'harvesting'
  | 'plowAndLevel' | 'sowSeeds' | 'waterRegularly' | 'harvestCrop' | 'transplantSeedlings' | 'maintainWaterLevel' | 'pickBolls' | 'plantSetts' | 'cutCanes'
  | 'shareYourTip' | 'replies' | 'you' | 'justNow'
  | 'marketPrices' | 'pricesFor' | 'msp' | 'quintal' | 'priceTrend' | 'range'
  | 'editProfile' | 'waterAdvisory'
  | 'farmConsultants' | 'consultantsNearby' | 'yearsExp' | 'getDirections'
  | 'cropDoctor' | 'soilExpert' | 'pestExpert' | 'irrigationExpert'
  | 'fieldHealthZones' | 'refresh' | 'lastUpdated' | 'stressAlert' | 'goToStressed' | 'demoMode' | 'addApiKey';

type Translations = Record<TranslationKeys, string>;

const translations: Record<LangCode, Translations> = {
  en: {
    appName: 'AgriSense', tagline: 'Smart Farming Intelligence', selectLanguage: 'Select Your Language', getStarted: 'Get Started',
    dashboard: 'Dashboard', scan: 'Scan', map: 'Map', shops: 'Shops', assistant: 'Assistant',
    onboarding: 'Farm Setup', farmProfile: 'Farm Profile', location: 'Location', crop: 'Crop', sowingDate: 'Sowing Date', soilMoisture: 'Soil Moisture', landSize: 'Land Size', saveFarm: 'Save Farm',
    speakNow: 'Speak Now', tapMicToSpeak: 'Tap the mic and tell us about your farm', orFillManually: 'Or fill manually',
    weatherAdvisory: 'Weather Advisory', playAudio: '🔊 Play Audio', stopAudio: '⏹ Stop',
    temperature: 'Temperature', humidity: 'Humidity', rainfall: 'Rainfall',
    heatStress: 'Heat stress detected! Provide shade and extra irrigation.', irrigationAdvice: 'Low moisture. Irrigate 20mm tomorrow morning.', pestRiskAlert: 'High humidity — pest risk! Monitor leaves closely.', goodConditions: 'Conditions are good. Continue regular care.',
    pestDetection: 'Crop Doctor', uploadLeaf: 'Upload Leaf Image', scanning: 'Scanning...', diseaseDetected: 'Disease Detected', treatment: 'Treatment', dosage: 'Dosage', timing: 'Timing',
    satelliteHealth: 'Satellite Health', healthy: 'Healthy', moderate: 'Moderate', stressed: 'Stressed', critical: 'Critical',
    nearbyShops: 'Nearby Agri Shops', distance: 'Distance', available: 'Available', callNow: 'Call Now',
    voiceAssistant: 'Voice Assistant', askQuestion: 'Ask a question about farming...', listening: 'Listening...', thinking: 'Thinking...',
    offline: 'Offline', online: 'Online', offlineMode: 'Offline Mode', lastSynced: 'Last synced', syncNow: 'Sync Now',
    acres: 'acres', percent: '%', celsius: '°C',
    welcome: 'Welcome to AgriSense!', farmSaved: 'Farm profile saved!', noData: 'No data yet. Complete onboarding first.',
    wheat: 'Wheat', rice: 'Rice', cotton: 'Cotton', sugarcane: 'Sugarcane', maize: 'Maize', millet: 'Millet',
    cropCalendar: 'Crop Calendar', calendarFor: 'Schedule for', currentPhase: 'Current Phase', yearOverview: 'Year Overview',
    landPreparation: 'Land Preparation', sowing: 'Sowing', irrigation: 'Irrigation', harvesting: 'Harvesting',
    plowAndLevel: 'Plow and level the field', sowSeeds: 'Sow seeds at proper spacing', waterRegularly: 'Water regularly as needed', harvestCrop: 'Harvest when crop is mature',
    transplantSeedlings: 'Transplant seedlings to paddy field', maintainWaterLevel: 'Maintain standing water level', pickBolls: 'Pick cotton bolls when open', plantSetts: 'Plant sugarcane setts', cutCanes: 'Cut mature canes',
    community: 'Community', shareYourTip: 'Share a tip or ask a question...', replies: 'replies', you: 'You', justNow: 'Just now',
    calendar: 'Calendar', prices: 'Prices',
    marketPrices: 'Market Prices', pricesFor: 'Mandi rates for', msp: 'MSP (Min Support Price)', quintal: 'quintal', priceTrend: 'Price Trend (12 months)', range: 'Range',
    editProfile: 'Edit Profile', waterAdvisory: 'Water Advisory',
    farmConsultants: 'Farm Consultants', consultantsNearby: 'Expert consultants near you', yearsExp: 'years exp.', getDirections: 'Directions',
    cropDoctor: 'Crop Doctor', soilExpert: 'Soil Expert', pestExpert: 'Pest Expert', irrigationExpert: 'Irrigation Expert',
    fieldHealthZones: 'Field Health Zones', refresh: 'Refresh', lastUpdated: 'Last updated', stressAlert: '⚠️ Crop stress increased over 10%! Check your field immediately.', goToStressed: 'Navigate to Stressed Area', demoMode: 'Demo mode', addApiKey: 'Add Agromonitoring API key for live data',
  },
  hi: {
    appName: 'एग्रीसेंस', tagline: 'स्मार्ट कृषि बुद्धिमत्ता', selectLanguage: 'अपनी भाषा चुनें', getStarted: 'शुरू करें',
    dashboard: 'डैशबोर्ड', scan: 'स्कैन', map: 'नक्शा', shops: 'दुकानें', assistant: 'सहायक',
    onboarding: 'खेत सेटअप', farmProfile: 'खेत प्रोफ़ाइल', location: 'स्थान', crop: 'फसल', sowingDate: 'बुवाई तिथि', soilMoisture: 'मिट्टी की नमी', landSize: 'भूमि का आकार', saveFarm: 'खेत सहेजें',
    speakNow: 'अभी बोलें', tapMicToSpeak: 'माइक दबाकर अपने खेत के बारे में बताएं', orFillManually: 'या मैन्युअल भरें',
    weatherAdvisory: 'मौसम सलाह', playAudio: '🔊 ऑडियो चलाएं', stopAudio: '⏹ रुकें',
    temperature: 'तापमान', humidity: 'नमी', rainfall: 'बारिश',
    heatStress: 'गर्मी का तनाव! छाया और अतिरिक्त सिंचाई दें।', irrigationAdvice: 'नमी कम है। कल सुबह 20mm सिंचाई करें।', pestRiskAlert: 'उच्च नमी — कीट का खतरा! पत्तियों की जांच करें।', goodConditions: 'स्थिति अच्छी है। नियमित देखभाल जारी रखें।',
    pestDetection: 'फसल डॉक्टर', uploadLeaf: 'पत्ती की तस्वीर अपलोड करें', scanning: 'स्कैन हो रहा है...', diseaseDetected: 'रोग मिला', treatment: 'उपचार', dosage: 'खुराक', timing: 'समय',
    satelliteHealth: 'उपग्रह स्वास्थ्य', healthy: 'स्वस्थ', moderate: 'मध्यम', stressed: 'तनावग्रस्त', critical: 'गंभीर',
    nearbyShops: 'पास की कृषि दुकानें', distance: 'दूरी', available: 'उपलब्ध', callNow: 'अभी कॉल करें',
    voiceAssistant: 'वॉयस सहायक', askQuestion: 'खेती के बारे में सवाल पूछें...', listening: 'सुन रहे हैं...', thinking: 'सोच रहे हैं...',
    offline: 'ऑफ़लाइन', online: 'ऑनलाइन', offlineMode: 'ऑफ़लाइन मोड', lastSynced: 'अंतिम सिंक', syncNow: 'अभी सिंक करें',
    acres: 'एकड़', percent: '%', celsius: '°C',
    welcome: 'एग्रीसेंस में आपका स्वागत है!', farmSaved: 'खेत प्रोफ़ाइल सहेजी गई!', noData: 'अभी कोई डेटा नहीं। पहले ऑनबोर्डिंग पूरी करें।',
    wheat: 'गेहूं', rice: 'चावल', cotton: 'कपास', sugarcane: 'गन्ना', maize: 'मक्का', millet: 'बाजरा',
    cropCalendar: 'फसल कैलेंडर', calendarFor: 'अनुसूची', currentPhase: 'वर्तमान चरण', yearOverview: 'वार्षिक अवलोकन',
    landPreparation: 'भूमि तैयारी', sowing: 'बुवाई', irrigation: 'सिंचाई', harvesting: 'कटाई',
    plowAndLevel: 'खेत की जुताई और समतल करें', sowSeeds: 'उचित दूरी पर बीज बोएं', waterRegularly: 'नियमित रूप से पानी दें', harvestCrop: 'फसल पकने पर काटें',
    transplantSeedlings: 'धान के खेत में पौध रोपें', maintainWaterLevel: 'खड़े पानी का स्तर बनाए रखें', pickBolls: 'कपास के गोले चुनें', plantSetts: 'गन्ने की पेड़ियां लगाएं', cutCanes: 'पके गन्ने काटें',
    community: 'समुदाय', shareYourTip: 'सुझाव साझा करें या प्रश्न पूछें...', replies: 'जवाब', you: 'आप', justNow: 'अभी',
    calendar: 'कैलेंडर', prices: 'भाव',
    marketPrices: 'बाज़ार भाव', pricesFor: 'मंडी भाव', msp: 'MSP (न्यूनतम समर्थन मूल्य)', quintal: 'क्विंटल', priceTrend: 'मूल्य रुझान (12 महीने)', range: 'सीमा',
    editProfile: 'प्रोफ़ाइल संपादित करें', waterAdvisory: 'पानी सलाह',
    farmConsultants: 'कृषि सलाहकार', consultantsNearby: 'आपके पास के विशेषज्ञ सलाहकार', yearsExp: 'वर्ष अनुभव', getDirections: 'रास्ता',
    cropDoctor: 'फसल डॉक्टर', soilExpert: 'मिट्टी विशेषज्ञ', pestExpert: 'कीट विशेषज्ञ', irrigationExpert: 'सिंचाई विशेषज्ञ',
    fieldHealthZones: 'खेत स्वास्थ्य क्षेत्र', refresh: 'रिफ्रेश', lastUpdated: 'अंतिम अपडेट', stressAlert: '⚠️ फसल तनाव 10% से अधिक बढ़ गया! तुरंत खेत की जांच करें।', goToStressed: 'तनावग्रस्त क्षेत्र पर जाएं', demoMode: 'डेमो मोड', addApiKey: 'लाइव डेटा के लिए Agromonitoring API कुंजी जोड़ें',
  },
  ta: {
    appName: 'அக்ரிசென்ஸ்', tagline: 'ஸ்மார்ட் விவசாய நுண்ணறிவு', selectLanguage: 'உங்கள் மொழியைத் தேர்ந்தெடுக்கவும்', getStarted: 'தொடங்கு',
    dashboard: 'டாஷ்போர்ட்', scan: 'ஸ்கேன்', map: 'வரைபடம்', shops: 'கடைகள்', assistant: 'உதவியாளர்',
    onboarding: 'பண்ணை அமைப்பு', farmProfile: 'பண்ணை விவரம்', location: 'இடம்', crop: 'பயிர்', sowingDate: 'விதைப்பு தேதி', soilMoisture: 'மண் ஈரப்பதம்', landSize: 'நிலம் அளவு', saveFarm: 'பண்ணை சேமி',
    speakNow: 'இப்போது பேசுங்கள்', tapMicToSpeak: 'மைக் அழுத்தி உங்கள் பண்ணையைப் பற்றி சொல்லுங்கள்', orFillManually: 'அல்லது கைமுறையாக நிரப்பவும்',
    weatherAdvisory: 'வானிலை ஆலோசனை', playAudio: '🔊 ஆடியோ இயக்கு', stopAudio: '⏹ நிறுத்து',
    temperature: 'வெப்பநிலை', humidity: 'ஈரப்பதம்', rainfall: 'மழை',
    heatStress: 'வெப்ப அழுத்தம்! நிழல் மற்றும் கூடுதல் பாசனம் வழங்கவும்.', irrigationAdvice: 'ஈரப்பதம் குறைவு. நாளை காலை 20mm பாசனம் செய்யவும்.', pestRiskAlert: 'அதிக ஈரப்பதம் — பூச்சி ஆபத்து! இலைகளை கவனியுங்கள்.', goodConditions: 'நிலைமைகள் நல்லவை. வழக்கமான பராமரிப்பு தொடரவும்.',
    pestDetection: 'பயிர் மருத்துவர்', uploadLeaf: 'இலை படம் பதிவேற்றவும்', scanning: 'ஸ்கேன் செய்கிறது...', diseaseDetected: 'நோய் கண்டறியப்பட்டது', treatment: 'சிகிச்சை', dosage: 'அளவு', timing: 'நேரம்',
    satelliteHealth: 'செயற்கைக்கோள் ஆரோக்கியம்', healthy: 'ஆரோக்கியம்', moderate: 'மிதமான', stressed: 'அழுத்தம்', critical: 'மோசமான',
    nearbyShops: 'அருகிலுள்ள விவசாய கடைகள்', distance: 'தூரம்', available: 'கிடைக்கும்', callNow: 'இப்போது அழைக்கவும்',
    voiceAssistant: 'குரல் உதவியாளர்', askQuestion: 'விவசாயம் பற்றி கேள்வி கேளுங்கள்...', listening: 'கேட்கிறது...', thinking: 'யோசிக்கிறது...',
    offline: 'ஆஃப்லைன்', online: 'ஆன்லைன்', offlineMode: 'ஆஃப்லைன் பயன்முறை', lastSynced: 'கடைசி ஒத்திசைவு', syncNow: 'இப்போது ஒத்திசை',
    acres: 'ஏக்கர்', percent: '%', celsius: '°C',
    welcome: 'அக்ரிசென்ஸுக்கு வரவேற்கிறோம்!', farmSaved: 'பண்ணை விவரம் சேமிக்கப்பட்டது!', noData: 'இன்னும் தரவு இல்லை. முதலில் ஆன்போர்டிங் முடிக்கவும்.',
    wheat: 'கோதுமை', rice: 'அரிசி', cotton: 'பருத்தி', sugarcane: 'கரும்பு', maize: 'மக்காச்சோளம்', millet: 'கம்பு',
    cropCalendar: 'பயிர் நாட்காட்டி', calendarFor: 'அட்டவணை', currentPhase: 'தற்போதைய நிலை', yearOverview: 'ஆண்டு கண்ணோட்டம்',
    landPreparation: 'நிலம் தயாரிப்பு', sowing: 'விதைப்பு', irrigation: 'பாசனம்', harvesting: 'அறுவடை',
    plowAndLevel: 'நிலத்தை உழுது சமன் செய்யவும்', sowSeeds: 'சரியான இடைவெளியில் விதைக்கவும்', waterRegularly: 'தேவையான போது தண்ணீர் பாய்ச்சவும்', harvestCrop: 'பயிர் முதிர்ச்சி அடைந்ததும் அறுவடை செய்யவும்',
    transplantSeedlings: 'நாற்றுகளை நடவும்', maintainWaterLevel: 'நிற்கும் நீர் மட்டத்தை பராமரிக்கவும்', pickBolls: 'பருத்தி காய்களை பறிக்கவும்', plantSetts: 'கரும்பு நடவும்', cutCanes: 'முதிர்ந்த கரும்புகளை வெட்டவும்',
    community: 'சமூகம்', shareYourTip: 'குறிப்பு பகிரவும் அல்லது கேள்வி கேளுங்கள்...', replies: 'பதில்கள்', you: 'நீங்கள்', justNow: 'இப்போதே',
    calendar: 'நாட்காட்டி', prices: 'விலைகள்',
    marketPrices: 'சந்தை விலைகள்', pricesFor: 'மண்டி விலைகள்', msp: 'MSP (குறைந்தபட்ச ஆதரவு விலை)', quintal: 'குவிண்டால்', priceTrend: 'விலை போக்கு (12 மாதங்கள்)', range: 'எல்லை',
    editProfile: 'சுயவிவரம் திருத்து', waterAdvisory: 'நீர் ஆலோசனை',
    farmConsultants: 'விவசாய ஆலோசகர்கள்', consultantsNearby: 'உங்களுக்கு அருகிலுள்ள நிபுணர்கள்', yearsExp: 'ஆண்டு அனுபவம்', getDirections: 'வழிகாட்டு',
    cropDoctor: 'பயிர் மருத்துவர்', soilExpert: 'மண் நிபுணர்', pestExpert: 'பூச்சி நிபுணர்', irrigationExpert: 'பாசன நிபுணர்',
    fieldHealthZones: 'வயல் ஆரோக்கிய மண்டலங்கள்', refresh: 'புதுப்பி', lastUpdated: 'கடைசி புதுப்பிப்பு', stressAlert: '⚠️ பயிர் அழுத்தம் 10%க்கு மேல் அதிகரித்தது! உடனே வயலை சரிபாருங்கள்.', goToStressed: 'அழுத்த பகுதிக்கு செல்', demoMode: 'டெமோ பயன்முறை', addApiKey: 'நேரடி தரவுக்கு API விசை சேர்க்கவும்',
  },
  te: {
    appName: 'అగ్రిసెన్స్', tagline: 'స్మార్ట్ వ్యవసాయ మేధస్సు', selectLanguage: 'మీ భాషను ఎంచుకోండి', getStarted: 'ప్రారంభించు',
    dashboard: 'డాష్‌బోర్డ్', scan: 'స్కాన్', map: 'మ్యాప్', shops: 'దుకాణాలు', assistant: 'సహాయకుడు',
    onboarding: 'పొలం సెటప్', farmProfile: 'పొలం ప్రొఫైల్', location: 'ప్రదేశం', crop: 'పంట', sowingDate: 'విత్తన తేదీ', soilMoisture: 'నేల తేమ', landSize: 'భూమి పరిమాణం', saveFarm: 'పొలం సేవ్',
    speakNow: 'ఇప్పుడు మాట్లాడండి', tapMicToSpeak: 'మైక్ నొక్కి మీ పొలం గురించి చెప్పండి', orFillManually: 'లేదా మాన్యువల్‌గా నింపండి',
    weatherAdvisory: 'వాతావరణ సలహా', playAudio: '🔊 ఆడియో ప్లే', stopAudio: '⏹ ఆపు',
    temperature: 'ఉష్ణోగ్రత', humidity: 'తేమ', rainfall: 'వర్షపాతం',
    heatStress: 'వేడి ఒత్తిడి! నీడ మరియు అదనపు నీటిపారుదల అందించండి.', irrigationAdvice: 'తేమ తక్కువ. రేపు ఉదయం 20mm నీటిపారుదల చేయండి.', pestRiskAlert: 'అధిక తేమ — పురుగుల ప్రమాదం! ఆకులను పరిశీలించండి.', goodConditions: 'పరిస్థితులు బాగున్నాయి. సాధారణ సంరక్షణ కొనసాగించండి.',
    pestDetection: 'పంట వైద్యుడు', uploadLeaf: 'ఆకు చిత్రం అప్‌లోడ్', scanning: 'స్కాన్ అవుతోంది...', diseaseDetected: 'వ్యాధి గుర్తించబడింది', treatment: 'చికిత్స', dosage: 'మోతాదు', timing: 'సమయం',
    satelliteHealth: 'ఉపగ్రహ ఆరోగ్యం', healthy: 'ఆరోగ్యం', moderate: 'మధ్యస్థం', stressed: 'ఒత్తిడి', critical: 'తీవ్రమైన',
    nearbyShops: 'సమీపంలోని వ్యవసాయ దుకాణాలు', distance: 'దూరం', available: 'అందుబాటు', callNow: 'ఇప్పుడు కాల్ చేయండి',
    voiceAssistant: 'వాయిస్ సహాయకుడు', askQuestion: 'వ్యవసాయం గురించి ప్రశ్న అడగండి...', listening: 'వింటోంది...', thinking: 'ఆలోచిస్తోంది...',
    offline: 'ఆఫ్‌లైన్', online: 'ఆన్‌లైన్', offlineMode: 'ఆఫ్‌లైన్ మోడ్', lastSynced: 'చివరి సింక్', syncNow: 'ఇప్పుడు సింక్',
    acres: 'ఎకరాలు', percent: '%', celsius: '°C',
    welcome: 'అగ్రిసెన్స్‌కు స్వాగతం!', farmSaved: 'పొలం ప్రొఫైల్ సేవ్ అయింది!', noData: 'ఇంకా డేటా లేదు. ముందుగా ఆన్‌బోర్డింగ్ పూర్తి చేయండి.',
    wheat: 'గోధుమ', rice: 'బియ్యం', cotton: 'పత్తి', sugarcane: 'చెరకు', maize: 'మొక్కజొన్న', millet: 'రాగి',
    cropCalendar: 'పంట క్యాలెండర్', calendarFor: 'షెడ్యూల్', currentPhase: 'ప్రస్తుత దశ', yearOverview: 'సంవత్సర అవలోకనం',
    landPreparation: 'భూమి తయారీ', sowing: 'విత్తనం', irrigation: 'నీటిపారుదల', harvesting: 'పంట కోత',
    plowAndLevel: 'పొలాన్ని దున్ని సమం చేయండి', sowSeeds: 'సరైన దూరంలో విత్తనాలు వేయండి', waterRegularly: 'అవసరమైనప్పుడు నీరు పెట్టండి', harvestCrop: 'పంట పరిపక్వం అయినప్పుడు కోయండి',
    transplantSeedlings: 'వరి పొలంలో మొలకలు నాటండి', maintainWaterLevel: 'నిలబడిన నీటి స్థాయిని కాపాడండి', pickBolls: 'పత్తి గూళ్ళను ఏరుకోండి', plantSetts: 'చెరకు ముక్కలు నాటండి', cutCanes: 'పరిపక్వ చెరకు కోయండి',
    community: 'సమాజం', shareYourTip: 'చిట్కా పంచుకోండి లేదా ప్రశ్న అడగండి...', replies: 'జవాబులు', you: 'మీరు', justNow: 'ఇప్పుడే',
    calendar: 'క్యాలెండర్', prices: 'ధరలు',
    marketPrices: 'మార్కెట్ ధరలు', pricesFor: 'మండి ధరలు', msp: 'MSP (కనీస మద్దతు ధర)', quintal: 'క్వింటాల్', priceTrend: 'ధర ధోరణి (12 నెలలు)', range: 'పరిధి',
    editProfile: 'ప్రొఫైల్ మార్చండి', waterAdvisory: 'నీటి సలహా',
    farmConsultants: 'వ్యవసాయ సలహాదారులు', consultantsNearby: 'మీ దగ్గరి నిపుణులు', yearsExp: 'సంవత్సరాల అనుభవం', getDirections: 'దిశలు',
    cropDoctor: 'పంట వైద్యుడు', soilExpert: 'నేల నిపుణుడు', pestExpert: 'పురుగుల నిపుణుడు', irrigationExpert: 'నీటిపారుదల నిపుణుడు',
    fieldHealthZones: 'పొలం ఆరోగ్య మండలాలు', refresh: 'రిఫ్రెష్', lastUpdated: 'చివరి అప్‌డేట్', stressAlert: '⚠️ పంట ఒత్తిడి 10% కంటే ఎక్కువ పెరిగింది! వెంటనే పొలాన్ని తనిఖీ చేయండి.', goToStressed: 'ఒత్తిడి ప్రాంతానికి వెళ్ళండి', demoMode: 'డెమో మోడ్', addApiKey: 'లైవ్ డేటా కోసం API కీ జోడించండి',
  },
  ml: {
    appName: 'അഗ്രിസെൻസ്', tagline: 'സ്മാർട്ട് കൃഷി ബുദ്ധി', selectLanguage: 'നിങ്ങളുടെ ഭാഷ തിരഞ്ഞെടുക്കുക', getStarted: 'ആരംഭിക്കുക',
    dashboard: 'ഡാഷ്‌ബോർഡ്', scan: 'സ്കാൻ', map: 'ഭൂപടം', shops: 'കടകൾ', assistant: 'സഹായി',
    onboarding: 'ഫാം സെറ്റപ്പ്', farmProfile: 'ഫാം പ്രൊഫൈൽ', location: 'സ്ഥലം', crop: 'വിള', sowingDate: 'വിതയ്ക്കൽ തീയതി', soilMoisture: 'മണ്ണിലെ ഈർപ്പം', landSize: 'ഭൂമിയുടെ വലിപ്പം', saveFarm: 'ഫാം സേവ് ചെയ്യുക',
    speakNow: 'ഇപ്പോൾ സംസാരിക്കൂ', tapMicToSpeak: 'മൈക്ക് ടാപ്പ് ചെയ്ത് നിങ്ങളുടെ ഫാമിനെ കുറിച്ച് പറയൂ', orFillManually: 'അല്ലെങ്കിൽ സ്വയം പൂരിപ്പിക്കൂ',
    weatherAdvisory: 'കാലാവസ്ഥാ ഉപദേശം', playAudio: '🔊 ഓഡിയോ പ്ലേ', stopAudio: '⏹ നിർത്തുക',
    temperature: 'താപനില', humidity: 'ഈർപ്പം', rainfall: 'മഴ',
    heatStress: 'ചൂട് സമ്മർദ്ദം! തണലും അധിക ജലസേചനവും നൽകുക.', irrigationAdvice: 'ഈർപ്പം കുറവ്. നാളെ രാവിലെ 20mm ജലസേചനം ചെയ്യുക.', pestRiskAlert: 'ഉയർന്ന ഈർപ്പം — കീട അപകടം! ഇലകൾ നിരീക്ഷിക്കുക.', goodConditions: 'സ്ഥിതി നല്ലതാണ്. പതിവ് പരിചരണം തുടരുക.',
    pestDetection: 'വിള ഡോക്ടർ', uploadLeaf: 'ഇല ചിത്രം അപ്‌ലോഡ്', scanning: 'സ്കാൻ ചെയ്യുന്നു...', diseaseDetected: 'രോഗം കണ്ടെത്തി', treatment: 'ചികിത്സ', dosage: 'ഡോസ്', timing: 'സമയം',
    satelliteHealth: 'ഉപഗ്രഹ ആരോഗ്യം', healthy: 'ആരോഗ്യം', moderate: 'മിതമായ', stressed: 'സമ്മർദ്ദം', critical: 'ഗുരുതരം',
    nearbyShops: 'സമീപത്തെ കാർഷിക കടകൾ', distance: 'ദൂരം', available: 'ലഭ്യം', callNow: 'ഇപ്പോൾ വിളിക്കുക',
    voiceAssistant: 'വോയിസ് സഹായി', askQuestion: 'കൃഷിയെ കുറിച്ച് ചോദ്യം ചോദിക്കുക...', listening: 'കേൾക്കുന്നു...', thinking: 'ചിന്തിക്കുന്നു...',
    offline: 'ഓഫ്‌ലൈൻ', online: 'ഓൺലൈൻ', offlineMode: 'ഓഫ്‌ലൈൻ മോഡ്', lastSynced: 'അവസാന സിങ്ക്', syncNow: 'ഇപ്പോൾ സിങ്ക്',
    acres: 'ഏക്കർ', percent: '%', celsius: '°C',
    welcome: 'അഗ്രിസെൻസിലേക്ക് സ്വാഗതം!', farmSaved: 'ഫാം പ്രൊഫൈൽ സേവ് ചെയ്തു!', noData: 'ഇതുവരെ ഡാറ്റ ഇല്ല. ആദ്യം ഓൺബോർഡിംഗ് പൂർത്തിയാക്കുക.',
    wheat: 'ഗോതമ്പ്', rice: 'അരി', cotton: 'പരുത്തി', sugarcane: 'കരിമ്പ്', maize: 'ചോളം', millet: 'റാഗി',
    cropCalendar: 'വിള കലണ്ടർ', calendarFor: 'ഷെഡ്യൂൾ', currentPhase: 'ഇപ്പോഴത്തെ ഘട്ടം', yearOverview: 'വർഷ അവലോകനം',
    landPreparation: 'ഭൂമി ഒരുക്കൽ', sowing: 'വിതയ്ക്കൽ', irrigation: 'ജലസേചനം', harvesting: 'വിളവെടുപ്പ്',
    plowAndLevel: 'ഭൂമി ഉഴുത് നിരപ്പാക്കുക', sowSeeds: 'ശരിയായ അകലത്തിൽ വിത്ത് വിതയ്ക്കുക', waterRegularly: 'ആവശ്യാനുസരണം വെള്ളം നൽകുക', harvestCrop: 'വിള മൂപ്പെത്തുമ്പോൾ വിളവെടുക്കുക',
    transplantSeedlings: 'തൈകൾ നടുക', maintainWaterLevel: 'നിലനിൽക്കുന്ന ജല നിരപ്പ് നിലനിർത്തുക', pickBolls: 'പരുത്തി കായ്കൾ പറിക്കുക', plantSetts: 'കരിമ്പ് കഷണങ്ങൾ നടുക', cutCanes: 'മൂപ്പെത്തിയ കരിമ്പ് മുറിക്കുക',
    community: 'സമൂഹം', shareYourTip: 'നുറുങ്ങ് പങ്കിടുക അല്ലെങ്കിൽ ചോദ്യം ചോദിക്കുക...', replies: 'മറുപടികൾ', you: 'നിങ്ങൾ', justNow: 'ഇപ്പോൾ',
    calendar: 'കലണ്ടർ', prices: 'വിലകൾ',
    marketPrices: 'വിപണി വിലകൾ', pricesFor: 'മണ്ഡി വിലകൾ', msp: 'MSP (കുറഞ്ഞ താങ്ങുവില)', quintal: 'ക്വിന്റൽ', priceTrend: 'വില പ്രവണത (12 മാസം)', range: 'പരിധി',
    editProfile: 'പ്രൊഫൈൽ തിരുത്തുക', waterAdvisory: 'ജല ഉപദേശം',
    farmConsultants: 'കാർഷിക ഉപദേഷ്ടാക്കൾ', consultantsNearby: 'സമീപത്തെ വിദഗ്ധ ഉപദേഷ്ടാക്കൾ', yearsExp: 'വർഷം അനുഭവം', getDirections: 'വഴി',
    cropDoctor: 'വിള ഡോക്ടർ', soilExpert: 'മണ്ണ് വിദഗ്ധൻ', pestExpert: 'കീട വിദഗ്ധൻ', irrigationExpert: 'ജലസേചന വിദഗ്ധൻ',
    fieldHealthZones: 'വയൽ ആരോഗ്യ മേഖലകൾ', refresh: 'പുതുക്കുക', lastUpdated: 'അവസാന അപ്‌ഡേറ്റ്', stressAlert: '⚠️ വിള സമ്മർദ്ദം 10% കൂടി! ഉടൻ വയൽ പരിശോധിക്കുക.', goToStressed: 'സമ്മർദ്ദ മേഖലയിലേക്ക് പോകുക', demoMode: 'ഡെമോ മോഡ്', addApiKey: 'തത്സമയ ഡാറ്റയ്ക്ക് API കീ ചേർക്കുക',
  },
  kn: {
    appName: 'ಅಗ್ರಿಸೆನ್ಸ್', tagline: 'ಸ್ಮಾರ್ಟ್ ಕೃಷಿ ಬುದ್ಧಿಮತ್ತೆ', selectLanguage: 'ನಿಮ್ಮ ಭಾಷೆಯನ್ನು ಆಯ್ಕೆಮಾಡಿ', getStarted: 'ಪ್ರಾರಂಭಿಸಿ',
    dashboard: 'ಡ್ಯಾಶ್‌ಬೋರ್ಡ್', scan: 'ಸ್ಕ್ಯಾನ್', map: 'ನಕ್ಷೆ', shops: 'ಅಂಗಡಿಗಳು', assistant: 'ಸಹಾಯಕ',
    onboarding: 'ಹೊಲ ಸೆಟಪ್', farmProfile: 'ಹೊಲ ಪ್ರೊಫೈಲ್', location: 'ಸ್ಥಳ', crop: 'ಬೆಳೆ', sowingDate: 'ಬಿತ್ತನೆ ದಿನಾಂಕ', soilMoisture: 'ಮಣ್ಣಿನ ತೇವಾಂಶ', landSize: 'ಭೂಮಿ ಗಾತ್ರ', saveFarm: 'ಹೊಲ ಉಳಿಸಿ',
    speakNow: 'ಈಗ ಮಾತನಾಡಿ', tapMicToSpeak: 'ಮೈಕ್ ಒತ್ತಿ ನಿಮ್ಮ ಹೊಲದ ಬಗ್ಗೆ ಹೇಳಿ', orFillManually: 'ಅಥವಾ ಕೈಯಿಂದ ಭರ್ತಿ ಮಾಡಿ',
    weatherAdvisory: 'ಹವಾಮಾನ ಸಲಹೆ', playAudio: '🔊 ಆಡಿಯೋ ಪ್ಲೇ', stopAudio: '⏹ ನಿಲ್ಲಿಸಿ',
    temperature: 'ಉಷ್ಣತೆ', humidity: 'ತೇವಾಂಶ', rainfall: 'ಮಳೆ',
    heatStress: 'ಶಾಖ ಒತ್ತಡ! ನೆರಳು ಮತ್ತು ಹೆಚ್ಚಿನ ನೀರಾವರಿ ನೀಡಿ.', irrigationAdvice: 'ತೇವಾಂಶ ಕಡಿಮೆ. ನಾಳೆ ಬೆಳಿಗ್ಗೆ 20mm ನೀರಾವರಿ ಮಾಡಿ.', pestRiskAlert: 'ಹೆಚ್ಚಿನ ತೇವಾಂಶ — ಕೀಟ ಅಪಾಯ! ಎಲೆಗಳನ್ನು ಗಮನಿಸಿ.', goodConditions: 'ಪರಿಸ್ಥಿತಿ ಚೆನ್ನಾಗಿದೆ. ನಿಯಮಿತ ಆರೈಕೆ ಮುಂದುವರಿಸಿ.',
    pestDetection: 'ಬೆಳೆ ವೈದ್ಯ', uploadLeaf: 'ಎಲೆ ಚಿತ್ರ ಅಪ್‌ಲೋಡ್', scanning: 'ಸ್ಕ್ಯಾನ್ ಆಗುತ್ತಿದೆ...', diseaseDetected: 'ರೋಗ ಪತ್ತೆಯಾಗಿದೆ', treatment: 'ಚಿಕಿತ್ಸೆ', dosage: 'ಡೋಸ್', timing: 'ಸಮಯ',
    satelliteHealth: 'ಉಪಗ್ರಹ ಆರೋಗ್ಯ', healthy: 'ಆರೋಗ್ಯ', moderate: 'ಮಧ್ಯಮ', stressed: 'ಒತ್ತಡ', critical: 'ಗಂಭೀರ',
    nearbyShops: 'ಹತ್ತಿರದ ಕೃಷಿ ಅಂಗಡಿಗಳು', distance: 'ದೂರ', available: 'ಲಭ್ಯ', callNow: 'ಈಗ ಕರೆ ಮಾಡಿ',
    voiceAssistant: 'ವಾಯ್ಸ್ ಸಹಾಯಕ', askQuestion: 'ಕೃಷಿ ಬಗ್ಗೆ ಪ್ರಶ್ನೆ ಕೇಳಿ...', listening: 'ಕೇಳುತ್ತಿದೆ...', thinking: 'ಯೋಚಿಸುತ್ತಿದೆ...',
    offline: 'ಆಫ್‌ಲೈನ್', online: 'ಆನ್‌ಲೈನ್', offlineMode: 'ಆಫ್‌ಲೈನ್ ಮೋಡ್', lastSynced: 'ಕೊನೆಯ ಸಿಂಕ್', syncNow: 'ಈಗ ಸಿಂಕ್',
    acres: 'ಎಕರೆ', percent: '%', celsius: '°C',
    welcome: 'ಅಗ್ರಿಸೆನ್ಸ್‌ಗೆ ಸ್ವಾಗತ!', farmSaved: 'ಹೊಲ ಪ್ರೊಫೈಲ್ ಉಳಿಸಲಾಗಿದೆ!', noData: 'ಇನ್ನೂ ಡೇಟಾ ಇಲ್ಲ. ಮೊದಲು ಆನ್‌ಬೋರ್ಡಿಂಗ್ ಪೂರ್ಣಗೊಳಿಸಿ.',
    wheat: 'ಗೋಧಿ', rice: 'ಅಕ್ಕಿ', cotton: 'ಹತ್ತಿ', sugarcane: 'ಕಬ್ಬು', maize: 'ಮೆಕ್ಕೆಜೋಳ', millet: 'ರಾಗಿ',
    cropCalendar: 'ಬೆಳೆ ಕ್ಯಾಲೆಂಡರ್', calendarFor: 'ವೇಳಾಪಟ್ಟಿ', currentPhase: 'ಪ್ರಸ್ತುತ ಹಂತ', yearOverview: 'ವಾರ್ಷಿಕ ಅವಲೋಕನ',
    landPreparation: 'ಭೂಮಿ ತಯಾರಿ', sowing: 'ಬಿತ್ತನೆ', irrigation: 'ನೀರಾವರಿ', harvesting: 'ಕೊಯ್ಲು',
    plowAndLevel: 'ಹೊಲವನ್ನು ಉಳುಮೆ ಮಾಡಿ ಸಮತಟ್ಟು ಮಾಡಿ', sowSeeds: 'ಸರಿಯಾದ ಅಂತರದಲ್ಲಿ ಬೀಜಗಳನ್ನು ಬಿತ್ತಿ', waterRegularly: 'ಅಗತ್ಯವಿದ್ದಾಗ ನೀರು ಹಾಕಿ', harvestCrop: 'ಬೆಳೆ ಮಾಗಿದಾಗ ಕೊಯ್ಲು ಮಾಡಿ',
    transplantSeedlings: 'ಸಸಿಗಳನ್ನು ನಾಟಿ ಮಾಡಿ', maintainWaterLevel: 'ನಿಂತ ನೀರಿನ ಮಟ್ಟವನ್ನು ಕಾಪಾಡಿ', pickBolls: 'ಹತ್ತಿ ಕಾಯಿಗಳನ್ನು ಆರಿಸಿ', plantSetts: 'ಕಬ್ಬಿನ ತುಂಡುಗಳನ್ನು ನೆಡಿ', cutCanes: 'ಮಾಗಿದ ಕಬ್ಬು ಕಡಿಯಿರಿ',
    community: 'ಸಮುದಾಯ', shareYourTip: 'ಸಲಹೆ ಹಂಚಿಕೊಳ್ಳಿ ಅಥವಾ ಪ್ರಶ್ನೆ ಕೇಳಿ...', replies: 'ಉತ್ತರಗಳು', you: 'ನೀವು', justNow: 'ಈಗಷ್ಟೇ',
    calendar: 'ಕ್ಯಾಲೆಂಡರ್', prices: 'ಬೆಲೆಗಳು',
    marketPrices: 'ಮಾರುಕಟ್ಟೆ ಬೆಲೆಗಳು', pricesFor: 'ಮಂಡಿ ಬೆಲೆಗಳು', msp: 'MSP (ಕನಿಷ್ಠ ಬೆಂಬಲ ಬೆಲೆ)', quintal: 'ಕ್ವಿಂಟಾಲ್', priceTrend: 'ಬೆಲೆ ಪ್ರವೃತ್ತಿ (12 ತಿಂಗಳು)', range: 'ವ್ಯಾಪ್ತಿ',
    editProfile: 'ಪ್ರೊಫೈಲ್ ಬದಲಿಸಿ', waterAdvisory: 'ನೀರು ಸಲಹೆ',
    farmConsultants: 'ಕೃಷಿ ಸಲಹೆಗಾರರು', consultantsNearby: 'ಹತ್ತಿರದ ತಜ್ಞ ಸಲಹೆಗಾರರು', yearsExp: 'ವರ್ಷ ಅನುಭವ', getDirections: 'ದಿಕ್ಕುಗಳು',
    cropDoctor: 'ಬೆಳೆ ವೈದ್ಯ', soilExpert: 'ಮಣ್ಣಿನ ತಜ್ಞ', pestExpert: 'ಕೀಟ ತಜ್ಞ', irrigationExpert: 'ನೀರಾವರಿ ತಜ್ಞ',
    fieldHealthZones: 'ಹೊಲ ಆರೋಗ್ಯ ಮಂಡಲ', refresh: 'ರಿಫ್ರೆಶ್', lastUpdated: 'ಕೊನೆಯ ಅಪ್‌ಡೇಟ್', stressAlert: '⚠️ ಬೆಳೆ ಒತ್ತಡ 10% ಹೆಚ್ಚಾಗಿದೆ! ತಕ್ಷಣ ಹೊಲ ಪರಿಶೀಲಿಸಿ.', goToStressed: 'ಒತ್ತಡ ಪ್ರದೇಶಕ್ಕೆ ಹೋಗಿ', demoMode: 'ಡೆಮೊ ಮೋಡ್', addApiKey: 'ಲೈವ್ ಡೇಟಾಕ್ಕೆ API ಕೀ ಸೇರಿಸಿ',
  },
  mr: {
    appName: 'अ‍ॅग्रीसेन्स', tagline: 'स्मार्ट शेती बुद्धिमत्ता', selectLanguage: 'तुमची भाषा निवडा', getStarted: 'सुरू करा',
    dashboard: 'डॅशबोर्ड', scan: 'स्कॅन', map: 'नकाशा', shops: 'दुकाने', assistant: 'सहाय्यक',
    onboarding: 'शेत सेटअप', farmProfile: 'शेत प्रोफाइल', location: 'ठिकाण', crop: 'पीक', sowingDate: 'पेरणी तारीख', soilMoisture: 'मातीतील ओलावा', landSize: 'जमिनीचा आकार', saveFarm: 'शेत सेव्ह करा',
    speakNow: 'आता बोला', tapMicToSpeak: 'माइक दाबा आणि तुमच्या शेताबद्दल सांगा', orFillManually: 'किंवा स्वतः भरा',
    weatherAdvisory: 'हवामान सल्ला', playAudio: '🔊 ऑडिओ प्ले', stopAudio: '⏹ थांबा',
    temperature: 'तापमान', humidity: 'आर्द्रता', rainfall: 'पाऊस',
    heatStress: 'उष्णतेचा ताण! सावली आणि अतिरिक्त सिंचन द्या.', irrigationAdvice: 'ओलावा कमी. उद्या सकाळी 20mm सिंचन करा.', pestRiskAlert: 'उच्च आर्द्रता — कीटकांचा धोका! पानांवर लक्ष ठेवा.', goodConditions: 'परिस्थिती चांगली आहे. नियमित काळजी सुरू ठेवा.',
    pestDetection: 'पीक डॉक्टर', uploadLeaf: 'पानाचा फोटो अपलोड करा', scanning: 'स्कॅन होत आहे...', diseaseDetected: 'रोग आढळला', treatment: 'उपचार', dosage: 'मात्रा', timing: 'वेळ',
    satelliteHealth: 'उपग्रह आरोग्य', healthy: 'निरोगी', moderate: 'मध्यम', stressed: 'ताणग्रस्त', critical: 'गंभीर',
    nearbyShops: 'जवळच्या कृषी दुकाने', distance: 'अंतर', available: 'उपलब्ध', callNow: 'आता कॉल करा',
    voiceAssistant: 'व्हॉइस सहाय्यक', askQuestion: 'शेतीबद्दल प्रश्न विचारा...', listening: 'ऐकत आहे...', thinking: 'विचार करत आहे...',
    offline: 'ऑफलाइन', online: 'ऑनलाइन', offlineMode: 'ऑफलाइन मोड', lastSynced: 'शेवटचे सिंक', syncNow: 'आता सिंक करा',
    acres: 'एकर', percent: '%', celsius: '°C',
    welcome: 'अ‍ॅग्रीसेन्समध्ये आपले स्वागत!', farmSaved: 'शेत प्रोफाइल सेव्ह झाली!', noData: 'अजून डेटा नाही. आधी ऑनबोर्डिंग पूर्ण करा.',
    wheat: 'गहू', rice: 'तांदूळ', cotton: 'कापूस', sugarcane: 'ऊस', maize: 'मका', millet: 'बाजरी',
    cropCalendar: 'पीक कॅलेंडर', calendarFor: 'वेळापत्रक', currentPhase: 'सध्याचा टप्पा', yearOverview: 'वार्षिक आढावा',
    landPreparation: 'जमीन तयारी', sowing: 'पेरणी', irrigation: 'सिंचन', harvesting: 'कापणी',
    plowAndLevel: 'शेत नांगरून सपाट करा', sowSeeds: 'योग्य अंतरावर बी पेरा', waterRegularly: 'गरजेनुसार पाणी द्या', harvestCrop: 'पीक पक्व झाल्यावर कापणी करा',
    transplantSeedlings: 'रोपे लावा', maintainWaterLevel: 'उभ्या पाण्याची पातळी राखा', pickBolls: 'कापसाचे बोंडे वेचा', plantSetts: 'उसाच्या कांड्या लावा', cutCanes: 'पक्व ऊस तोडा',
    community: 'समुदाय', shareYourTip: 'टिप शेअर करा किंवा प्रश्न विचारा...', replies: 'उत्तरे', you: 'तुम्ही', justNow: 'आत्ताच',
    calendar: 'कॅलेंडर', prices: 'भाव',
    marketPrices: 'बाजार भाव', pricesFor: 'मंडी भाव', msp: 'MSP (किमान आधार भाव)', quintal: 'क्विंटल', priceTrend: 'भाव कल (12 महिने)', range: 'श्रेणी',
    editProfile: 'प्रोफाइल बदला', waterAdvisory: 'पाणी सल्ला',
    farmConsultants: 'कृषी सल्लागार', consultantsNearby: 'जवळचे तज्ञ सल्लागार', yearsExp: 'वर्ष अनुभव', getDirections: 'दिशा',
    cropDoctor: 'पीक डॉक्टर', soilExpert: 'माती तज्ञ', pestExpert: 'कीटक तज्ञ', irrigationExpert: 'सिंचन तज्ञ',
    fieldHealthZones: 'शेत आरोग्य क्षेत्रे', refresh: 'रिफ्रेश', lastUpdated: 'शेवटचे अपडेट', stressAlert: '⚠️ पीक ताण 10% पेक्षा जास्त वाढला! तात्काळ शेत तपासा.', goToStressed: 'ताणग्रस्त क्षेत्राकडे जा', demoMode: 'डेमो मोड', addApiKey: 'लाइव्ह डेटासाठी API की जोडा',
  },
  pa: {
    appName: 'ਐਗਰੀਸੈਂਸ', tagline: 'ਸਮਾਰਟ ਖੇਤੀ ਬੁੱਧੀ', selectLanguage: 'ਆਪਣੀ ਭਾਸ਼ਾ ਚੁਣੋ', getStarted: 'ਸ਼ੁਰੂ ਕਰੋ',
    dashboard: 'ਡੈਸ਼ਬੋਰਡ', scan: 'ਸਕੈਨ', map: 'ਨਕਸ਼ਾ', shops: 'ਦੁਕਾਨਾਂ', assistant: 'ਸਹਾਇਕ',
    onboarding: 'ਖੇਤ ਸੈਟਅਪ', farmProfile: 'ਖੇਤ ਪ੍ਰੋਫਾਈਲ', location: 'ਸਥਾਨ', crop: 'ਫਸਲ', sowingDate: 'ਬਿਜਾਈ ਤਾਰੀਖ', soilMoisture: 'ਮਿੱਟੀ ਦੀ ਨਮੀ', landSize: 'ਜ਼ਮੀਨ ਦਾ ਆਕਾਰ', saveFarm: 'ਖੇਤ ਸੇਵ ਕਰੋ',
    speakNow: 'ਹੁਣ ਬੋਲੋ', tapMicToSpeak: 'ਮਾਈਕ ਦਬਾ ਕੇ ਆਪਣੇ ਖੇਤ ਬਾਰੇ ਦੱਸੋ', orFillManually: 'ਜਾਂ ਖੁਦ ਭਰੋ',
    weatherAdvisory: 'ਮੌਸਮ ਸਲਾਹ', playAudio: '🔊 ਆਡੀਓ ਚਲਾਓ', stopAudio: '⏹ ਰੁਕੋ',
    temperature: 'ਤਾਪਮਾਨ', humidity: 'ਨਮੀ', rainfall: 'ਮੀਂਹ',
    heatStress: 'ਗਰਮੀ ਦਾ ਤਣਾਅ! ਛਾਂ ਅਤੇ ਵਾਧੂ ਸਿੰਚਾਈ ਦਿਓ।', irrigationAdvice: 'ਨਮੀ ਘੱਟ ਹੈ। ਕੱਲ੍ਹ ਸਵੇਰੇ 20mm ਸਿੰਚਾਈ ਕਰੋ।', pestRiskAlert: 'ਉੱਚ ਨਮੀ — ਕੀੜਿਆਂ ਦਾ ਖ਼ਤਰਾ! ਪੱਤਿਆਂ ਦੀ ਜਾਂਚ ਕਰੋ।', goodConditions: 'ਹਾਲਾਤ ਚੰਗੇ ਹਨ। ਨਿਯਮਿਤ ਦੇਖਭਾਲ ਜਾਰੀ ਰੱਖੋ।',
    pestDetection: 'ਫਸਲ ਡਾਕਟਰ', uploadLeaf: 'ਪੱਤੇ ਦੀ ਤਸਵੀਰ ਅਪਲੋਡ ਕਰੋ', scanning: 'ਸਕੈਨ ਹੋ ਰਿਹਾ ਹੈ...', diseaseDetected: 'ਬਿਮਾਰੀ ਮਿਲੀ', treatment: 'ਇਲਾਜ', dosage: 'ਖੁਰਾਕ', timing: 'ਸਮਾਂ',
    satelliteHealth: 'ਸੈਟੇਲਾਈਟ ਸਿਹਤ', healthy: 'ਸਿਹਤਮੰਦ', moderate: 'ਦਰਮਿਆਨਾ', stressed: 'ਤਣਾਅ', critical: 'ਗੰਭੀਰ',
    nearbyShops: 'ਨੇੜੇ ਦੀਆਂ ਖੇਤੀ ਦੁਕਾਨਾਂ', distance: 'ਦੂਰੀ', available: 'ਉਪਲਬਧ', callNow: 'ਹੁਣ ਕਾਲ ਕਰੋ',
    voiceAssistant: 'ਵੌਇਸ ਸਹਾਇਕ', askQuestion: 'ਖੇਤੀ ਬਾਰੇ ਸਵਾਲ ਪੁੱਛੋ...', listening: 'ਸੁਣ ਰਿਹਾ ਹੈ...', thinking: 'ਸੋਚ ਰਿਹਾ ਹੈ...',
    offline: 'ਆਫ਼ਲਾਈਨ', online: 'ਆਨਲਾਈਨ', offlineMode: 'ਆਫ਼ਲਾਈਨ ਮੋਡ', lastSynced: 'ਆਖਰੀ ਸਿੰਕ', syncNow: 'ਹੁਣ ਸਿੰਕ ਕਰੋ',
    acres: 'ਏਕੜ', percent: '%', celsius: '°C',
    welcome: 'ਐਗਰੀਸੈਂਸ ਵਿੱਚ ਜੀ ਆਇਆਂ ਨੂੰ!', farmSaved: 'ਖੇਤ ਪ੍ਰੋਫਾਈਲ ਸੇਵ ਹੋਈ!', noData: 'ਅਜੇ ਕੋਈ ਡਾਟਾ ਨਹੀਂ। ਪਹਿਲਾਂ ਆਨਬੋਰਡਿੰਗ ਪੂਰੀ ਕਰੋ।',
    wheat: 'ਕਣਕ', rice: 'ਚੌਲ', cotton: 'ਕਪਾਹ', sugarcane: 'ਗੰਨਾ', maize: 'ਮੱਕੀ', millet: 'ਬਾਜਰਾ',
    cropCalendar: 'ਫਸਲ ਕੈਲੰਡਰ', calendarFor: 'ਅਨੁਸੂਚੀ', currentPhase: 'ਮੌਜੂਦਾ ਪੜਾਅ', yearOverview: 'ਸਾਲਾਨਾ ਝਲਕ',
    landPreparation: 'ਜ਼ਮੀਨ ਤਿਆਰੀ', sowing: 'ਬਿਜਾਈ', irrigation: 'ਸਿੰਚਾਈ', harvesting: 'ਵਾਢੀ',
    plowAndLevel: 'ਖੇਤ ਵਾਹ ਕੇ ਪੱਧਰਾ ਕਰੋ', sowSeeds: 'ਸਹੀ ਦੂਰੀ \'ਤੇ ਬੀਜ ਬੀਜੋ', waterRegularly: 'ਲੋੜ ਅਨੁਸਾਰ ਪਾਣੀ ਦਿਓ', harvestCrop: 'ਫਸਲ ਪੱਕਣ \'ਤੇ ਵਾਢੀ ਕਰੋ',
    transplantSeedlings: 'ਪਨੀਰੀ ਲਗਾਓ', maintainWaterLevel: 'ਖੜ੍ਹੇ ਪਾਣੀ ਦਾ ਪੱਧਰ ਬਣਾ ਕੇ ਰੱਖੋ', pickBolls: 'ਕਪਾਹ ਦੇ ਟਿੰਡੇ ਚੁਣੋ', plantSetts: 'ਗੰਨੇ ਦੇ ਟੁਕੜੇ ਲਗਾਓ', cutCanes: 'ਪੱਕੇ ਗੰਨੇ ਕੱਟੋ',
    community: 'ਭਾਈਚਾਰਾ', shareYourTip: 'ਸੁਝਾਅ ਸਾਂਝਾ ਕਰੋ ਜਾਂ ਸਵਾਲ ਪੁੱਛੋ...', replies: 'ਜਵਾਬ', you: 'ਤੁਸੀਂ', justNow: 'ਹੁਣੇ',
    calendar: 'ਕੈਲੰਡਰ', prices: 'ਭਾਅ',
    marketPrices: 'ਬਾਜ਼ਾਰ ਭਾਅ', pricesFor: 'ਮੰਡੀ ਭਾਅ', msp: 'MSP (ਘੱਟੋ-ਘੱਟ ਸਹਾਇਤਾ ਮੁੱਲ)', quintal: 'ਕੁਇੰਟਲ', priceTrend: 'ਭਾਅ ਰੁਝਾਨ (12 ਮਹੀਨੇ)', range: 'ਸੀਮਾ',
    editProfile: 'ਪ੍ਰੋਫਾਈਲ ਬਦਲੋ', waterAdvisory: 'ਪਾਣੀ ਸਲਾਹ',
    farmConsultants: 'ਖੇਤੀ ਸਲਾਹਕਾਰ', consultantsNearby: 'ਤੁਹਾਡੇ ਨੇੜੇ ਮਾਹਿਰ ਸਲਾਹਕਾਰ', yearsExp: 'ਸਾਲ ਤਜਰਬਾ', getDirections: 'ਰਸਤਾ',
    cropDoctor: 'ਫਸਲ ਡਾਕਟਰ', soilExpert: 'ਮਿੱਟੀ ਮਾਹਿਰ', pestExpert: 'ਕੀੜੇ ਮਾਹਿਰ', irrigationExpert: 'ਸਿੰਚਾਈ ਮਾਹਿਰ',
    fieldHealthZones: 'ਖੇਤ ਸਿਹਤ ਖੇਤਰ', refresh: 'ਰਿਫ੍ਰੈਸ਼', lastUpdated: 'ਆਖਰੀ ਅੱਪਡੇਟ', stressAlert: '⚠️ ਫਸਲ ਤਣਾਅ 10% ਤੋਂ ਵੱਧ ਗਿਆ! ਤੁਰੰਤ ਖੇਤ ਦੀ ਜਾਂਚ ਕਰੋ।', goToStressed: 'ਤਣਾਅ ਵਾਲੇ ਖੇਤਰ \'ਤੇ ਜਾਓ', demoMode: 'ਡੈਮੋ ਮੋਡ', addApiKey: 'ਲਾਈਵ ਡਾਟਾ ਲਈ API ਕੁੰਜੀ ਜੋੜੋ',
  },
  bn: {
    appName: 'অ্যাগ্রিসেন্স', tagline: 'স্মার্ট কৃষি বুদ্ধিমত্তা', selectLanguage: 'আপনার ভাষা নির্বাচন করুন', getStarted: 'শুরু করুন',
    dashboard: 'ড্যাশবোর্ড', scan: 'স্ক্যান', map: 'মানচিত্র', shops: 'দোকান', assistant: 'সহকারী',
    onboarding: 'খামার সেটআপ', farmProfile: 'খামার প্রোফাইল', location: 'অবস্থান', crop: 'ফসল', sowingDate: 'বীজ বপনের তারিখ', soilMoisture: 'মাটির আর্দ্রতা', landSize: 'জমির আকার', saveFarm: 'খামার সেভ করুন',
    speakNow: 'এখন বলুন', tapMicToSpeak: 'মাইক চাপুন এবং আপনার খামার সম্পর্কে বলুন', orFillManually: 'অথবা নিজে পূরণ করুন',
    weatherAdvisory: 'আবহাওয়া পরামর্শ', playAudio: '🔊 অডিও চালান', stopAudio: '⏹ থামুন',
    temperature: 'তাপমাত্রা', humidity: 'আর্দ্রতা', rainfall: 'বৃষ্টিপাত',
    heatStress: 'তাপ চাপ! ছায়া এবং অতিরিক্ত সেচ দিন।', irrigationAdvice: 'আর্দ্রতা কম। আগামীকাল সকালে 20mm সেচ করুন।', pestRiskAlert: 'উচ্চ আর্দ্রতা — পোকার ঝুঁকি! পাতা পরীক্ষা করুন।', goodConditions: 'অবস্থা ভালো। নিয়মিত পরিচর্যা চালিয়ে যান।',
    pestDetection: 'ফসল ডাক্তার', uploadLeaf: 'পাতার ছবি আপলোড করুন', scanning: 'স্ক্যান হচ্ছে...', diseaseDetected: 'রোগ শনাক্ত হয়েছে', treatment: 'চিকিৎসা', dosage: 'মাত্রা', timing: 'সময়',
    satelliteHealth: 'স্যাটেলাইট স্বাস্থ্য', healthy: 'সুস্থ', moderate: 'মাঝারি', stressed: 'চাপে', critical: 'গুরুতর',
    nearbyShops: 'কাছের কৃষি দোকান', distance: 'দূরত্ব', available: 'উপলব্ধ', callNow: 'এখন কল করুন',
    voiceAssistant: 'ভয়েস সহকারী', askQuestion: 'কৃষি সম্পর্কে প্রশ্ন করুন...', listening: 'শুনছে...', thinking: 'ভাবছে...',
    offline: 'অফলাইন', online: 'অনলাইন', offlineMode: 'অফলাইন মোড', lastSynced: 'শেষ সিঙ্ক', syncNow: 'এখন সিঙ্ক করুন',
    acres: 'একর', percent: '%', celsius: '°C',
    welcome: 'অ্যাগ্রিসেন্সে স্বাগতম!', farmSaved: 'খামার প্রোফাইল সেভ হয়েছে!', noData: 'এখনো কোনো ডাটা নেই। আগে অনবোর্ডিং সম্পন্ন করুন।',
    wheat: 'গম', rice: 'চাল', cotton: 'তুলা', sugarcane: 'আখ', maize: 'ভুট্টা', millet: 'বাজরা',
    cropCalendar: 'ফসল ক্যালেন্ডার', calendarFor: 'সময়সূচি', currentPhase: 'বর্তমান পর্ব', yearOverview: 'বার্ষিক পর্যালোচনা',
    landPreparation: 'জমি প্রস্তুতি', sowing: 'বীজ বপন', irrigation: 'সেচ', harvesting: 'ফসল কাটা',
    plowAndLevel: 'জমি চাষ করে সমতল করুন', sowSeeds: 'সঠিক দূরত্বে বীজ বপন করুন', waterRegularly: 'প্রয়োজন অনুসারে জল দিন', harvestCrop: 'ফসল পাকলে কেটে নিন',
    transplantSeedlings: 'চারা রোপণ করুন', maintainWaterLevel: 'দাঁড়ানো জলের স্তর বজায় রাখুন', pickBolls: 'তুলা বল তুলুন', plantSetts: 'আখের টুকরো রোপণ করুন', cutCanes: 'পাকা আখ কাটুন',
    community: 'সম্প্রদায়', shareYourTip: 'টিপ শেয়ার করুন বা প্রশ্ন করুন...', replies: 'উত্তর', you: 'আপনি', justNow: 'এইমাত্র',
    calendar: 'ক্যালেন্ডার', prices: 'দাম',
    marketPrices: 'বাজার দাম', pricesFor: 'মান্ডি দাম', msp: 'MSP (ন্যূনতম সমর্থন মূল্য)', quintal: 'কুইন্টাল', priceTrend: 'দাম প্রবণতা (12 মাস)', range: 'পরিসর',
    editProfile: 'প্রোফাইল সম্পাদনা', waterAdvisory: 'জল পরামর্শ',
    farmConsultants: 'কৃষি পরামর্শদাতা', consultantsNearby: 'আপনার কাছের বিশেষজ্ঞ পরামর্শদাতা', yearsExp: 'বছর অভিজ্ঞতা', getDirections: 'দিকনির্দেশ',
    cropDoctor: 'ফসল ডাক্তার', soilExpert: 'মাটি বিশেষজ্ঞ', pestExpert: 'পোকা বিশেষজ্ঞ', irrigationExpert: 'সেচ বিশেষজ্ঞ',
    fieldHealthZones: 'ক্ষেত্র স্বাস্থ্য অঞ্চল', refresh: 'রিফ্রেশ', lastUpdated: 'শেষ আপডেট', stressAlert: '⚠️ ফসলের চাপ 10% বেড়েছে! তৎক্ষণাৎ খামার পরীক্ষা করুন।', goToStressed: 'চাপের এলাকায় যান', demoMode: 'ডেমো মোড', addApiKey: 'লাইভ ডাটার জন্য API কী যোগ করুন',
  },
  ur: {
    appName: 'ایگری سینس', tagline: 'سمارٹ زراعت ذہانت', selectLanguage: 'اپنی زبان منتخب کریں', getStarted: 'شروع کریں',
    dashboard: 'ڈیش بورڈ', scan: 'اسکین', map: 'نقشہ', shops: 'دکانیں', assistant: 'معاون',
    onboarding: 'کھیت سیٹ اپ', farmProfile: 'کھیت پروفائل', location: 'مقام', crop: 'فصل', sowingDate: 'بوائی کی تاریخ', soilMoisture: 'مٹی کی نمی', landSize: 'زمین کا سائز', saveFarm: 'کھیت محفوظ کریں',
    speakNow: 'ابھی بولیں', tapMicToSpeak: 'مائیک دبائیں اور اپنے کھیت کے بارے میں بتائیں', orFillManually: 'یا خود بھریں',
    weatherAdvisory: 'موسمی مشورہ', playAudio: '🔊 آڈیو چلائیں', stopAudio: '⏹ روکیں',
    temperature: 'درجہ حرارت', humidity: 'نمی', rainfall: 'بارش',
    heatStress: 'گرمی کا دباؤ! سایہ اور اضافی آبپاشی فراہم کریں۔', irrigationAdvice: 'نمی کم ہے۔ کل صبح 20mm آبپاشی کریں۔', pestRiskAlert: 'زیادہ نمی — کیڑوں کا خطرہ! پتوں کی جانچ کریں۔', goodConditions: 'حالات اچھے ہیں۔ باقاعدہ دیکھ بھال جاری رکھیں۔',
    pestDetection: 'فصل ڈاکٹر', uploadLeaf: 'پتے کی تصویر اپلوڈ کریں', scanning: 'اسکین ہو رہا ہے...', diseaseDetected: 'بیماری ملی', treatment: 'علاج', dosage: 'خوراک', timing: 'وقت',
    satelliteHealth: 'سیٹلائٹ صحت', healthy: 'صحت مند', moderate: 'معتدل', stressed: 'دباؤ', critical: 'شدید',
    nearbyShops: 'قریبی زرعی دکانیں', distance: 'فاصلہ', available: 'دستیاب', callNow: 'ابھی کال کریں',
    voiceAssistant: 'وائس معاون', askQuestion: 'زراعت کے بارے میں سوال پوچھیں...', listening: 'سن رہا ہے...', thinking: 'سوچ رہا ہے...',
    offline: 'آف لائن', online: 'آن لائن', offlineMode: 'آف لائن موڈ', lastSynced: 'آخری سنک', syncNow: 'ابھی سنک کریں',
    acres: 'ایکڑ', percent: '%', celsius: '°C',
    welcome: 'ایگری سینس میں خوش آمدید!', farmSaved: 'کھیت پروفائل محفوظ ہو گئی!', noData: 'ابھی کوئی ڈیٹا نہیں۔ پہلے آن بورڈنگ مکمل کریں۔',
    wheat: 'گندم', rice: 'چاول', cotton: 'کپاس', sugarcane: 'گنا', maize: 'مکئی', millet: 'باجرا',
    cropCalendar: 'فصل کیلنڈر', calendarFor: 'شیڈول', currentPhase: 'موجودہ مرحلہ', yearOverview: 'سالانہ جائزہ',
    landPreparation: 'زمین کی تیاری', sowing: 'بوائی', irrigation: 'آبپاشی', harvesting: 'فصل کٹائی',
    plowAndLevel: 'زمین ہل چلا کر ہموار کریں', sowSeeds: 'صحیح فاصلے پر بیج بوئیں', waterRegularly: 'ضرورت کے مطابق پانی دیں', harvestCrop: 'فصل پکنے پر کاٹیں',
    transplantSeedlings: 'پنیری لگائیں', maintainWaterLevel: 'کھڑے پانی کی سطح برقرار رکھیں', pickBolls: 'کپاس کے ٹنڈے چنیں', plantSetts: 'گنے کے ٹکڑے لگائیں', cutCanes: 'پکے گنے کاٹیں',
    community: 'برادری', shareYourTip: 'مشورہ شیئر کریں یا سوال پوچھیں...', replies: 'جوابات', you: 'آپ', justNow: 'ابھی',
    calendar: 'کیلنڈر', prices: 'قیمتیں',
    marketPrices: 'منڈی قیمتیں', pricesFor: 'منڈی ریٹ', msp: 'MSP (کم از کم حمایتی قیمت)', quintal: 'کوئنٹل', priceTrend: 'قیمت رجحان (12 ماہ)', range: 'حد',
    editProfile: 'پروفائل تبدیل کریں', waterAdvisory: 'پانی مشورہ',
    farmConsultants: 'زرعی مشیر', consultantsNearby: 'آپ کے قریب ماہر مشیر', yearsExp: 'سال تجربہ', getDirections: 'سمت',
    cropDoctor: 'فصل ڈاکٹر', soilExpert: 'مٹی ماہر', pestExpert: 'کیڑے ماہر', irrigationExpert: 'آبپاشی ماہر',
    fieldHealthZones: 'کھیت صحت زون', refresh: 'ریفریش', lastUpdated: 'آخری اپ ڈیٹ', stressAlert: '⚠️ فصل کا دباؤ 10% سے زیادہ بڑھ گیا! فوراً کھیت چیک کریں۔', goToStressed: 'دباؤ والے علاقے میں جائیں', demoMode: 'ڈیمو موڈ', addApiKey: 'لائیو ڈیٹا کے لیے API کلید شامل کریں',
  },
};

export function t(lang: LangCode, key: TranslationKeys): string {
  return translations[lang]?.[key] ?? translations.en[key] ?? key;
}

export function getLangMeta(code: LangCode): LangMeta {
  return LANGUAGES.find(l => l.code === code) ?? LANGUAGES[0];
}

// Crop keyword map for voice parsing
const CROP_KEYWORDS: Record<string, string> = {
  wheat: 'Wheat', गेहूं: 'Wheat', கோதுமை: 'Wheat', గోధుమ: 'Wheat', ഗോതമ്പ്: 'Wheat', ಗೋಧಿ: 'Wheat', गहू: 'Wheat', ਕਣਕ: 'Wheat', গম: 'Wheat', گندم: 'Wheat',
  rice: 'Rice', चावल: 'Rice', அரிசி: 'Rice', బియ్యం: 'Rice', അരി: 'Rice', ಅಕ್ಕಿ: 'Rice', तांदूळ: 'Rice', ਚੌਲ: 'Rice', চাল: 'Rice', چاول: 'Rice',
  paddy: 'Rice', धान: 'Rice', நெல்: 'Rice',
  cotton: 'Cotton', कपास: 'Cotton', பருத்தி: 'Cotton', పత్తి: 'Cotton', പരുത്തി: 'Cotton', ಹತ್ತಿ: 'Cotton', कापूस: 'Cotton', ਕਪਾਹ: 'Cotton', তুলা: 'Cotton', کپاس: 'Cotton',
  sugarcane: 'Sugarcane', गन्ना: 'Sugarcane', கரும்பு: 'Sugarcane', చెరకు: 'Sugarcane', കരിമ്പ്: 'Sugarcane', ಕಬ್ಬು: 'Sugarcane', ऊस: 'Sugarcane', ਗੰਨਾ: 'Sugarcane', আখ: 'Sugarcane', گنا: 'Sugarcane',
  maize: 'Maize', मक्का: 'Maize', மக்காச்சோளம்: 'Maize', మొక్కజొన్న: 'Maize', ചോളം: 'Maize', ಮೆಕ್ಕೆಜೋಳ: 'Maize', मका: 'Maize', ਮੱਕੀ: 'Maize', ভুট্টা: 'Maize', مکئی: 'Maize',
  millet: 'Millet', बाजरा: 'Millet', கம்பு: 'Millet', రాగి: 'Millet', റാഗി: 'Millet', ರಾಗಿ: 'Millet', बाजरी: 'Millet', ਬਾਜਰਾ: 'Millet', বাজরা: 'Millet', باجرا: 'Millet',
};

export function parseSpeechForFarmData(transcript: string): { crop?: string; landSize?: string; location?: string } {
  const result: { crop?: string; landSize?: string; location?: string } = {};
  const lower = transcript.toLowerCase();

  // Detect crop
  for (const [keyword, crop] of Object.entries(CROP_KEYWORDS)) {
    if (transcript.includes(keyword) || lower.includes(keyword.toLowerCase())) {
      result.crop = crop;
      break;
    }
  }

  // Detect land size (number + acre/hectare/bigha patterns)
  const sizeMatch = lower.match(/(\d+\.?\d*)\s*(acre|एकड़|ஏக்கர்|ఎకరా|ഏക്കർ|ಎಕರೆ|एकर|ਏਕੜ|একর|ایکڑ|hectare|bigha|बीघा)/i);
  if (sizeMatch) {
    result.landSize = sizeMatch[1];
  }

  // If nothing parsed, use transcript segments as location hint
  if (!result.crop && !result.landSize) {
    result.location = transcript.trim();
  }

  return result;
}
