export interface WeatherData {
  temperature: number;
  humidity: number;
  rainfall: number;
}

export interface FarmData {
  location: string;
  crop: string;
  sowingDate: string;
  soilMoisture: number;
  landSize: string;
}

export interface Advisory {
  type: 'warning' | 'danger' | 'info' | 'success';
  message: string;
  key: string;
}

export function generateMockWeather(): WeatherData {
  return {
    temperature: Math.floor(28 + Math.random() * 14), // 28-42
    humidity: Math.floor(40 + Math.random() * 50),     // 40-90
    rainfall: Math.floor(Math.random() * 30),          // 0-30mm
  };
}

export function generateAdvisory(weather: WeatherData, soilMoisture: number): Advisory[] {
  const advisories: Advisory[] = [];

  if (weather.temperature > 35) {
    advisories.push({ type: 'danger', message: 'heatStress', key: 'heat' });
  }
  if (soilMoisture < 30 && weather.rainfall < 5) {
    advisories.push({ type: 'warning', message: 'irrigationAdvice', key: 'irrigation' });
  }
  if (weather.humidity > 75) {
    advisories.push({ type: 'warning', message: 'pestRiskAlert', key: 'pest' });
  }
  if (advisories.length === 0) {
    advisories.push({ type: 'success', message: 'goodConditions', key: 'good' });
  }

  return advisories;
}

export interface PestResult {
  disease: string;
  confidence: number;
  treatment: string;
  dosage: string;
  timing: string;
}

export function simulatePestDetection(): PestResult {
  const diseases = [
    { disease: 'Late Blight', treatment: 'Mancozeb 75% WP', dosage: '2.5g/L water', timing: 'Spray every 7 days' },
    { disease: 'Powdery Mildew', treatment: 'Sulphur 80% WP', dosage: '3g/L water', timing: 'Spray every 10 days' },
    { disease: 'Leaf Spot', treatment: 'Carbendazim 50% WP', dosage: '1g/L water', timing: 'Spray every 14 days' },
    { disease: 'Bacterial Wilt', treatment: 'Copper Oxychloride', dosage: '3g/L water', timing: 'Drench soil weekly' },
  ];
  const pick = diseases[Math.floor(Math.random() * diseases.length)];
  return { ...pick, confidence: 85 + Math.floor(Math.random() * 12) };
}

export interface ShopInfo {
  name: string;
  type: string;
  distance: string;
  phone: string;
  products: string[];
  lat?: number;
  lng?: number;
}

export function getMockShops(): ShopInfo[] {
  return [
    { name: 'IFFCO Kisan Sewa Kendra', type: 'Cooperative', distance: '2.3 km', phone: '+91 98765 43210', products: ['Mancozeb', 'DAP', 'Urea', 'Seeds'], lat: 11.0120, lng: 76.9520 },
    { name: 'TNAU Agritech Dealer', type: 'Government', distance: '4.1 km', phone: '+91 98765 43211', products: ['Sulphur WP', 'Bio-fertilizer', 'Neem Oil'], lat: 11.0200, lng: 76.9600 },
    { name: 'Krishi Seva Kendra', type: 'Private', distance: '5.7 km', phone: '+91 98765 43212', products: ['Carbendazim', 'Pesticides', 'Sprayers'], lat: 11.0080, lng: 76.9480 },
    { name: 'India Agro Agencies', type: 'Private', distance: '7.2 km', phone: '+91 98765 43213', products: ['Copper Oxychloride', 'Drip Systems', 'Fertilizers'], lat: 11.0250, lng: 76.9650 },
  ];
}

// Voice assistant responses (simulated AI) — all 10 languages
export function getAssistantResponse(query: string, lang: string): string {
  const lower = query.toLowerCase();

  // Keywords per topic in all languages
  const waterKeys = ['water', 'irrigat', 'पानी', 'सिंचाई', 'தண்ணீர்', 'பாசன', 'నీరు', 'నీటిపారుదల', 'വെള്ളം', 'ജലസേചന', 'ನೀರು', 'ನೀರಾವರಿ', 'पाणी', 'सिंचन', 'ਪਾਣੀ', 'ਸਿੰਚਾਈ', 'জল', 'সেচ', 'پانی', 'آبپاشی'];
  const pestKeys = ['pest', 'bug', 'insect', 'कीट', 'कीड़', 'பூச்சி', 'పురుగు', 'കീട', 'ಕೀಟ', 'कीटक', 'ਕੀੜ', 'পোকা', 'کیڑ'];
  const fertKeys = ['fertiliz', 'खाद', 'உரம்', 'ఎరువు', 'വളം', 'ಗೊಬ್ಬರ', 'खत', 'ਖਾਦ', 'সার', 'کھاد'];
  const harvestKeys = ['harvest', 'कटाई', 'அறுவடை', 'కోత', 'വിളവെടുപ്പ്', 'ಕೊಯ್ಲು', 'कापणी', 'ਵਾਢੀ', 'ফসল কাটা', 'فصل کاٹ'];
  const weatherKeys = ['weather', 'मौसम', 'வானிலை', 'వాతావరణ', 'കാലാവസ്ഥ', 'ಹವಾಮಾನ', 'हवामान', 'ਮੌਸਮ', 'আবহাওয়া', 'موسم'];

  const responses: Record<string, Record<string, string>> = {
    en: {
      water: 'Based on current soil moisture levels, I recommend irrigating your field with 20mm of water early tomorrow morning. Drip irrigation is most efficient for your crop type.',
      pest: 'I detect potential pest risk due to high humidity. Apply Neem oil spray (5ml/L) as a preventive measure. Monitor undersides of leaves for early signs.',
      fertilizer: 'For your current crop stage, apply NPK 10:26:26 at 50kg per acre. Best time is early morning or late evening with adequate soil moisture.',
      harvest: 'Based on your sowing date and crop type, estimated harvest time is in 45-60 days. Monitor grain moisture content — ideal harvest is at 14% moisture.',
      weather: 'The forecast shows moderate temperatures this week. However, humidity levels are rising which may increase fungal disease risk. Keep fungicide ready.',
      default: 'I am your AgriSense AI assistant. I can help with irrigation advice, pest management, fertilizer recommendations, harvest timing, and weather-based guidance. What would you like to know?',
    },
    hi: {
      water: 'मिट्टी की नमी के आधार पर, कल सुबह जल्दी 20mm पानी से सिंचाई करें। ड्रिप सिंचाई आपकी फसल के लिए सबसे अच्छी है।',
      pest: 'अधिक नमी के कारण कीट का खतरा है। नीम तेल (5ml/L) का छिड़काव करें। पत्तियों की निचली सतह की जांच करें।',
      fertilizer: 'अभी NPK 10:26:26, 50 किलो प्रति एकड़ डालें। सुबह या शाम को डालें जब मिट्टी में नमी हो।',
      harvest: 'आपकी बुवाई तिथि के अनुसार, अनुमानित कटाई 45-60 दिनों में है। अनाज में नमी 14% होने पर कटाई करें।',
      weather: 'इस सप्ताह मौसम सामान्य रहेगा। हालांकि नमी बढ़ रही है जिससे फफूंद रोग का खतरा है। फफूंदनाशक तैयार रखें।',
      default: 'मैं आपका एग्रीसेंस सहायक हूं। सिंचाई, कीट, खाद, फसल कटाई या मौसम — कुछ भी पूछें!',
    },
    ta: {
      water: 'மண் ஈரப்பதத்தின் அடிப்படையில், நாளை அதிகாலை 20mm தண்ணீர் பாய்ச்சவும். சொட்டு நீர்ப்பாசனம் சிறந்தது.',
      pest: 'அதிக ஈரப்பதம் காரணமாக பூச்சி ஆபத்து. வேப்ப எண்ணெய் (5ml/L) தெளிக்கவும். இலைகளின் அடிப்பகுதியை கவனிக்கவும்.',
      fertilizer: 'தற்போதைய பயிர் நிலைக்கு NPK 10:26:26, ஒரு ஏக்கருக்கு 50 கிலோ பயன்படுத்தவும். காலை அல்லது மாலையில் இடவும்.',
      harvest: 'உங்கள் விதைப்பு தேதியின்படி, அறுவடை 45-60 நாட்களில். தானிய ஈரப்பதம் 14% இருக்கும்போது அறுவடை செய்யவும்.',
      weather: 'இந்த வாரம் வெப்பநிலை மிதமாக இருக்கும். ஈரப்பதம் அதிகரிப்பதால் பூஞ்சை நோய் ஆபத்து. பூஞ்சைக்கொல்லி தயாராக வைக்கவும்.',
      default: 'நான் உங்கள் அக்ரிசென்ஸ் உதவியாளர். பாசனம், பூச்சி, உரம், அறுவடை, வானிலை — எதைப் பற்றியும் கேளுங்கள்!',
    },
    te: {
      water: 'మట్టి తేమ ఆధారంగా, రేపు ఉదయం 20mm నీటిపారుదల చేయండి. డ్రిప్ ఇరిగేషన్ మీ పంటకు అత్యుత్తమం.',
      pest: 'అధిక తేమ వల్ల పురుగుల ముప్పు ఉంది. వేప నూనె (5ml/L) పిచికారీ చేయండి. ఆకుల అడుగు భాగాన్ని పరిశీలించండి.',
      fertilizer: 'ప్రస్తుత పంట దశకు NPK 10:26:26, ఎకరాకు 50 కిలో వేయండి. ఉదయం లేదా సాయంత్రం వేయండి.',
      harvest: 'మీ విత్తన తేదీ ప్రకారం, అంచనా కోత 45-60 రోజులలో. ధాన్యంలో తేమ 14% ఉన్నప్పుడు కోయండి.',
      weather: 'ఈ వారం ఉష్ణోగ్రత మోస్తరుగా ఉంటుంది. తేమ పెరుగుతున్నందున శిలీంధ్ర వ్యాధి ముప్పు ఉంది. శిలీంధ్రనాశిని సిద్ధంగా ఉంచండి.',
      default: 'నేను మీ అగ్రిసెన్స్ సహాయకుడిని. నీటిపారుదల, పురుగులు, ఎరువులు, కోత, వాతావరణం — ఏదైనా అడగండి!',
    },
    ml: {
      water: 'മണ്ണിലെ ഈർപ്പത്തിന്റെ അടിസ്ഥാനത്തിൽ, നാളെ രാവിലെ 20mm ജലസേചനം ചെയ്യുക. ഡ്രിപ്പ് ഇറിഗേഷൻ നിങ്ങളുടെ വിളയ്ക്ക് ഏറ്റവും നല്ലതാണ്.',
      pest: 'ഉയർന്ന ഈർപ്പം കാരണം കീട ഭീഷണി. വേപ്പെണ്ണ (5ml/L) തളിക്കുക. ഇലകളുടെ അടിവശം പരിശോധിക്കുക.',
      fertilizer: 'ഇപ്പോഴത്തെ വിള ഘട്ടത്തിന് NPK 10:26:26, ഏക്കറിന് 50 കിലോ ഇടുക. രാവിലെ അല്ലെങ്കിൽ വൈകുന്നേരം ഇടുക.',
      harvest: 'നിങ്ങളുടെ വിതയ്ക്കൽ തീയതി പ്രകാരം, വിളവെടുപ്പ് 45-60 ദിവസത്തിനുള്ളിൽ. ധാന്യത്തിലെ ഈർപ്പം 14% ആകുമ്പോൾ വിളവെടുക്കുക.',
      weather: 'ഈ ആഴ്ച താപനില മിതമായിരിക്കും. ഈർപ്പം വർധിക്കുന്നതിനാൽ ഫംഗൽ രോഗ സാധ്യത. ഫംഗിസൈഡ് തയ്യാറാക്കി വയ്ക്കുക.',
      default: 'ഞാൻ നിങ്ങളുടെ അഗ്രിസെൻസ് സഹായിയാണ്. ജലസേചനം, കീടങ്ങൾ, വളം, വിളവെടുപ്പ്, കാലാവസ്ഥ — എന്തും ചോദിക്കൂ!',
    },
    kn: {
      water: 'ಮಣ್ಣಿನ ತೇವಾಂಶದ ಆಧಾರದಲ್ಲಿ, ನಾಳೆ ಬೆಳಿಗ್ಗೆ 20mm ನೀರಾವರಿ ಮಾಡಿ. ಡ್ರಿಪ್ ನೀರಾವರಿ ನಿಮ್ಮ ಬೆಳೆಗೆ ಅತ್ಯುತ್ತಮ.',
      pest: 'ಹೆಚ್ಚಿನ ತೇವಾಂಶದಿಂದ ಕೀಟ ಅಪಾಯ. ಬೇವಿನ ಎಣ್ಣೆ (5ml/L) ಸಿಂಪಡಿಸಿ. ಎಲೆಗಳ ಕೆಳಭಾಗವನ್ನು ಪರಿಶೀಲಿಸಿ.',
      fertilizer: 'ಪ್ರಸ್ತುತ ಬೆಳೆ ಹಂತಕ್ಕೆ NPK 10:26:26, ಎಕರೆಗೆ 50 ಕೆಜಿ ಹಾಕಿ. ಬೆಳಿಗ್ಗೆ ಅಥವಾ ಸಂಜೆ ಹಾಕಿ.',
      harvest: 'ನಿಮ್ಮ ಬಿತ್ತನೆ ದಿನಾಂಕದ ಪ್ರಕಾರ, ಅಂದಾಜು ಕೊಯ್ಲು 45-60 ದಿನಗಳಲ್ಲಿ. ಧಾನ್ಯದ ತೇವಾಂಶ 14% ಇರುವಾಗ ಕೊಯ್ಲು ಮಾಡಿ.',
      weather: 'ಈ ವಾರ ಉಷ್ಣಾಂಶ ಮಧ್ಯಮವಾಗಿರುತ್ತದೆ. ತೇವಾಂಶ ಹೆಚ್ಚುತ್ತಿರುವುದರಿಂದ ಶಿಲೀಂಧ್ರ ರೋಗ ಅಪಾಯ. ಶಿಲೀಂಧ್ರನಾಶಕ ಸಿದ್ಧವಾಗಿರಲಿ.',
      default: 'ನಾನು ನಿಮ್ಮ ಅಗ್ರಿಸೆನ್ಸ್ ಸಹಾಯಕ. ನೀರಾವರಿ, ಕೀಟ, ಗೊಬ್ಬರ, ಕೊಯ್ಲು, ಹವಾಮಾನ — ಏನಾದರೂ ಕೇಳಿ!',
    },
    mr: {
      water: 'मातीतील ओलाव्याच्या आधारे, उद्या सकाळी 20mm सिंचन करा. ठिबक सिंचन तुमच्या पिकासाठी सर्वोत्तम आहे.',
      pest: 'जास्त आर्द्रतेमुळे कीटकांचा धोका. कडुनिंबाचे तेल (5ml/L) फवारणी करा. पानांच्या खालच्या बाजूला तपासा.',
      fertilizer: 'सध्याच्या पीक टप्प्यासाठी NPK 10:26:26, एकरी 50 किलो द्या. सकाळी किंवा संध्याकाळी द्या.',
      harvest: 'तुमच्या पेरणी तारखेनुसार, अंदाजे कापणी 45-60 दिवसांत. धान्यातील ओलावा 14% असताना कापणी करा.',
      weather: 'या आठवड्यात तापमान मध्यम राहील. आर्द्रता वाढत असल्याने बुरशीजन्य रोगाचा धोका. बुरशीनाशक तयार ठेवा.',
      default: 'मी तुमचा अ‍ॅग्रीसेन्स सहाय्यक आहे. सिंचन, कीटक, खत, कापणी, हवामान — काहीही विचारा!',
    },
    pa: {
      water: 'ਮਿੱਟੀ ਦੀ ਨਮੀ ਦੇ ਆਧਾਰ \'ਤੇ, ਕੱਲ੍ਹ ਸਵੇਰੇ 20mm ਸਿੰਚਾਈ ਕਰੋ। ਡ੍ਰਿਪ ਸਿੰਚਾਈ ਤੁਹਾਡੀ ਫਸਲ ਲਈ ਸਭ ਤੋਂ ਵਧੀਆ ਹੈ।',
      pest: 'ਜ਼ਿਆਦਾ ਨਮੀ ਕਰਕੇ ਕੀੜਿਆਂ ਦਾ ਖ਼ਤਰਾ। ਨਿੰਮ ਦਾ ਤੇਲ (5ml/L) ਛਿੜਕਾਅ ਕਰੋ। ਪੱਤਿਆਂ ਦੀ ਹੇਠਲੀ ਸਤਹ ਚੈੱਕ ਕਰੋ।',
      fertilizer: 'ਮੌਜੂਦਾ ਫਸਲ ਪੜਾਅ ਲਈ NPK 10:26:26, ਏਕੜ ਪਿੱਛੇ 50 ਕਿਲੋ ਪਾਓ। ਸਵੇਰੇ ਜਾਂ ਸ਼ਾਮ ਨੂੰ ਪਾਓ।',
      harvest: 'ਤੁਹਾਡੀ ਬਿਜਾਈ ਤਾਰੀਖ਼ ਅਨੁਸਾਰ, ਅੰਦਾਜ਼ਨ ਵਾਢੀ 45-60 ਦਿਨਾਂ ਵਿੱਚ। ਅਨਾਜ ਦੀ ਨਮੀ 14% ਹੋਣ \'ਤੇ ਵਾਢੀ ਕਰੋ।',
      weather: 'ਇਸ ਹਫ਼ਤੇ ਤਾਪਮਾਨ ਦਰਮਿਆਨਾ ਰਹੇਗਾ। ਨਮੀ ਵਧ ਰਹੀ ਹੈ ਜਿਸ ਨਾਲ ਫੰਗਲ ਬਿਮਾਰੀ ਦਾ ਖ਼ਤਰਾ। ਉੱਲੀਨਾਸ਼ਕ ਤਿਆਰ ਰੱਖੋ।',
      default: 'ਮੈਂ ਤੁਹਾਡਾ ਐਗਰੀਸੈਂਸ ਸਹਾਇਕ ਹਾਂ। ਸਿੰਚਾਈ, ਕੀੜੇ, ਖਾਦ, ਵਾਢੀ, ਮੌਸਮ — ਕੁਝ ਵੀ ਪੁੱਛੋ!',
    },
    bn: {
      water: 'মাটির আর্দ্রতার ভিত্তিতে, আগামীকাল সকালে 20mm সেচ দিন। ড্রিপ সেচ আপনার ফসলের জন্য সবচেয়ে ভালো।',
      pest: 'বেশি আর্দ্রতার কারণে পোকার ঝুঁকি। নিম তেল (5ml/L) স্প্রে করুন। পাতার নিচের দিক পরীক্ষা করুন।',
      fertilizer: 'বর্তমান ফসলের পর্বের জন্য NPK 10:26:26, একরে 50 কেজি দিন। সকালে বা সন্ধ্যায় দিন।',
      harvest: 'আপনার বপনের তারিখ অনুযায়ী, আনুমানিক ফসল কাটা 45-60 দিনে। শস্যের আর্দ্রতা 14% হলে কাটুন।',
      weather: 'এই সপ্তাহে তাপমাত্রা মাঝারি থাকবে। আর্দ্রতা বাড়ছে তাই ছত্রাক রোগের ঝুঁকি। ছত্রাকনাশক প্রস্তুত রাখুন।',
      default: 'আমি আপনার অ্যাগ্রিসেন্স সহকারী। সেচ, পোকা, সার, ফসল কাটা, আবহাওয়া — যেকোনো কিছু জিজ্ঞেস করুন!',
    },
    ur: {
      water: 'مٹی کی نمی کی بنیاد پر، کل صبح 20mm آبپاشی کریں۔ ڈرپ آبپاشی آپ کی فصل کے لیے بہترین ہے۔',
      pest: 'زیادہ نمی کی وجہ سے کیڑوں کا خطرہ۔ نیم کا تیل (5ml/L) چھڑکاؤ کریں۔ پتوں کی نچلی سطح چیک کریں۔',
      fertilizer: 'موجودہ فصل کے مرحلے کے لیے NPK 10:26:26، فی ایکڑ 50 کلو ڈالیں۔ صبح یا شام ڈالیں۔',
      harvest: 'آپ کی بوائی کی تاریخ کے مطابق، تخمینی فصل کٹائی 45-60 دنوں میں۔ اناج میں نمی 14% ہونے پر کاٹیں۔',
      weather: 'اس ہفتے درجہ حرارت معتدل رہے گا۔ نمی بڑھ رہی ہے جس سے پھپھوندی بیماری کا خطرہ ہے۔ پھپھوندی کش تیار رکھیں۔',
      default: 'میں آپ کا ایگری سینس معاون ہوں۔ آبپاشی، کیڑے، کھاد، فصل کٹائی، موسم — کچھ بھی پوچھیں!',
    },
  };

  const langResponses = responses[lang] || responses.en;

  const matchesAny = (keys: string[]) => keys.some(k => lower.includes(k) || query.includes(k));

  if (matchesAny(waterKeys)) return langResponses.water;
  if (matchesAny(pestKeys)) return langResponses.pest;
  if (matchesAny(fertKeys)) return langResponses.fertilizer;
  if (matchesAny(harvestKeys)) return langResponses.harvest;
  if (matchesAny(weatherKeys)) return langResponses.weather;
  return langResponses.default;
}
