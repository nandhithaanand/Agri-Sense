## Plan: 3 Major Feature Updates

### 1. Shops Tab — OpenStreetMap + Leaflet Integration
- Install `leaflet` and `react-leaflet` packages
- Show each shop on an interactive map with markers
- Clicking a marker shows shop name, phone, products
- "Get Directions" button opens Google Maps navigation
- All strings localized in 10 languages

### 2. Replace AI Assistant → Farm Consultants Tab
- Remove `AssistantTab.tsx`, create `ConsultantsTab.tsx`
- Show a list of nearby farm consultants (mock data) with:
  - Name, specialty, phone number, location
  - "Call" button (tel: link) and "Get Directions" (Google Maps link)
- Consultants shown on a small Leaflet map
- Update nav icon and translations for all 10 languages

### 3. Satellite NDVI — Real Agromonitoring API Integration
- **Requires**: Lovable Cloud (edge function to proxy API calls) + `AGROMONITORING_API_KEY` secret
- Enable Lovable Cloud
- Create edge function `get-ndvi` that:
  - Accepts field polygon coordinates
  - Calls Agromonitoring API for NDVI data
  - Returns health zone percentages and satellite imagery URL
- Update `MapTab.tsx` with:
  - Leaflet map with field boundaries drawn
  - NDVI color overlay on the field
  - Health zone breakdown (Healthy/Moderate/Stressed/Poor percentages)
  - Alerts when Stressed+Poor increases >10% between passes
  - "Go to stressed area" button → opens Google Maps
  - Cloud coverage filtering
- Full localization in all 10 languages

### Execution Order
1. Install Leaflet packages
2. Build Shops + Consultants tabs (no cloud needed)
3. Enable Lovable Cloud → request API key → build NDVI integration
